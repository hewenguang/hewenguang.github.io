# Circle reading mode

Make webpages pleasing to the eye and return reading to the original intention

## install deps

```
npm install
```

## dev

```
npm run dev
```

## build

Please do the following after installing nodejs and NPM

```
npm install
npm run build
```
Generate extension in dist / Firefox folder