import React from 'react';
import Copy from 'app/components/copy';
import useApp from 'app/context/useApp';
import './index.less';

export default function(){
  const app = useApp();
  const manifest = app.runtime.getManifest();
  const version = manifest.version ? `v ${manifest.version}` : '--';

  return (
    <div className="version">
      {app.fire('i18n', 'version')} {version} <Copy text={version} />
    </div>
  );
}
