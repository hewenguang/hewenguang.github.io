import React from 'react';
import Icon from 'app/components/icon';
import useApp from 'app/context/useApp';

export default function(props){
  const { text } = props;
  const app = useApp();
  const disabled = !text;

  return (
    <Icon
      name="copy"
      tooltip={app.fire('i18n', 'copy')}
      style={disabled ? {color:'#ccc'}: undefined}
      onClick={() => {
        if(disabled){
          return;
        }
        const type = dom.copy(text) ? 'success' : 'fail';
        app.fire('message', {
          type,
          duration: 1,
          key: `copy_${type}`,
          message: app.fire('i18n', `copy_${type}`),
        });
      }}
    />
  );
}
