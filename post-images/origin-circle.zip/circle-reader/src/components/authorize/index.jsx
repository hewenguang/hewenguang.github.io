import React from 'react';

const allowedFields = [
  'custom',
  'stylesheet',
  'autosync',
  'autoupdate',
  'style-more',
];

export default function(props){
  const { field, access, children } = props;

  if(!access && allowedFields.includes(field)){
    return React.cloneElement(children, {
      ...children.props,
      vip: true,
    });
  }

  return children;
}

export function authorize(field){
  if(!field){
    return true;
  }
  return !allowedFields.includes(field);
}
