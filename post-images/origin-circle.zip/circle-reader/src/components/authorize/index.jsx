import React from 'react';

const allowedFields = ['title1', 'title1weight', 'title2', 'title2weight', 'title3','title3weight', 'title4', 'title4weight', 'color', 'link', 'hover', 'visited', 'select', 'selectbg', 'bg', 'scrollbar', 'column', 'padding', 'autohide', 'removefooter', 'autoscroll', 'autofullscreen', 'stylesheet', 'scrollpage', 'speak', 'copy', 'image', 'word', 'text', 'marked', 'mail', 'srt-scrollpage', 'srt-togglescrollpage', 'srt-speak', 'srt-togglespeak', 'srt-copy', 'srt-image', 'srt-word', 'srt-text', 'srt-marked', 'srt-mail'];

export default function(props){
  const { field, access, children } = props;

  if(!access && allowedFields.includes(field)){
    return React.cloneElement(children, {
      ...children.props,
      vip: true,
    });
  }

  return children;
}

export function authorize(field){
  if(!field){
    return true;
  }
  return !allowedFields.includes(field);
}
