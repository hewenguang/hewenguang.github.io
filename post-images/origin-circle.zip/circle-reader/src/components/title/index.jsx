import React from 'react';
import Icon from 'app/components/icon';
import useApp from 'app/context/useApp';

export default function(props){
  const { vip, name, label, learn_more, tooltip, tooltipStyle, placement } = props;
  const app = useApp();

  return (
    <label>
      {name && (
        <Icon
          name={name}
          placement={placement}
          style={{marginRight:3}}
        />
      )}
      {label}
      {tooltip && (
        <Icon
          name="question"
          tooltip={
            <>
              {tooltip}{learn_more && (
                <a
                  target="_blank"
                  href={learn_more}
                  style={{marginLeft:3}}
                >
                  {app.fire('i18n', 'learn_more')}
                </a>
              )}
            </>
          }
          placement={placement}
          style={tooltipStyle ? tooltipStyle : {marginLeft:3}}
        />
      )}
      {vip && ' 💎'}
    </label>
  );
}
