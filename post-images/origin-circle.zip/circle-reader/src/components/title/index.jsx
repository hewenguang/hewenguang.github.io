import React from 'react';
import { Tooltip } from 'antd';
import { QuestionCircleOutlined } from '@ant-design/icons';

export default function(props){
  const { vip, label, tooltip, tooltipStyle, placement } = props;

  return (
    <label>
      {label}
      {tooltip && (
        <Tooltip
          title={tooltip}
          placement={placement}
        >
          <QuestionCircleOutlined style={tooltipStyle ? tooltipStyle : {marginLeft:3}}/>
        </Tooltip>
      )}
      {vip && ' 💎'}
    </label>
  );
}
