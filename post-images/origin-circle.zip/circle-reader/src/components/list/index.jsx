import React from 'react';
import cx from 'classnames';
import { List } from 'antd';
import Title from '../title';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import Authorize, { authorize } from '../authorize';
import './index.less';

export default function (props){
  const {
    data = [],
    borderNone,
    className,
    renderItem,
    children,
    itemStyle,
    borderTop,
    borderBottom,
    ...resetProps
  } = props;
  const app = useApp();
  const user = useUser();

  return (
    <List
      {...resetProps}
      dataSource={data}
      className={cx(className, {
        'border-top': borderTop,
        'border-none': borderNone,
        'border-bottom': borderBottom
      })}
      renderItem={item => {
        const itemProps = {
          ...item,
          onChange: () => {
            const allowed = user.member || authorize(item.field);
            !allowed && app.fire('upgrade', 'upgrade');
            return allowed;
          },
        };
        return (
          <List.Item style={itemStyle}>
            {Object.prototype.toString.call(children) === '[object Function]'
              ? children(itemProps)
              : (
                <>
                  {item.label && (
                    <Authorize
                      field={item.field}
                      access={user.member}
                    >
                      <Title {...item} />
                    </Authorize>
                  )}
                  {renderItem && renderItem(itemProps)}
                </>
              )
            }
          </List.Item>
        );
      }}
    />
  );
}
