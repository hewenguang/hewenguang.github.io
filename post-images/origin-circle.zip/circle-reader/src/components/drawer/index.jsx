import cx from 'classnames';
import { ConfigProvider } from 'antd';
import Icon from 'app/components/icon';
import { AppContext } from 'app/context';
import React, { useRef, useState, useEffect } from 'react';
import 'antd/dist/antd.css';
import './index.less';

export default function(props){
  const { app, size, plugin, children, closeable = true, disabled, type = 'setting' } = props;
  const root = useRef(null);
  const [ visible, setVisible ] = useState(false);
  const rootElement = app.fire('dom-root');

  useEffect(() => {
    const hook = app.on(plugin, function(){
      app.fire('drawer', plugin);
    });
    setTimeout(function(){
      setVisible(true);
      app.fire('drawer', plugin);
    }, 100);
    return () => {
      app.remove(hook);
    };
  }, []);

  useEffect(() => {
    const hook = app.on('drawer', function(name){
      if(plugin === name){
        if(rootElement){
          if(visible){
            rootElement.style.removeProperty('padding-right');
            app.fire('toolbar-key', '');
          } else {
            rootElement.style.setProperty('padding-right', type === 'setting' ? '300px' : '1px');
            app.fire('toolbar-key', plugin);
          }
          // 更新工具栏位置
          app.fire('toolbar-sticky');
        }
        setVisible(!visible);
        app.fire(`${name}-change`, !visible);
      } else {
        setVisible(false);
        visible && app.fire(`${plugin}-change`, false);
      }
    });
    return () => {
      app.remove(hook);
    };
  }, [ visible ]);

  return (
    <AppContext.Provider value={app}>
      <ConfigProvider
        componentSize={size}
        getPopupContainer={() => {
          if(root && root.current){
            return root.current;
          }
        }}
      >
        <div
          className={cx('drawer', type, {
            disabled,
            closeable,
            visible: !disabled && visible,
          })}
        >
          {!disabled && closeable && (
            <Icon
              name="close"
              tabIndex={0}
              className="close"
              onClick={() => app.fire('drawer', plugin)}
            />
          )}
          <div ref={root} className="drawer-body">{children}</div>
        </div>
      </ConfigProvider>
    </AppContext.Provider>
  );
}
