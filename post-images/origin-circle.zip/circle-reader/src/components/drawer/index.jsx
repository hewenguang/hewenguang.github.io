import cx from 'classnames';
import { CloseOutlined } from '@ant-design/icons';
import React, { useRef, useEffect } from 'react';
import './index.less';

export default function(props){
  const { visible, className, onClose, children, getRoot, disabled } = props;
  const root = useRef(null);

  useEffect(() => {
    if(!root || !getRoot){
      return;
    }
    root.current && getRoot(root.current);
  }, []);

  return (
    <div className={cx('drawer', className, { disabled, visible: !disabled && visible })}>
      {!disabled && (
        <CloseOutlined
          className="close"
          onClick={onClose}
        />
      )}
      <div
        ref={root}
        className="drawer-body"
      >
        {children}
      </div>
    </div>
  );
}
