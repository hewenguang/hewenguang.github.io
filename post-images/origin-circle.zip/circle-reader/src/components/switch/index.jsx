import { Switch, Tooltip } from 'antd';
import React, { useRef } from 'react';

export default function(props){
  const { disabled, tooltip, placement, checked, onChange } = props;
  const root = useRef(null);

  return (
    <Tooltip
      title={tooltip}
      placement={placement}
    >
      <Switch
        ref={root}
        checked={!!checked}
        disabled={disabled}
        onChange={changeChecked => {
          onChange && onChange(changeChecked);
          root && root.current && root.current.blur();
        }}
      />
    </Tooltip>
  );
}
