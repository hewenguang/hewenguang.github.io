import React from 'react';
import Switch from './index';
import useApp from 'app/context/useApp';
import useOption from 'app/context/useOption';

export default function(props){
  const { field, table, onChange } = props;
  const app = useApp();
  const [ option, change ] = useOption({
    field,
    table,
    defaultValue: false,
  });

  return (
    <Switch
      checked={!!option}
      onChange={checked => {
        onChange(checked) && change(checked, function(){
          app.fire(field, checked);
        });
      }}
    />
  );
}
