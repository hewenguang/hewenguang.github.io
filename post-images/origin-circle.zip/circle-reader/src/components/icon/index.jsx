import React from 'react';
import cx from 'classnames';
import { Tooltip } from 'antd';
import icons from './config';
import './index.less';

export default function (props){
  const {
    size,
    name,
    onClick,
    tooltip,
    disabled,
    className,
    placement,
    tabIndex = -1,
    mouseEnterDelay,
    ...resetProps
  } = props;

  return (
    <Tooltip
      title={tooltip}
      placement={placement}
      mouseEnterDelay={mouseEnterDelay}
      overlayClassName="icon-tooltip"
    >
      <span
        {...resetProps}
        role="img"
        tabIndex={tabIndex}
        className={cx('icon', size, className, {disabled})}
        onClick={event => {
          if(disabled){
            return;
          }
          onClick && onClick(event);
        }}
        onKeyPress={event => {
          if(disabled || tabIndex <= -1 || event.key !== 'Enter'){
            return;
          }
          onClick && onClick(event);
        }}
      >
        {icons[name]}
      </span>
    </Tooltip>
  );
}
