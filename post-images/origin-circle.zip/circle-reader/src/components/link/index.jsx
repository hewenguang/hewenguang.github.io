import React from 'react';

export default function(props){
  const { style, children, className, onClick } = props;
 
  return (
    <a
      tabIndex="0"
      style={style}
      onClick={onClick}
      className={className}
      onKeyPress={event => event.key === 'Enter' && onClick && onClick(event)}
    >
      {children}
    </a>
  );
}
