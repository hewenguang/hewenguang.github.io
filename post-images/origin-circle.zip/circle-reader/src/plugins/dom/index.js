App.register('dom', ['utils'], function(utils){
  window.dom = {
    tag(node, tagName){
      return node && node.tagName && utils.toLower(node.tagName) === tagName;
    },
    setStyle(node, attr, value) {
      if (!node || !utils.isString(attr) || utils.isUndefined(value)) {
        return;
      }
      const attrValue = utils.isNumber(value) && !['zIndex', 'opacity'].includes(attr) ? `${value}px` : value;
      node.style[attr] = attrValue;
    },
    setAttr(node, attr, value){
      if (!node || !node.setAttribute || !utils.isString(attr) || utils.isUndefined(value)) {
        return;
      }
      const attrValue = utils.isNumber(value) && !['zIndex', 'opacity'].includes(attr) ? `${value}px` : value;    
      switch (attr) {
        case 'innerHTML':
        case 'innerText':
        case 'className':
        case 'textContent':
          node[attr] = attrValue;
          break;
        case 'style':
          utils.each(value, (itemValue, itemKey) => {
            this.setStyle(node, itemKey, itemValue);
          });
        break;
        default:
          node.setAttribute(attr, attrValue);
      }
    },
    create(tagName, attrs){
      const node = document.createElement(tagName);
      utils.each(attrs, (value, key) => {
        this.setAttr(node, key, value);
      });
      return node;
    },
    remove(node){
      node && node.parentElement && node.parentElement.removeChild(node);
    },
    getAttr(node, attr) {
      if (!node) {
        return;
      }
      if(utils.isString(attr)){
        return node.getAttribute(attr);
      }
      return Array.prototype.slice.call(node.attributes).reduce((prev, next) => `${prev} ${next.nodeValue}`, '');
    },
    removeAttr(node, attr) {
      if (!node) {
        return;
      }
      if(utils.isString(attr)){
        node.removeAttribute(attr);
      } else {
        const attributesToRemove = [];
        utils.each(node.attributes, function(attribute){
          const attributeName = attribute.nodeName;
          utils.isFunction(attr) && attr(attributeName) && attributesToRemove.push(attributeName);
        });
        utils.each(attributesToRemove, function(attribute){
          node.removeAttribute(attribute);
        });
      }
    },
    getStyle(node, property) {
      if (node[property]) {
        return node[property];
      }
      if (node.style[property]) {
        return node.style[property];
      }
      if (window.getComputedStyle) {
        return window.getComputedStyle(node, null)[property];
      }
      if (node.currentStyle) {
        return node.currentStyle[property];
      }
    },
    position(node) {
      if (!node || !node.getBoundingClientRect) {
        return;
      }
      if(node._rect){
        return node._rect;
      }
      const scrollX = window.scrollX;
      const scrollY = window.scrollY;
      const rect = node.getBoundingClientRect();
      if(scrollX <= 0 && scrollY <= 0){
        node._rect = rect;
        return node._rect;
      }
      node._rect = {
        top: rect.top + scrollY,
        right: rect.right - scrollX,
        bottom: rect.bottom - scrollY,
        left: rect.left + scrollX,
        width: rect.width,
        height: rect.height,
      };
      return node._rect;
    },
    visible(node) {
      if (!utils.isElement(node)) {
        return false;
      }
      if (this.tag(node, 'body')) {
        return true;
      }
      const nodeRect = this.position(node);
      if(nodeRect.height <= 10 || nodeRect.width <= 10){
        return false;
      }
      if ('0' === this.getStyle(node, 'opacity') || 'hidden' === this.getStyle(node, 'visibility')){
        return false;
      }
      return true;
    },
    parents(node, maxAncestor = 3, condition) {
      let i = 0;
      let tempNode = node.parentElement;
      const ancestors = [];
      while (tempNode && !this.tag(tempNode, 'html')) {
        if(utils.isFunction(condition) && condition(tempNode, i)){
          ancestors.push(tempNode);
          if (++i >= maxAncestor) {
            break;
          }
        }
        tempNode = tempNode.parentElement;
      }
      return ancestors;
    },
    nodeText(node){
      if(!node){
        return '';
      }
      let text = '';
      if(utils.isString(node)){
        text = node;
      } else if(utils.isTextNode(node)){
        text = node.nodeValue;
      } else if(utils.isElement(node)){
        text = node.innerText;
      }
      const cleanText = (text || '').trim();
      return cleanText.length > 0 ? cleanText.replace(/^&nbsp;+|&nbsp;+$/g, '') : '';
    },
    isNodeWhitespace(node){
      if (!utils.isTextNode(node)){
        return false;
      }
      const nodeValue = node.nodeValue.trim();
      if(nodeValue.length <= 0){
        return true;
      }
      return /^[\s\xA0]+$/.test(nodeValue);
    },
    counterNode(node){
      let counter = 0;
      utils.each(node.childNodes, item => {
        if(utils.isElement(item) || !this.isNodeWhitespace(item)){
          counter++;
        }
      });
      return counter;
    },
    onlyOneNode(node){
      if(!utils.isElement(node)){
        return false;
      }
      return this.counterNode(node) === 1;
    },
    replaceNode(node, newNode){
      let child;
      // eslint-disable-next-line
      while(child = node.firstChild){
        newNode.appendChild(child);
      }
      return newNode;
    },
    linkDensity(node) {
      const links = node.getElementsByTagName('a');
      let linkTextLength = 0;
      utils.each(links, (link) => {
        linkTextLength += this.nodeText(link).length;
      });
      const nodeTextLength = this.nodeText(node).length;
      return linkTextLength / (nodeTextLength <= 0 ? 1 : nodeTextLength);
    },
    siblings(node, callback) {
      if (!node || !node.parentElement || !utils.isFunction(callback)) {
        return;
      }
      let tempNode = node.parentElement.firstElementChild;
      while (tempNode && !this.tag(tempNode, 'body')) {
        if (tempNode !== node && callback(tempNode)) {
          break;
        }
        tempNode = tempNode.nextElementSibling;
      }
    },
    parentExcept(node, callback) {
      if (!node || !node.parentElement) {
        return;
      }
      let tempNode = node;
      while (tempNode && !this.tag(tempNode, 'body')){
        this.siblings(tempNode, item => {
          utils.isFunction(callback) && callback(item);
        });
        tempNode = tempNode.parentElement;
      }
    },
    scrollTop(node){
      if(utils.isElement(node)){
        return node.scrollTop;
      } else {
        return window.pageYOffset;
      }
    },
    clientWidth(node){
      if(utils.isElement(node)){
        return node.clientWidth;
      } else {
        return window.innerWidth;
      }
    },
    clientHeight(node){
      if(utils.isElement(node)){
        return node.clientHeight;
      } else {
        return window.innerHeight;
      }
    },
    ready(callback){
      document.addEventListener('DOMContentLoaded', callback, false);
      (document.readyState === 'interactive' || document.readyState === 'complete') && callback();
    },
    checkImage(node, target){
      const width = node.naturalWidth;
      const height = node.naturalHeight;
      // 删除严重失衡宽高比图片（如 banner 广告）
      if(width / height > 4){
        this.remove(target || node);
      }
    },
    imgFilter(node, target){
      // 删除加载失败的图片
      node.addEventListener('error', () => {
        this.remove(target || node);
      });
      // 删除长宽严重失衡的图片
      node.complete && this.checkImage(node, target);
      node.addEventListener('load', () => {
        this.checkImage(node, target);
      });
    },
    imgUrl(node){
      let url = '';
      utils.each(node.attributes, function(attribute){
        const nodeName = attribute.nodeName;
        if(['class', 'role', 'src'].includes(nodeName)){
          return;
        }
        const nodeValue = `${attribute.nodeValue}`;
        // original https://www.ithome.com/0/544/257.htm
        if((nodeValue.startsWith('http') || /src|url|origin/i.test(nodeName)) && nodeValue.split('/').length > 1 && nodeValue.length > 10){
          url = nodeValue.split(/\s/).shift();
          return true;
        }
      });
      return url ? url : node.src;
    }
    // getSelector(node, withoutClass, index = 1){
    //   if(!utils.isElement(node)){
    //     console.error('node utils.is valid');
    //     return;
    //   }
    //   const id = node.id;
    //   if (id) {
    //     return `#${id}`;
    //   }
    //   if (this.tag(node, 'body')){
    //     return 'body';
    //   }
    //   let selector = `> ${utils.toLower(node.tagName)}`;
    //   if(!withoutClass || index <= 1){
    //     const className = node.className.trim();
    //     const classes = className.length > 0 ? className.split(' ') : [];
    //     classes.length > 0 && (selector += `.${classes.join('.')}`);
    //   }
    //   const parentElement = node.parentElement;
    //   if(parentElement){
    //     return getSelector(parentElement, withoutClass, index + 1) + ' ' + selector;
    //   } else {
    //     return selector;
    //   }
    // }
  };
  return window.dom;
});
