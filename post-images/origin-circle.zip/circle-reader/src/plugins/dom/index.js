App.register('dom', ['utils'], function(utils){
  window.dom = {
    tag(node, tagName){
      return node && node.tagName && utils.toLower(node.tagName) === tagName;
    },
    setStyle(node, attr, value) {
      if (!node || !utils.isString(attr) || utils.isUndefined(value)) {
        return;
      }
      const attrValue = utils.isNumber(value) && !['zIndex', 'opacity'].includes(attr) ? `${value}px` : value;
      node.style[attr] = attrValue;
    },
    setAttr(node, attr, value){
      if (!node || !node.setAttribute || !utils.isString(attr) || utils.isUndefined(value)) {
        return;
      }
      const attrValue = utils.isNumber(value) && !['zIndex', 'opacity'].includes(attr) ? `${value}px` : value;    
      switch (attr) {
        case 'innerHTML':
        case 'innerText':
        case 'className':
        case 'textContent':
          node[attr] = attrValue;
          break;
        case 'style':
          utils.each(value, (itemValue, itemKey) => {
            this.setStyle(node, itemKey, itemValue);
          });
        break;
        default:
          node.setAttribute(attr, attrValue);
      }
    },
    create(tagName, attrs){
      const node = document.createElement(tagName);
      utils.each(attrs, (value, key) => {
        this.setAttr(node, key, value);
      });
      return node;
    },
    remove(node){
      node && node.parentElement && node.parentElement.removeChild(node);
    },
    getAttr(node, attr) {
      if (!node) {
        return;
      }
      if(utils.isString(attr)){
        return node.getAttribute(attr);
      }
      return Array.prototype.slice.call(node.attributes).reduce((prev, next) => `${prev} ${next.nodeValue}`, '');
    },
    removeAttr(node, attr) {
      if (!node) {
        return;
      }
      if(utils.isString(attr)){
        node.removeAttribute(attr);
      } else {
        const attributesToRemove = [];
        utils.each(node.attributes, function(attribute){
          const attributeName = attribute.nodeName;
          utils.isFunction(attr) && attr(attributeName) && attributesToRemove.push(attributeName);
        });
        utils.each(attributesToRemove, function(attribute){
          node.removeAttribute(attribute);
        });
      }
    },
    getStyle(node, property) {
      if (node[property]) {
        return node[property];
      }
      if (node.style[property]) {
        return node.style[property];
      }
      if (window.getComputedStyle) {
        return window.getComputedStyle(node, null)[property];
      }
      if (node.currentStyle) {
        return node.currentStyle[property];
      }
    },
    position(node) {
      if (!node || !node.getBoundingClientRect) {
        return;
      }
      if(node._rect){
        return node._rect;
      }
      const scrollX = window.scrollX;
      const scrollY = window.scrollY;
      const rect = node.getBoundingClientRect();
      if(scrollX <= 0 && scrollY <= 0){
        node._rect = rect;
        return node._rect;
      }
      node._rect = {
        top: rect.top + scrollY,
        right: rect.right - scrollX,
        bottom: rect.bottom - scrollY,
        left: rect.left + scrollX,
        width: rect.width,
        height: rect.height,
      };
      return node._rect;
    },
    visible(node) {
      if (!utils.isElement(node)) {
        return false;
      }
      if (['br', 'hr', 'img', 'body'].includes(utils.toLower(node.tagName))) {
        return true;
      }
      const rect = node.getBoundingClientRect();
      if(rect.height <= 0 || rect.width <= 0){
        return false;
      }
      if ('0' === this.getStyle(node, 'opacity') || 'hidden' === this.getStyle(node, 'visibility')){
        return false;
      }
      return true;
    },
    nodeText(node){
      if(!node){
        return '';
      }
      let text = '';
      if(utils.isString(node)){
        text = node;
      } else if(utils.isTextNode(node)){
        text = node.nodeValue;
      } else if(utils.isElement(node)){
        text = node.textContent;
      }
      const cleanText = (text || '').trim();
      return cleanText.length > 0 ? cleanText.replace(/^&nbsp;+|&nbsp;+$/g, '') : '';
    },
    isNodeWhitespace(node){
      if (!utils.isTextNode(node)){
        return false;
      }
      const nodeValue = node.nodeValue.trim();
      if(nodeValue.length <= 0){
        return true;
      }
      return /^[\s\xA0]+$/.test(nodeValue);
    },
    counterNode(node){
      let counter = 0;
      utils.each(node.childNodes, item => {
        if(utils.isElement(item) || !this.isNodeWhitespace(item)){
          counter++;
        }
      });
      return counter;
    },
    onlyOneNode(node){
      if(!utils.isElement(node)){
        return false;
      }
      return this.counterNode(node) === 1;
    },
    replaceNode(node, newNode){
      let child;
      // eslint-disable-next-line
      while(child = node.firstChild){
        newNode.appendChild(child);
      }
      return newNode;
    },
    linkDensity(node) {
      const links = node.getElementsByTagName('a');
      let linkTextLength = 0;
      utils.each(links, (link) => {
        linkTextLength += this.nodeText(link).length;
      });
      const nodeTextLength = this.nodeText(node).length;
      return linkTextLength / (nodeTextLength <= 0 ? 1 : nodeTextLength);
    },
    sibling(node, callback){
      let nextSibling;
      let current = node.firstElementChild;
      while(current){
        nextSibling = current.nextElementSibling;
        if(callback(current)){
          current = null;
        } else {
          current = nextSibling;
        }
      }
    },
    nextSibling(node, callback){
      let nextSibling;
      let current = node.firstChild;
      while(current){
        nextSibling = current.nextSibling;
        if(callback(current)){
          current = null;
        } else {
          current = nextSibling;
        }
      }
    },
    scrollTop(node){
      if(utils.isElement(node)){
        return node.scrollTop;
      } else {
        return window.pageYOffset;
      }
    },
    clientWidth(node){
      if(utils.isElement(node)){
        return node.clientWidth;
      } else {
        return window.innerWidth;
      }
    },
    clientHeight(node){
      if(utils.isElement(node)){
        return node.clientHeight;
      } else {
        return window.innerHeight;
      }
    },
    ready(callback){
      if (document.readyState === 'complete'){
        callback();
        return;
      }
      let timer;
      function done(event){
        if(event && event.type && event.type == 'readystatechange' && document.readyState != 'complete'){
          return;
        }
        timer && clearTimeout(timer);
        document.removeEventListener('DOMContentLoaded', done, false);
        document.removeEventListener('readystatechange', done, false);
        callback();
      }
      document.addEventListener('DOMContentLoaded', done, false);
      document.addEventListener('readystatechange', done, false);
      timer = setTimeout(done, 4000);
    },
    scrollIntoView(node){
      utils.isElement(node) && node.scrollIntoView({
        block: 'start',
        inline: 'nearest',
        behavior: 'smooth',
      });
    },
    imgUrl(node){
      let url = '';
      utils.each(node.attributes, function(attribute){
        const nodeName = attribute.nodeName;
        if(['class', 'role', 'src'].includes(nodeName)){
          return;
        }
        const nodeValue = `${attribute.nodeValue}`;
        // original https://www.ithome.com/0/544/257.htm
        if((nodeValue.startsWith('http') || /src|url|origin/i.test(nodeName)) && nodeValue.split('/').length > 1 && nodeValue.length > 10){
          url = nodeValue.split(/\s/).shift();
          return true;
        }
      });
      return url ? url : node.src;
    },
    traverse(node){
      let current = node;
      let mirror = node.cloneNode(true);
      while(current){
        mirror.mirrorElement = current;
        const firstElementChild = current.firstElementChild;
        if (firstElementChild) {
          current = firstElementChild;
          mirror = mirror.firstElementChild;
        }else{
          let nextSibling;
          while (current !== node && !(nextSibling = current.nextElementSibling)){
            current = current.parentElement;
            mirror = mirror.parentElement;
          }
          if(current === node){
            break;
          }
          current = nextSibling;
          mirror = mirror.nextElementSibling;
        }
      }
      return mirror;
    },
    copy(node){
      if(!utils.isElement(node) && !utils.isString(node)){
        return;
      }
      let target = node;
      if(utils.isString(node)){
        target = this.create('div', {
          innerText: node,
          style: {
            position:'fixed',
            left:0,
            top:0,
            opacity:0,
          }
        });
        document.documentElement.appendChild(target);
      }
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(target);
      selection.removeAllRanges();
      selection.addRange(range);
      let success = false;
      try {success = document.execCommand('copy');} catch(e){
        // todo
      }
      selection.removeAllRanges();
      target !== node && this.remove(target);
      return success;
    },
    keyboard(event){
      const key = (event.key || '').trim().length > 0 ? event.key : event.code;
      if(!key || ['alt', 'control', 'meta', 'shift'].includes(utils.toLower(key))){
        return '';
      }
      const keys = [key];
      event.altKey && keys.unshift('alt');
      event.ctrlKey && keys.unshift('ctrl');
      event.metaKey && keys.unshift('meta');
      // event.shiftKey && keys.unshift('shift');
      if(keys.length <= 0){
        return '';
      }
      return keys.join('+').replace(/？/g, '?').replace(/Escape/g, 'escape');
    }
  };
  return window.dom;
});
