App.register('pjax', 'utils', function(utils){
  const app = this;

  app.on('pjax-start', function({request, callback}){
    callback && callback();
    const hostname = request.hostname;
    hostname && app.cache('pjax-hostname', hostname);
  });
  // pjax 页面事件监听
  app.tabs.onCreated.addListener(function(){
    app.cache('pjax-hostname', null);
  });
  app.tabs.onUpdated.addListener(function(tabId, changeInfo){
    const url = changeInfo.url;
    url && app.cache('pjax-changeurl', url);
    if(changeInfo.status !== 'complete' || !app.cache('pjax-changeurl') || !app.cache('pjax-hostname')){
      return;
    }
    const location = utils.location(app.cache('pjax-changeurl'));
    if(location.hostname !== app.cache('pjax-hostname')){
      return;
    }
    app.fire('send', 'pjax-change', {tab: {id: tabId}});
    app.cache('pjax-changeurl', null);
  });
});
