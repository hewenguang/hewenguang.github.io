App.register('pjax', 'utils', function(utils){
  const app = this;

  // 开始监听地址变化
  app.on('render-ready', function(){
    app.fire('send', 'pjax-start', {
      hostname: location.hostname,
    });
  });
  // 监听地址变化返回
  app.on('pjax-change', function({callback} = {}){
    callback && callback();
    utils.wait(function(){
      app.fire('send', 'status', function(){
        const { url, title, article } = app.fire('parser', document);
        if(utils.isElement(article)){
          app.fire('send', 'status', {action: 'wait'});
          app.cache('node', {
            url,
            title,
            article,
            cover: app.fire('parser-cover', article),
          });
          app.fire('empty-anchor');
          app.fire('empty-page', function(){
            app.fire('render-page');
          });
        } else {
          app.fire('parser-fail');
        }
      });
    }, 1000);
  });
});
