App.register('remove', ['utils', 'dom', 'choose'], function(utils, dom){
  const app = this;
  const root = app.fire('dom-container');
  if(!root){
    return;
  }
  let destory;
  app.on('remove', function(){
    if(destory){
      app.fire('toolbar-key', '');
      utils.isFunction(destory) && destory();
      destory = null;
    } else {
      app.fire('toolbar-key', 'srt-remove');
      destory = app.fire('choose', root, function(node){
        dom.remove(node);
        const tag = utils.toLower(node.tagName);
        ['img', 'pre'].includes(tag) && app.fire(`remove-${tag}`);
      }, function(node){
        return node.classList.contains('page');
      });
      app.fire('send', 'storage', {
        execute:'get',
        name: 'remove-alert',
      }, function({error, data}){
        if(error || data){
          error && app.fire('error', error);
          return;
        }
        app.fire('message', {
          key: 'remove',
          btnText: app.fire('i18n', 'got_it'),
          message: app.fire('i18n', 'remove_element_tooltip'),
        }, function(){
          app.fire('send', 'storage', {
            execute: 'add',
            name: 'remove-alert',
            value: true,
          }, function({error}){
            error && app.fire('error', error);
          });
        });
      });
    }
    app.fire('send', 'analytics', {event:'remove'});
  });
  app.fire('remove');
});

