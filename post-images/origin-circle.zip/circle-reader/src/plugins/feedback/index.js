App.register('feedback', function(){
  const app = this;
  app.on('feedback', function(){
    app.fire('to', app.to('feedback'));
    app.fire('send', 'analytics', {event:'feedback'});
  });
  app.fire('feedback');
});
