App.register('mail', function(){
  const app = this;
  const root = app.fire('dom-container');
  if(!root){
    return;
  }
  app.on('mail', function(){
    app.fire('toolbar-loading', 'mail');
    const body = encodeURIComponent(root.innerText);
    const subject = encodeURIComponent(document.title) || 'circle';
    app.fire('send', 'tab', {
      action: 'update',
      value: {
        url: `mailto:?subject=${subject}&body=${body}`,
      }
    }, function(){
      app.fire('toolbar-loading', '');
    });
    app.fire('send', 'storage', {
      execute:'get',
      name: 'mail-alert',
    }, function({error, data}){
      if(error || data){
        error && app.fire('error', error);
        return;
      }
      app.fire('message', {
        key: 'mail',
        duration: 8,
        btnText: app.fire('i18n', 'got_it'),
        message: app.fire('i18n', 'mail_alert'),
      }, function(){
        app.fire('send', 'storage', {
          execute: 'add',
          name: 'mail-alert',
          value: true,
        }, function({error}){
          error && app.fire('error', error);
        });
      });
    });
    app.fire('send', 'analytics', {event:'mail-export'});
  });
  app.fire('mail');
});
