App.register('print', function(){
  const app = this;
  app.on('printchange', function(action){
    app.fire('send', 'analytics', {event:`print-${action}`});
  });
  if (navigator.userAgent.indexOf('Firefox') >= 0){
    // Firefox
    window.addEventListener('beforeprint', function(){
      app.fire('printchange', 'before');
    });
    window.addEventListener('afterprint', function(){
      app.fire('printchange', 'after');
    });
  } else {
    const mediaQueryList = window.matchMedia('print');
    mediaQueryList.addEventListener('change', function(mql){
      if(mql.matches){
        app.fire('printchange', 'before');
      } else {
        app.fire('printchange', 'after');
      }
    });
  }
  app.on('print', function(){
    window.print();
  });
  app.fire('print');
});
