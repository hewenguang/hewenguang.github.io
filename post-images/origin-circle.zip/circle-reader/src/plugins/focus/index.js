App.register('focus', ['utils', 'dom'], function(utils, dom){
  let root;
  const app = this;
  // 挂载样式
  document.documentElement.appendChild(dom.create('style', {
    textContent:`
      .circle-focus{
        background:#ddd !important;
        cursor:pointer !important;
        outline:3px dashed #777 !important;
      }
      .circle-focus-hide{
        opacity:0 !important;
        visibility:hidden !important;
      }
    `,
  }));

  function handleClick(event){
    // this._app.doAction('message-close');
    const target = event.target;
    if(utils.isElement(root)){
      !root.contains(target) && app.fire('focus-destory');
    } else {
      event.stopPropagation();
      event.preventDefault();
      target.classList.remove('circle-focus');
      document.removeEventListener('mouseover', handleMouseover);
      dom.parentExcept(target, function(node){node.classList.add('circle-focus-hide')});
      root = target;
    }
  }

  function handleMouseover(event){
    const target = event.target;
    const fromTarget = event.fromElement || event.relatedTarget;
    utils.isElement(fromTarget) && fromTarget.classList.remove('circle-focus');
    target.classList.add('circle-focus');
  }

  app.on('focus', function(){
    if(app.cache('running')){
      app.fire('message', {
        key: 'focus',
        type:'error',
        duration: 1,
        message: app.fire('i18n', 'focus_error'),
      });
      return;
    } else {
      app.fire('message', {
        key: 'focus',
        duration: 3,
        message: app.fire('i18n', 'focus_tips'),
      });
    }
    document.addEventListener('click', handleClick);
    document.addEventListener('mouseover', handleMouseover);
  });
  app.on('focus-destory', function(){
    document.removeEventListener('click', handleClick);
    document.removeEventListener('mouseover', handleMouseover);
    utils.each(document.querySelectorAll('.circle-focus, .circle-focus-hide'), function(node){
      node.classList.remove('circle-focus', 'circle-focus-hide');
    });
    root = null;
  });

  app.fire('focus');
});
