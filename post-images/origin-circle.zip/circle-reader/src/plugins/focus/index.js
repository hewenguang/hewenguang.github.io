App.register('focus', ['dom', 'choose'], function(dom){
  const app = this;
  app.on('focus', function(){
    if(app.cache('running')){
      app.fire('message', {
        key: 'focus',
        type:'error',
        duration: 1,
        message: app.fire('i18n', 'focus_error'),
      });
      return;
    }
    const destory = app.fire('choose', document.documentElement, function(node){
      destory();
      app.cache('node', {
        url: null,
        title: null,
        cover: null,
        article: node,
      });
      dom.ready(function(){
        app.fire('empty-anchor');
        if(app.has('empty-page')){
          app.fire('empty-page', function(){
            app.fire('render-page');
            app.fire('render');
          });
        } else {
          app.load('render');
        }
      });
    }, function(node){
      return !document.body.contains(node);
    });
    app.fire('send', 'storage', {
      execute:'get',
      name: 'focus-alert',
    }, function({error, data}){
      if(error || data){
        error && app.fire('error', error);
        return;
      }
      app.fire('message', {
        key: 'focus',
        btnText: app.fire('i18n', 'got_it'),
        message: app.fire('i18n', 'focus_tips'),
      }, function(){
        app.fire('send', 'storage', {
          execute: 'add',
          name: 'focus-alert',
          value: true,
        }, function({error}){
          error && app.fire('error', error);
        });
      });
    });
    app.fire('send', 'analytics', {event:'focus'});
  });
  app.fire('focus');
});
