import React from 'react';
import ReactDOM from 'react-dom';
import { notification, Button, ConfigProvider } from 'antd';
import 'antd/dist/antd.css';
import './index.less';

App.register('message', ['shadow', 'dom', 'utils'], function(shadow, dom){
  let root;
  const app = this;
  // 有展示再挂载
  function mount2dom(){
    root = dom.create('div', {className:'root'});
    shadow({
      style: [
        'plugins/antd/index.css',
        'plugins/message/index.css',
      ],
      onReady: function(shadowRoot){
        shadowRoot.appendChild(root);
      }
    });
    ReactDOM.render((
      <ConfigProvider componentSize="small">
        <div />
      </ConfigProvider>
    ), root);
  }

  app.on('message', function(options = {}, callback){
    !root && mount2dom();
    const type = options.type || 'open';
    const key = options.key || `_${Date.now()}`;
    const args = Object.assign({key, getContainer: () => root}, options);
    callback && (args.btn = (
      <Button
        size="small"
        type="primary"
        onClick={() => {
          notification.close(key);
          callback(key);
        }}
      >
        {args.btnText || app.fire('i18n', 'ok')}
      </Button>
    ));
    notification[type](args);
  });
});
