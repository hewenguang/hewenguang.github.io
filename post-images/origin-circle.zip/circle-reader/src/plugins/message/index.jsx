import React from 'react';
import ReactDOM from 'react-dom';
import { notification, Button, ConfigProvider } from 'antd';
import zhCN from 'antd/lib/locale/zh_CN';
import enGB from 'antd/lib/locale/en_GB';
import 'antd/dist/antd.css';
import './index.less';

App.register('message', ['shadow', 'dom', 'utils'], function(shadow, dom){
  const app = this;
  const root = dom.create('div', {className:'root'});
  const shadowRoot = shadow({
    root: document.documentElement,
    style: [
      'plugins/antd/index.css',
      'plugins/message/index.css',
    ],
  });
  shadowRoot.appendChild(root);
  app.on('message', function(options = {
    btnText: 'ok',
  }, callback){
    const type = options.type || 'open';
    const key = options.key || `_${Date.now()}`;
    const args = Object.assign({
      key,
      getContainer: () => root,
    }, options);
    callback && (args.btn = (
      <Button
        size="small"
        type="primary"
        onClick={() => {
          notification.close(key);
          callback(key);
        }}
      >
        {args.btnText}
      </Button>
    ));
    notification[type](args);
  });

  ReactDOM.render((
    <ConfigProvider
      componentSize="small"
      locale={app.i18n.getUILanguage() === 'zh-CN' ? zhCN : enGB}
    >
      <div />
    </ConfigProvider>
  ), root);
});
