export function loadImage(node){
  const width = node.naturalWidth;
  const height = node.naturalHeight;
  if(!node.classList.contains('tiny') && width > 100 && height > 100){
    dom.setAttr(node, 'action', 'zoom-in');
  }
}

export function openNewWindow(url) {
  window.open(url, '_blank');
}
