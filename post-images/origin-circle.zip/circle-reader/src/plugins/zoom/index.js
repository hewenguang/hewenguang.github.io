import Zoom from './class.zoom';
import toolbar from './toolbar';
import './index.less';

App.register('zoom', ['utils', 'dom'], function(utils, dom){
  const app = this;
  function init(node){
    const rect = node.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    if(!node.classList.contains('tiny')){
      (width > 100 || height > 100) && dom.setAttr(node, 'action', 'zoom-in');
    }
  }
  app.on('render-ready', function(blocks){
    utils.each(blocks, function(block){
      utils.each(block.querySelectorAll('img'), function(node){
        // 如果是链接图片则不做任何处理
        if(dom.tag(node.parentElement, 'a')){
          return;
        }
        node.complete && init(node);
        node.addEventListener('load', function(){
          init(node);
        });
      });
    });
  });
  const zoom = new Zoom(function(opened){
    app.fire('zoom', opened);
    app.fire(`${opened ? 'disable' : 'enable'}-scroll`);
  });
  app.on('click', function(node, event){
    if(!dom.tag(node, 'img') || !['zoom-in', 'zoom-out'].includes(dom.getAttr(node, 'action'))){
      return;
    }
    event.stopPropagation();
    if (event.metaKey || event.ctrlKey){
      app.fire('send', 'tab', {
        action: 'create',
        value: {
          url: node.src,
        },
      });
      app.fire('send', 'analytics', {event:'zoom-meta-exit'});
      return;
    }
    // 编辑过程
    if(app.cache('edit')){
      return;
    }
    zoom.start(node);
  });
  app.on('render-destory-done', function(){
    zoom.close();
  });
  app.on('srt-exitimg', function(){
    zoom.close();
  });
  app.on('zoom-in', function(node){
    zoom.start(node, true);
  });
  app.on('zoom-out', function(){
    zoom.close();
  });

  app.fire('insert-style', 'plugins/zoom/index.css');

  toolbar(app);
});
