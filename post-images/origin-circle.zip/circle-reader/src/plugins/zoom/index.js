import Zoom from './class.zoom';
import { loadImage, openNewWindow } from './utils';
import './index.less';

App.register('zoom', ['utils', 'dom'], function(utils, dom){
  const app = this;
  const zoom = new Zoom;
  app.fire('insert-style', 'plugins/zoom/index.css');
  app.on('click', function(node, event){
    if(!dom.tag(node, 'img') || !['zoom-in', 'zoom-out'].includes(dom.getAttr(node, 'action'))){
      return;
    }
    event.stopPropagation();
    if (event.metaKey || event.ctrlKey){
      return openNewWindow(node.src);
    }
    zoom.start(node);
  });
  app.on('scroll', function(){
    zoom.close();
  });
  app.on('keydown', function(key){
    key === 'escape' && zoom.close();
  });
  app.on('zoom', function(imgs){
    utils.each(imgs, function(node){
      // 如果是链接图片则不做任何处理
      if(dom.tag(node.parentElement, 'a')){
        return;
      }
      node.complete && loadImage(node);
      node.addEventListener('load', function(){
        loadImage(node);
      });
    });
  });
});
