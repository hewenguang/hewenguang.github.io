import { saveAs } from 'file-saver';
import parseFileName from 'parse-filename'

export default function(app){
  // 工具栏
  const root = app.fire('dom-root');
  if(!utils.isElement(root)){
    return;
  }
  const toolbar = dom.create('div', {
    className: 'zoom-toolbar',
    innerHTML: `
      <span role="button" tabindex="-1" class="icon download"><svg viewBox="64 64 896 896" focusable="false" width="1em" height="1em" fill="currentColor" aria-hidden="true"><path d="M505.7 661a8 8 0 0012.6 0l112-141.7c4.1-5.2.4-12.9-6.3-12.9h-74.1V168c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8v338.3H400c-6.7 0-10.4 7.7-6.3 12.9l112 141.8zM878 626h-60c-4.4 0-8 3.6-8 8v154H214V634c0-4.4-3.6-8-8-8h-60c-4.4 0-8 3.6-8 8v198c0 17.7 14.3 32 32 32h684c17.7 0 32-14.3 32-32V634c0-4.4-3.6-8-8-8z"></path></svg></span>
      <span role="button" tabindex="-1" class="icon arrows-alt"><svg viewBox="64 64 896 896" focusable="false" data-icon="arrows-alt" width="1em" height="1em" fill="currentColor" aria-hidden="true"><path d="M855 160.1l-189.2 23.5c-6.6.8-9.3 8.8-4.7 13.5l54.7 54.7-153.5 153.5a8.03 8.03 0 000 11.3l45.1 45.1c3.1 3.1 8.2 3.1 11.3 0l153.6-153.6 54.7 54.7a7.94 7.94 0 0013.5-4.7L863.9 169a7.9 7.9 0 00-8.9-8.9zM416.6 562.3a8.03 8.03 0 00-11.3 0L251.8 715.9l-54.7-54.7a7.94 7.94 0 00-13.5 4.7L160.1 855c-.6 5.2 3.7 9.5 8.9 8.9l189.2-23.5c6.6-.8 9.3-8.8 4.7-13.5l-54.7-54.7 153.6-153.6c3.1-3.1 3.1-8.2 0-11.3l-45.2-45z"></path></svg>
      </span>
      <span role="button" tabindex="-1" class="icon shrink"><svg viewBox="64 64 896 896" focusable="false" data-icon="shrink" width="1em" height="1em" fill="currentColor" aria-hidden="true"><path d="M881.7 187.4l-45.1-45.1a8.03 8.03 0 00-11.3 0L667.8 299.9l-54.7-54.7a7.94 7.94 0 00-13.5 4.7L576.1 439c-.6 5.2 3.7 9.5 8.9 8.9l189.2-23.5c6.6-.8 9.3-8.8 4.7-13.5l-54.7-54.7 157.6-157.6c3-3 3-8.1-.1-11.2zM439 576.1l-189.2 23.5c-6.6.8-9.3 8.9-4.7 13.5l54.7 54.7-157.5 157.5a8.03 8.03 0 000 11.3l45.1 45.1c3.1 3.1 8.2 3.1 11.3 0l157.6-157.6 54.7 54.7a7.94 7.94 0 0013.5-4.7L447.9 585a7.9 7.9 0 00-8.9-8.9z"></path></svg></span>
    `,
  });
  app.on('pure-before', function(){
    dom.setStyle(toolbar, 'display', 'none');
  });
  app.on('remove-img', function(){
    dom.setStyle(toolbar, 'display', 'none');
  });
  root.appendChild(toolbar);

  let timer;
  toolbar.addEventListener('mouseover', function(){
    if(!app.cache('running')){
      return;
    }
    timer && clearTimeout(timer);
  });
  toolbar.addEventListener('mouseout', function(){
    if(!app.cache('running')){
      return;
    }
    if(toolbar.classList.contains('enlarged')){
      return;
    }
    timer && clearTimeout(timer);
    timer = setTimeout(function(){
      toolbar.style.display = 'none';
    }, 200);
  });

  app.on('zoom', function(opened){
    if(opened){
      toolbar.style.removeProperty('top');
      toolbar.style.removeProperty('right');
      toolbar.classList.add('enlarged');
      toolbar.style.display = 'flex';
    } else {
      toolbar.style.display = 'none';
      toolbar.classList.remove('enlarged');
    }
  });
  app.on('click', function(node){
    if(!toolbar.contains(node) || !node.classList.contains('icon')){
      return;
    }
    const target = toolbar.mirrorElement;
    if(!utils.isElement(target)){
      return;
    }
    if(node.classList.contains('arrows-alt')){
      app.fire('zoom-in', target);
      app.fire('send', 'analytics', {event:'zoom-arrowsalt'});
    } else if(node.classList.contains('shrink')){
      app.fire('zoom-out', target);
      app.fire('send', 'analytics', {event:'zoom-shrink'});
    } else if(node.classList.contains('download')){
      const url = target.src;
      if(!url){
        return;
      }
      let filename = 'circle';
      if(url.indexOf('data:') !== 0) {
        const result = parseFileName({data:url,debug:app.cache('debug')});
        result && result.filename && (filename = result.filename);
      }
      saveAs(url, filename);
      app.fire('send', 'analytics', {event:'zoom-download'});
    }
  });
  app.on('mouseover', function(node){
    if(!dom.tag(node, 'img') || !node.classList.contains('large')){
      return;
    }
    if(node.classList.contains('enlarged')){
      return;
    }
    timer && clearTimeout(timer);
    const scrollX = window.scrollX;
    const scrollY = window.scrollY;
    const width = dom.clientWidth();
    const rect = node.getBoundingClientRect();
    toolbar.style.top = `${rect.top + scrollY + 8}px`;
    toolbar.style.right = `${width - rect.right - scrollX}px`;
    toolbar.style.display = 'flex';
    toolbar.mirrorElement = node;
  });
  app.on('mouseout', function(node){
    if(!dom.tag(node, 'img') || !node.classList.contains('large')){
      return;
    }
    if(node.classList.contains('enlarged')){
      return;
    }
    timer && clearTimeout(timer);
    timer = setTimeout(function(){
      toolbar.style.display = 'none';
    }, 200);
  });
}
