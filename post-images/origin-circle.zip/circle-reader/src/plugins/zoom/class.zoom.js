export default class Zoom{
  constructor(){
    this.offset = 80;
    this.opened = false;
  }

  start(node){
    this.node = node;
    const action = this.node.getAttribute('action');
    if(action === 'zoom-out'){
      this.close();
    } else {
      this.node.complete && this.init();
      this.node.addEventListener('load', () => {
        this.init();
      });
    }
  }

  init(){
    const nodeRect = this.node.getBoundingClientRect();
    this.nodeRect = {
      top: nodeRect.top,
      left: nodeRect.left,
      width: nodeRect.width,
      height: nodeRect.height,
      naturalWidth: this.node.naturalWidth,
      naturalHeight: this.node.naturalHeight,
    };
    this.open();
  }

  getOverlay(){
    if(!this.overlay){
      this.overlay = document.createElement('div');
      this.overlay.classList.add('zoom-overlay');
      this.overlay.addEventListener('click', () => {
        this.close();
      });
    }
    return this.overlay;
  }

  getScale() {
    let scale = 0;
    const nodeRect = this.nodeRect;
    const viewportWidth  = window.innerWidth - this.offset;
    const viewportHeight = window.innerHeight - this.offset;
    const viewportAspectRatio = viewportWidth / viewportHeight;
    const maxScaleFactor = nodeRect.naturalWidth / nodeRect.width;
    const imageAspectRatio = nodeRect.naturalWidth / nodeRect.naturalHeight;
    if (nodeRect.naturalWidth < viewportWidth && nodeRect.naturalHeight < viewportHeight) {
      scale = maxScaleFactor;
    } else if (imageAspectRatio < viewportAspectRatio) {
      scale = (viewportHeight / nodeRect.naturalHeight) * maxScaleFactor;
    } else {
      scale = (viewportWidth / nodeRect.naturalWidth) * maxScaleFactor;
    }
    return scale;
  }

  getTransform() {
    const nodeRect = this.nodeRect;
    const viewportX = window.innerWidth / 2;
    const viewportY = window.innerHeight / 2;
    const imageCenterY = nodeRect.top + nodeRect.height / 2;
    const imageCenterX = nodeRect.left + (nodeRect.width / 2);
    const translateY = Math.round(viewportY - imageCenterY);
    const translateX = Math.round(viewportX - imageCenterX);
    return `translate(${translateX}px, ${translateY}px) translateZ(0) scale(${this.getScale()})`;
  }

  open(){
    const node = this.node;
    const root = node.parentElement;
    node.setAttribute('action', 'zoom-out');
    node.style.transform = this.getTransform();
    root.appendChild(this.getOverlay());
    root.classList.add('zoom-open');
    this.opened = true;
  }

  close(){
    if(!this.opened){
      return;
    }
    const root = this.node.parentElement;
    root.classList.remove('zoom-open');
    this.node.style.transform = '';
    root.removeChild(this.getOverlay());
    this.node.setAttribute('action', 'zoom-in');
    this.opened = false;
  }
}
