export default function(app){
  // 工具栏
  const root = app.fire('dom-root');
  if(!utils.isElement(root)){
    return;
  }
  const toolbar = dom.create('div', {
    className: 'hljs-toolbar',
    innerHTML: `
      <span role="button" tabindex="-1" class="icon copy"><svg viewBox="64 64 896 896" focusable="false" width="1em" height="1em" fill="currentColor" aria-hidden="true"><path d="M832 64H296c-4.4 0-8 3.6-8 8v56c0 4.4 3.6 8 8 8h496v688c0 4.4 3.6 8 8 8h56c4.4 0 8-3.6 8-8V96c0-17.7-14.3-32-32-32zM704 192H192c-17.7 0-32 14.3-32 32v530.7c0 8.5 3.4 16.6 9.4 22.6l173.3 173.3c2.2 2.2 4.7 4 7.4 5.5v1.9h4.2c3.5 1.3 7.2 2 11 2H704c17.7 0 32-14.3 32-32V224c0-17.7-14.3-32-32-32zM350 856.2L263.9 770H350v86.2zM664 888H414V746c0-22.1-17.9-40-40-40H232V264h432v624z" /></svg></span>
      <span role="button" tabindex="-1" class="icon arrows-alt"><svg viewBox="64 64 896 896" focusable="false" data-icon="arrows-alt" width="1em" height="1em" fill="currentColor" aria-hidden="true"><path d="M855 160.1l-189.2 23.5c-6.6.8-9.3 8.8-4.7 13.5l54.7 54.7-153.5 153.5a8.03 8.03 0 000 11.3l45.1 45.1c3.1 3.1 8.2 3.1 11.3 0l153.6-153.6 54.7 54.7a7.94 7.94 0 0013.5-4.7L863.9 169a7.9 7.9 0 00-8.9-8.9zM416.6 562.3a8.03 8.03 0 00-11.3 0L251.8 715.9l-54.7-54.7a7.94 7.94 0 00-13.5 4.7L160.1 855c-.6 5.2 3.7 9.5 8.9 8.9l189.2-23.5c6.6-.8 9.3-8.8 4.7-13.5l-54.7-54.7 153.6-153.6c3.1-3.1 3.1-8.2 0-11.3l-45.2-45z"></path></svg>
      </span>
      <span role="button" tabindex="-1" class="icon shrink"><svg viewBox="64 64 896 896" focusable="false" data-icon="shrink" width="1em" height="1em" fill="currentColor" aria-hidden="true"><path d="M881.7 187.4l-45.1-45.1a8.03 8.03 0 00-11.3 0L667.8 299.9l-54.7-54.7a7.94 7.94 0 00-13.5 4.7L576.1 439c-.6 5.2 3.7 9.5 8.9 8.9l189.2-23.5c6.6-.8 9.3-8.8 4.7-13.5l-54.7-54.7 157.6-157.6c3-3 3-8.1-.1-11.2zM439 576.1l-189.2 23.5c-6.6.8-9.3 8.9-4.7 13.5l54.7 54.7-157.5 157.5a8.03 8.03 0 000 11.3l45.1 45.1c3.1 3.1 8.2 3.1 11.3 0l157.6-157.6 54.7 54.7a7.94 7.94 0 0013.5-4.7L447.9 585a7.9 7.9 0 00-8.9-8.9z"></path></svg></span>
    `
  });
  app.on('pure-before', function(){
    dom.setStyle(toolbar, 'display', 'none');
  });
  app.on('remove-pre', function(){
    dom.setStyle(toolbar, 'display', 'none');
  });
  root.appendChild(toolbar);

  let timer;
  toolbar.addEventListener('mouseover', function(){
    if(!app.cache('running')){
      return;
    }
    timer && clearTimeout(timer);
  });
  toolbar.addEventListener('mouseout', function(){
    if(!app.cache('running')){
      return;
    }
    if(toolbar.classList.contains('enlarged')){
      return;
    }
    timer && clearTimeout(timer);
    timer = setTimeout(function(){
      toolbar.style.display = 'none';
    }, 200);
  });

  app.on('srt-exitcode', function(){
    const target = toolbar.mirrorElement;
    if(!utils.isElement(target) || !target.classList.contains('enlarged')){
      return;
    }
    toolbar.style.display = 'none';
    toolbar.classList.remove('enlarged');
    target.classList.remove('enlarged');
    app.fire('enable-scroll');
  });
  app.on('click', function(node){
    if(!toolbar.contains(node) || !node.classList.contains('icon')){
      return;
    }
    const target = toolbar.mirrorElement;
    if(!utils.isElement(target)){
      return;
    }
    if(node.classList.contains('arrows-alt')){
      toolbar.style.removeProperty('top');
      toolbar.style.removeProperty('right');
      toolbar.classList.add('enlarged');
      target.classList.add('enlarged');
      app.fire('disable-scroll');
      app.fire('send', 'analytics', {event:'hljs-arrowsalt'});
    } else if(node.classList.contains('shrink')){
      toolbar.style.display = 'none';
      toolbar.classList.remove('enlarged');
      target.classList.remove('enlarged');
      app.fire('enable-scroll');
      app.fire('send', 'analytics', {event:'hljs-shrink'});
    } else if(node.classList.contains('copy')){
      const type = dom.copy(target) ? 'success' : 'fail';
      app.fire('message', {
        type,
        duration: 1,
        key: `copy_${type}`,
        message: app.fire('i18n', `copy_${type}`),
      });
      app.fire('send', 'analytics', {event:'hljs-copy'});
    }
  });
  app.on('mouseover', function(node){
    if(!node.classList.contains('hljs')){
      return;
    }
    if(node.classList.contains('enlarged')){
      return;
    }
    timer && clearTimeout(timer);
    const scrollX = window.scrollX;
    const scrollY = window.scrollY;
    const width = dom.clientWidth();
    const rect = node.getBoundingClientRect();
    toolbar.style.top = `${rect.top + scrollY + 8}px`;
    toolbar.style.right = `${width - rect.right - scrollX}px`;
    toolbar.style.display = 'flex';
    toolbar.mirrorElement = node;
  });
  app.on('mouseout', function(node){
    if(!node.classList.contains('hljs')){
      return;
    }
    if(node.classList.contains('enlarged')){
      return;
    }
    timer && clearTimeout(timer);
    timer = setTimeout(function(){
      toolbar.style.display = 'none';
    }, 200);
  });
}
