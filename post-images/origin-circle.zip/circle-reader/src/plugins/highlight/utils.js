export function escape(html){
  return `${html}`.replace(/[<>]/g, function(match) {
    switch(match){
      case '>':
        return '&gt;';
      case '<':
        return '&lt;';
    }
  });
}
