import highlight from 'highlight.js';
import toolbar from './toolbar';
import { escape } from './utils';
import './index.less';

App.register('highlight', ['dom', 'utils'], function(dom, utils){
  const app = this;

  app.fire('insert-style', 'plugins/highlight/index.css');

  app.on('render-ready', function(blocks){
    utils.each(blocks, function(block){
      // 代码高亮
      const codes = [];
      utils.each(block.querySelectorAll('code'), function(node){
        const target = node.mirrorElement || node;
        getComputedStyle(target).display === 'block' && codes.push(node);
      });
      // 考虑 pre>code 情况
      utils.each(block.querySelectorAll('pre'), function(node){
        const codeElement = node.getElementsByTagName('code');
        if(codes.includes(codeElement)){
          return;
        }
        const target = node.mirrorElement || node;
        getComputedStyle(target).display === 'block' && codes.push(node);
      });
      utils.each(codes, function(node){
        const target = node.mirrorElement || node;
        const code = target.getElementsByTagName('code');
        const value = dom.tag(node, 'pre') && code.length === 1 ? code[0].innerText : target.innerText;
        node.innerHTML = escape(value.replace('复制代码', ''));
        // 禁用翻译
        node.classList.add('notranslate');
        highlight.highlightBlock(node);
      });
    });
  });

  toolbar(app);
});
