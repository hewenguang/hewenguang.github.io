import { getContext, parserHref, parserAttrs } from './utils';

App.register('nextpage', ['dom', 'utils'], function(){
  const app = this;
  let iframe;
  let ready = false;
  let context = document;
  app.on('render-ready', function(){
    const links = context.getElementsByTagName('a');
    const url = parserHref(links) || parserAttrs(links);
    if(!url){
      return;
    }
    if(!iframe){
      iframe = getContext(function(doc){
        context = doc;
        const { url, title, article } = app.fire('parser', context, 'nextpage');
        if(utils.isElement(article)){
          const lastnode = app.cache('node');
          // 记录上一页的地址，退出时使用
          lastnode && lastnode.url && app.cache('lastnodeurl', lastnode.url);
          app.cache('node', {
            url,
            title,
            article,
            cover: app.fire('parser-cover', article),
          });
          ready = true;
        } else {
          app.fire('parser-fail');
        }
      });
    }
    iframe.src = url;
  });
  app.on('scroll', function(top){
    if(!ready || (top + dom.clientHeight() + 360 < document.documentElement.scrollHeight
    )){
      return;
    }
    ready = false;
    app.fire('render-page');
  });
  app.on('render-start-done', function(){
    const clientHeight = dom.clientHeight();
    const scrollHeight = document.documentElement.scrollHeight;
    if(!ready || (clientHeight > 100 && scrollHeight <= clientHeight)){
      return;
    }
    ready = false;
    app.fire('render-page');
  });
});
