import { getContext, parserHref, parserAttrs } from './utils';

App.register('nextpage', ['dom', 'utils'], function(){
  const app = this;
  let iframe;
  let ready = 'wait';
  let context = document;
  app.on('render-ready', function(){
    // 必须时运行状态，否则会和pjax 冲突
    if(!app.cache('running')){
      return;
    }
    const links = context.getElementsByTagName('a');
    const link = parserHref(links) || parserAttrs(links);
    if(!link){
      ready = 'wait';
      return;
    }
    if(!iframe){
      iframe = getContext(function(doc){
        if(!doc || !doc.URL || doc.URL === 'about:blank'){
          ready = 'wait';
          return;
        }
        context = doc;
        const { url, title, article } = app.fire('parser', context, 'nextpage');
        app.fire('spinning', false);
        if(utils.isElement(article)){
          app.cache('node', {
            url,
            title,
            article,
            cover: app.fire('parser-cover', article),
          });
          ready = 'done';
        } else {
          app.fire('parser-fail');
          ready = 'wait';
        }
      });
    }
    iframe.src = link;
    ready = 'running';
  });
  app.on('scroll', function(top){
    if(ready === 'wait'){
      return;
    }
    if(top + dom.clientHeight() + 360 < document.documentElement.scrollHeight){
      return;
    }
    if(ready === 'running'){
      app.fire('spinning', true);
      return;
    }
    ready = 'wait';
    app.fire('render-page');
    const lastnode = app.cache('node');
    // 记录上一页的地址，退出时使用
    lastnode && lastnode.url && app.cache('lastnodeurl', lastnode.url);
  });
  app.on('render-start-done', function(){
    if(ready === 'wait'){
      return;
    }
    const clientHeight = dom.clientHeight();
    const scrollHeight = document.documentElement.scrollHeight;
    if(clientHeight <= 0 || scrollHeight <= 0){
      return;
    }
    if(scrollHeight > clientHeight){
      return;
    }
    if(ready === 'running'){
      app.fire('spinning', true);
      return;
    }
    ready = 'wait';
    app.fire('render-page');
    const lastnode = app.cache('node');
    // 记录上一页的地址，退出时使用
    lastnode && lastnode.url && app.cache('lastnodeurl', lastnode.url);
  });
});
