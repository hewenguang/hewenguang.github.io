function each(value, callback){
  const keys = Object.keys(value);
  const length = keys.length;
  if(length <= 0){
    return;
  }
  let index = length - 1;
  while(index >= 0 && !callback(value[keys[index]], keys[index])){
    index--;
  }
}

export function getContext(callback){
  const iframe = dom.create('iframe', {
    sandbox: 'allow-scripts allow-same-origin allow-popups',
    style: {
      top: 0,
      left:0,
      zIndex: -1,
      opacity: 0,
      width: '100%',
      height: '100%',
      overflow: 'hidden',
      position: 'fixed',
      pointerEvents: 'none',
    }
  });
  iframe.addEventListener('load', function(){
    callback && callback(iframe.contentDocument);
  });
  document.documentElement.appendChild(iframe);
  return iframe;
}

export function parserHref(links){
  let maybeLink;
  const LinkREG = /下一|next/;
  const url = location.href;
  const host = location.host;
  each(links, function(link){
    const parent = link.parentElement;
    if(!dom.visible(link) || (link.host && (link.host !== host)) || !parent){
      return;
    }
    const linkText = dom.nodeText(link);
    const href = link.href;
    if(LinkREG.test(`${dom.getAttr(link)} ${linkText}`) && href !== url && !href.startsWith('javascript')){
      maybeLink = link;
      return true;
    }
    if(parent.childElementCount === 1 && LinkREG.test(dom.getAttr(parent))){
      maybeLink = link;
      return true;
    }
  });
  if(utils.isElement(maybeLink)){
    return maybeLink.href;
  }
}

export function parserAttrs(links){
  let maybeUrl;
  const host = location.host;
  each(links, function(link){
    const parent = link.parentElement;
    if(!parent || (link.host && (link.host !== host))){
      return;
    }
    const linkText = dom.nodeText(link);
    const attributes = dom.getAttr(link);
    if(!/下一/.test(linkText) && !/next/.test(attributes)){
      return;
    }
    //<a class="next" onclick="javascript:location.href='/Edward-Luce/2017_09_16_427358_2.shtml';">下一页</a>
    utils.each(link.attributes, attrValue => {
      const nodeValue = `${attrValue.nodeValue}`;
      if(nodeValue.split('/').length > 1){
        maybeUrl = nodeValue.replace(/.*('|")(.*?)('|").*/, '$2');
        return true;
      }
    });
    if(maybeUrl){
      return true;
    }
  });
  return maybeUrl;
}
