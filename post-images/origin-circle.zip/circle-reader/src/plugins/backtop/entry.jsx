import cx from 'classnames';
import React, { useState, useEffect } from 'react';

export default function(props){
  const { app } = props;
  const [ visible, setVisible ] = useState(false);

  useEffect(() => {
    app.on('scroll', function(top){
      setVisible(top > 500);
    });
  });

  return (
    <div
      className={cx('backtop', {visible})}
      onClick={() => {
        if(!visible){
          return;
        }
        window.scrollTo({
          top:0,
          left:0,
          behavior: 'smooth',
        });
        app.fire('send', 'analytics', {event:'backtop'});
      }}
    >
      <svg viewBox="0 0 1024 1024">
        <path d="M512 1024a512 512 0 1 1 512-512 512 512 0 0 1-512 512z m182.816-534.576L534.32 328.928c-0.352-0.336-0.816-0.448-1.168-0.768a31.888 31.888 0 0 0-7.584-5.04 30.4 30.4 0 0 0-4.96-1.792 31.616 31.616 0 0 0-4.8-0.944 31.072 31.072 0 0 0-10.96 0.592c-0.528 0.128-1.088 0.16-1.6 0.32a30.576 30.576 0 0 0-6.624 2.816c-0.688 0.384-1.296 0.864-1.952 1.296a30.288 30.288 0 0 0-5.312 3.52 30.288 30.288 0 0 0-3.312 4.976c-0.464 0.656-1.056 1.2-1.472 1.904L328.272 492.112a32 32 0 0 0 45.248 45.248L480 430.864V672a32 32 0 0 0 64 0V428.608L649.824 534.4a31.824 31.824 0 1 0 44.992-44.976z" />
      </svg>
    </div>
  );
}
