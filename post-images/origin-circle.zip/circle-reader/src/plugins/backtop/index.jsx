import React from 'react';
import ReactDOM from 'react-dom';
import Entry from './entry';
import './index.less';

App.register('backtop', ['shadow', 'dom'], function(shadow, dom){
  const app = this;
  const root = dom.create('div', {className:'root'});
  shadow({
    style: 'plugins/backtop/index.css',
    onReady: function(shadowRoot){
      shadowRoot.appendChild(root);
    }
  });
  app.on('theme', function(value, key){
    if(utils.isUndefined(value)){
      return;
    }
    utils.each(utils.isPlainObject(value) ? value : {
      [key]: value
    }, (style, styleKey) => {
      if(styleKey !== 'color'){
        return;
      }
      root.style.setProperty(`--${styleKey}`, style);
    });
  });
  app.on('render-start-done', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('render-destory-done', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-before', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-after', function(){
    dom.setStyle(root, 'display', 'block');
  });

  ReactDOM.render(<Entry app={app} />, root);
});
