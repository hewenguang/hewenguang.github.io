import React from 'react';
import ReactDOM from 'react-dom';
import Entry from './entry';
import './index.less';

App.register('backtop', ['shadow', 'dom'], function(shadow, dom){
  const app = this;
  const root = dom.create('div', {className:'root'});
  shadow({
    root: document.documentElement,
    style: 'plugins/backtop/index.css',
    onReady: function(shadowRoot){
      shadowRoot.appendChild(root);
    }
  });
  app.on('theme', function(value, key){
    utils.each(utils.isPlainObject(value) ? value : {
      [key]: value
    }, (style, styleKey) => {
      if(styleKey !== 'color'){
        return;
      }
      root.style.setProperty(`--${styleKey}`, style);
    });
  });
  app.on('render-start-done', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('render-destory-done', function(){
    dom.setStyle(root, 'display', 'none');
  });

  ReactDOM.render(<Entry app={app} />, root);
});
