import { saveAs } from 'file-saver';
import { stylesheets } from './utils';

App.register('word', ['utils', 'dom'], function(utils, dom){
  const app = this;
  const root = app.fire('dom-container');
  if(!root){
    return;
  }
  app.on('word', function(){
    let footer = '\n';
    const body = dom.traverse(root);
    utils.each(body.getElementsByTagName('img'), function(node){
      const target = node.mirrorElement || node;
      if(!dom.visible(target)){
        return;
      }
      dom.removeAttr(node, attributeName => !['class', 'src'].includes(attributeName));
      const width = Math.min(target.width, 410);
      node.width = width;
      node.height = target.height * (width / target.width);
      node.src = node.src.replace('https','http');
    });
    footer += '--NEXT.ITEM-BOUNDARY--';
    const content = `Mime-Version: 1.0\nContent-Base: ${location.href}\nContent-Type: Multipart/related; boundary="NEXT.ITEM-BOUNDARY";type="text/html"\n\n--NEXT.ITEM-BOUNDARY\nContent-Type: text/html; charset="utf-8"\nContent-Location: ${location.href}\n\n<!DOCTYPE html>\n<html xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns:m="http://schemas.microsoft.com/office/2004/12/omml" xmlns="http://www.w3.org/TR/REC-html40" xmlns="http://www.w3.org/1999/xhtml">\n<head>\n<meta http-equiv="Content-Type" content="text/html; charset=utf-8">\n<style>\n${stylesheets(app)}\n</style>\n<!--[if gte mso 9]><xml><w:WordDocument><w:View>Print</w:View><w:TrackMoves>false</w:TrackMoves><w:TrackFormatting/><w:ValidateAgainstSchemas/><w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid><w:IgnoreMixedContent>false</w:IgnoreMixedContent><w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText><w:DoNotPromoteQF/><w:LidThemeOther>EN-US</w:LidThemeOther><w:LidThemeAsian>ZH-CN</w:LidThemeAsian><w:LidThemeComplexScript>X-NONE</w:LidThemeComplexScript><w:Compatibility><w:BreakWrappedTables/><w:SnapToGridInCell/><w:WrapTextWithPunct/><w:UseAsianBreakRules/><w:DontGrowAutofit/><w:SplitPgBreakAndParaMark/><w:DontVertAlignCellWithSp/><w:DontBreakConstrainedForcedTables/><w:DontVertAlignInTxbx/><w:Word11KerningPairs/><w:CachedColBalance/><w:UseFELayout/></w:Compatibility><w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel><m:mathPr><m:mathFont m:val="Cambria Math"/><m:brkBin m:val="before"/><m:brkBinSub m:val="--"/><m:smallFrac m:val="off"/><m:dispDef/><m:lMargin m:val="0"/> <m:rMargin m:val="0"/><m:defJc m:val="centerGroup"/><m:wrapIndent m:val="1440"/><m:intLim m:val="subSup"/><m:naryLim m:val="undOvr"/></m:mathPr></w:WordDocument></xml><![endif]--></head>\n<body>${body.innerHTML}</body></html>${footer}`;
    saveAs(new Blob([content], {type:'application/msword;charset=utf-8'}), `${document.title || 'circle'}.doc`);
    app.fire('send', 'analytics', {event:'word-export'});
  });
  app.fire('word');
});
