export function stylesheets(app){
  let styles = `
  h1,h2,h3,h4,h5,h6{color:var(--color)}
  a{color:var(--link)}a:hover{color:var(--hover)}
  a:active{color:var(--visited)}
  a:visited{color:var(--visited)}
  .title a{color:var(--color)}
  .title a:hover{color:var(--link)}
  .footer{color:var(--color)}
  .root{margin:0;padding:1px;line-height:1.5715;font-size:var(--size);font-variant:tabular-nums;font-feature-settings:'tnum';font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'Helvetica Neue',Arial,'Noto Sans',sans-serif,'Apple Color Emoji','Segoe UI Emoji','Segoe UI Symbol','Noto Color Emoji'}
  h1{font-size:var(--title1);font-weight:var(--title1weight)}
  h2{font-size:var(--title2);font-weight:var(--title2weight)}
  h3{font-size:var(--title3);font-weight:var(--title3weight)}
  h4{font-size:var(--title4);font-weight:var(--title4weight)}
  h5{font-size:var(--title5);font-weight:var(--title5weight)}
  h6{font-size:var(--title6);font-weight:var(--title6weight)}
  h1,h2,h3,h4,h5,h6{text-indent:0}
  ol,ul{text-indent:0}
  pre,code,blockquote{text-indent:0}
  p,blockquote,ul,ol,dl,table,pre,section,figcaption,.block{margin:var(--blockspace) 0}
  .container{min-height:500px;max-width:var(--width);margin:var(--margin) auto}
  .page{margin-bottom:20px;word-break:break-word;font-size:var(--size);font-family:var(--font);line-height:var(--lineheight);text-indent:var(--indent);letter-spacing:var(--space);font-weight:var(--weight);text-align:var(--align);border-bottom:1px solid var(--color);color:var(--color);background:var(--canvas)}
  .page img{width:100%;height:auto;display:var(--imagehide)}
  .page img.tiny{position:relative;top:-2px}
  .page img.large{margin-top:var(--blockspace);margin-bottom:var(--blockspace);margin-left:var(--imageleft);margin-right:var(--imageright)}
  .page .cover{max-width:calc(100%+160px);margin:-80px -80px 16px}
  .page .cover img{margin:0;width:100%}
  .page .title{text-indent:0;text-align:var(--titlealign);margin-bottom:var(--blockspace)}
  .page-block{padding:40px;column-gap:var(--columngap);column-count:var(--columncount);margin-bottom:100px}
  .page-block p,.page-block blockquote,.page-block ul,.page-block ol,.page-block dl,.page-block table,.page-block pre,.page-block section,.page-block .block{page-break-inside:avoid;break-inside:avoid-column}
  `;
  const root = app.fire('dom-root');
  root.style.cssText.split(';').forEach(function(item){
    const style = item.trim();
    if(!style.startsWith('--')){
      return;
    }
    const [ key, value ] = style.split(':');
    styles = styles.replace(new RegExp(`var(${key})`, 'g'), value);
  });
  return styles;
}
