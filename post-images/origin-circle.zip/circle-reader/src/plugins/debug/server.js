App.register('debug', function(){
  const app = this;
 
  const filesInDirectory = dir => new Promise(resolve =>
    dir.createReader().readEntries(entries =>
      Promise.all(entries.filter(e => e.name[0] !== '.').map(e => (
        e.isDirectory
          ? filesInDirectory(e)
          : new Promise(resolvePromise => e.file(resolvePromise)))))
        .then(files => [].concat(...files))
        .then(resolve)));

  const timestampForFilesInDirectory = dir =>
    filesInDirectory(dir).then(files =>
      files.map(f => f.name + f.lastModifiedDate).join());

  const reload = () => {
    app.tabs.query({ active: true, currentWindow: true }, tabs => {
      // app.runtime.reload();
      if (tabs[0]) {
        app.tabs.reload(tabs[0].id);
      }
    });
  };

  const watchChanges = (dir, lastTimestamp) => {
    timestampForFilesInDirectory(dir).then((timestamp) => {
      if (!lastTimestamp || (lastTimestamp === timestamp)) {
        setTimeout(() => watchChanges(dir, timestamp), 1000);
      } else {
        watchChanges(dir, timestamp);
        reload();
      }
    });
  };

  app.runtime.getPackageDirectoryEntry && app.runtime.getPackageDirectoryEntry(dir => watchChanges(dir));
});
