App.register('debug', function(){
  this.on('error', function(error){
    console.log('--- circle error ---');
    console.log(error);
    console.log('--- circle error ---');
  });
});
