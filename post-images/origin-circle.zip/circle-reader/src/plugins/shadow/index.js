App.register('shadow', 'dom', function(dom){
  const app = this;
  return function({
    style,
    onReady,
    mode = 'closed',
    root = document.body,
    delegatesFocus = false,
  } = {}){
    const host = dom.create('div');
    root.appendChild(host);
    const shadowRoot = host.attachShadow({ mode, delegatesFocus });
    if(style){
      const stylesheet = Array.isArray(style) ? style : [style];
      const stylesheetLength = stylesheet.length;
      stylesheet.forEach(function(url, index){
        const item = dom.create('link', {
          rel:'stylesheet',
          href:app.runtime.getURL(url),
        });
        index >= stylesheetLength - 1 && item.addEventListener('load', function(){
          onReady && onReady(shadowRoot, host);
        });
        shadowRoot.appendChild(item);
      });
    } else {
      onReady && onReady(shadowRoot, host);
    }
    return shadowRoot;
  };
});
