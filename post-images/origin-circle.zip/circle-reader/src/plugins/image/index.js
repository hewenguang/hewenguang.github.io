import { saveAs } from 'file-saver'

App.register('image', 'html2canvas', function(){
  const app = this;

  function export_image(){
    app.fire('html2canvas', function(canvas){
      canvas.toBlob(function(blob) {
        saveAs(blob, `${document.title || 'circle'}.png`);
        app.fire('send', 'analytics', {event:'image-export'});
      });
    });
  }

  app.on('image', function(){
    app.fire('send', 'storage', {
      execute:'get',
      name: 'export-image-alert',
    }, function({error, data}){
      if(error){
        app.fire('error', error);
        return;
      }
      if(data){
        export_image();
      } else {
        app.fire('message', {
          type: 'warn',
          duration: null,
          key: 'export_image',
          onClose: export_image,
          btnText: app.fire('i18n', 'got_it'),
          message: app.fire('i18n', 'export_image_alert'),
        }, function(){
          app.fire('send', 'storage', {
            value: true,
            execute: 'add',
            name: 'export-image-alert',
          }, function({error}){
            if(error){
              app.fire('error', error);
              return;
            }
            export_image();
          });
        });
      }
    });
  });
  app.fire('image');
});
