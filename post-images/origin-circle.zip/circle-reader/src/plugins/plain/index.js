import marked from 'marked';

App.register('plain', ['utils', 'dom'], function(utils, dom){
  let retry = 0;
  const app = this;

  app.on('parser-done', function(article, title, url){
    if(!article || !title){
      return;
    }
    app.fire('send', 'status', {
      action: 'wait',
    });
    app.cache('node', {
      url,
      title,
      article,
    });
    // 自动开启
    app.fire('send', 'db', {
      execute:'get',
      table: 'wrench',
      name:'autorun',
    }, function({error, data}){
      if(error){
        app.fire('error', error);
      } else {
        if(data){
          dom.ready(function(){
            app.load('render');
          });
        } else {
          // 白名单
          app.fire('send', 'db', {
            execute:'get',
            table: 'whitelist',
            name:location.hostname,
          }, function({error, data = []}){
            if(error){
              app.fire('error', error);
              return;
            }
            let render = false;
            const href = location.href;
            utils.each(data, item => {
              const url = item.url;
              if((url === href) || (!url.includes('/') && href.split(url).length > 1)){
                render = true;
                return true;
              }
            });
            render && dom.ready(function(){
              app.load('render');
            });
          });
        }
      }
    });
  });
  app.on('parser', function(context){
    if(!context){
      return {};
    }
    const maybeNode = context.firstElementChild;
    const url = decodeURIComponent(location.href);
    const maybeExt = url.substr(url.lastIndexOf('.'));
    const markdown = utils.isString(maybeExt) && maybeExt.startsWith('.md');
    const current = dom.tag(maybeNode, 'pre') ? maybeNode : context;
    const path = url.split(maybeExt).shift() || '';
    const title = document.title || `${path.substr(path.lastIndexOf('/') + 1)}`;

    return {
      url,
      title,
      article: dom.create('div', {
        innerHTML: markdown ? marked(current.innerHTML) : current.innerHTML.replace(/\n/g, '<br />'),
      }),
    };
  });
  app.on('parser-start', function(context){
    const { url, title, article } = app.fire('parser', context);
    if(utils.isElement(article)){
      retry = 0;
      app.fire('parser-done', article, title, url);
      return;
    }
    utils.wait(function(){
      if(retry < 5){
        retry++;
        app.fire('parser-start', context);
      } else {
        retry = 0;
        app.fire('parser-fail');
      }
    });
  });
  app.fire('parser-start', document.body);
});
