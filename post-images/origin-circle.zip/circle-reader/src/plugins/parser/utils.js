import {
  UNLIKE_ROLES,
  LIKE_ELEMENTS,
  NOISE_ELEMENTS,
  MINI_FONT_SIZE,
  NODE_NOT_PARENT,
  NODE_MAYBE_PARENT,
  MAYBE_LIKE_ELEMENTS,
  TEXTNODE_PUNCTUATIONS,
  BASIC_FEATURES_ELEMENTS,
  ENHANCED_FEATURES_ELEMENTS,
} from './config';

export function commonText(str1, str2){
  if (
    !utils.isString(str1) ||
    !utils.isString(str2) ||
    str1.length < 0 ||
    str2.length < 0
  ) {
    return '';
  }
  if (str1.length > str2.length) {
    const temp = str1;
    str1 = str2;
    str2 = temp;
  }
  const len1 = str1.length;
  for (let j = len1; j > 0; j--) {
    for (let i = 0; i < len1 - j; i++) {
      const current = str1.substr(i, j + 1);
      if (str2.indexOf(current) >= 0) {
        return current;
      }
    }
  }
  return '';
}

export function filterNode(node){
  if(!dom.visible(node)){
    return true;
  }
  const nodeStyle = window.getComputedStyle(node);
  const maybeFontSize = parseInt(nodeStyle.fontSize);
  const fontSize = utils.isNumber(maybeFontSize) ? maybeFontSize : MINI_FONT_SIZE;
  if(fontSize <= MINI_FONT_SIZE){
    return true;
  }
  if(node.getElementsByTagName('a').length > 1){
    return true;
  }
  return false;
}

export function highestScore(node, score, callback){
  // 只对第一层做判断 https://www.guancha.cn/Edward-Luce/2017_09_16_427358.shtml
  utils.each(dom.parents(node, 4, (item, itemIndex) => {
    if(itemIndex <= 0){
      // LIKE_ELEMENTS.test(`${item.className} ${item.id}`) https://page.om.qq.com/page/OLK3MWsrtVhiV3fPVfxqSGDQ0
      return NODE_MAYBE_PARENT.test(item.nodeName) || LIKE_ELEMENTS.test(`${item.className} ${item.id}`);
    } else{
      return !NODE_NOT_PARENT.test(item.nodeName);
    }
  }), function(parent, level){
    if (UNLIKE_ROLES.includes(dom.getAttr(parent, 'role'))){
      return;
    }
    const matchString = `${parent.className} ${parent.id}`;
    if(NOISE_ELEMENTS.test(matchString)){
      return;
    }
    // console.log('---- node --> ', node);
    const matchStringWidthNodeName = `${parent.tagName} ${matchString}`;
    if(LIKE_ELEMENTS.test(matchStringWidthNodeName)){
      score += 2;
    }
    if(MAYBE_LIKE_ELEMENTS.test(matchStringWidthNodeName)){
      score += 1;
    }
    !utils.isNumber(parent.score) && (parent.score = 0);
    parent.score += score / (level < 2 ? level + 2 : level * 3);
    // dom.setAttr(parent, 'p-score', parent.score);
    callback && callback(parent);
  });
}

export function calculateImgScore(node){
  let score = 0;
  if(!dom.visible(node)){
    return score;
  }
  const width = node.width;
  const height = node.height;
  const naturalWidth = node.naturalWidth;
  const naturalHeight = node.naturalHeight;
  if(width > 500 && height > 300 && naturalWidth > 800 && naturalHeight > 500){
    score += naturalWidth / 500;
  }
  return score;
}

export function calculateNodeScore(node){
  let score = 1;
  const text = dom.nodeText(node);
  score += text.split(TEXTNODE_PUNCTUATIONS).length;
  score += Math.min(Math.floor(utils.length(text) / 100), 3);
  // 加强文本特征
  const elementName = (utils.isTextNode(node) ? node.parentElement : node).nodeName.toLowerCase();
  if(BASIC_FEATURES_ELEMENTS.includes(elementName)){
    score += 1;
  }
  if(ENHANCED_FEATURES_ELEMENTS.includes(elementName)){
    score += 2;
  }
  node.score = score;
  return node.score;
}

export function eachNodeText(context, acceptNode, callback){
  const walker = document.createNodeIterator(context, NodeFilter.SHOW_TEXT, {
    acceptNode(textNode){
      return acceptNode(textNode) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    }
  });
  let nextNode;
  // eslint-disable-next-line
  while(nextNode = walker.nextNode()){
    callback(nextNode);
  }
}
