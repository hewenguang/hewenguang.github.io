export const MINI_FONT_SIZE = 12;
export const MINI_TEXTNODE_LENGTH = 10;
export const MINI_ARTICLE_AREA = 172000;
export const MINI_COMMON_TEXT_LENGTH = 3;
export const MAX_DISTANCE_FROM_TOP = 1800;
export const MINI_DISTANCE_ARTICLE_AND_TITLE = 600;

export const NODE_NOT_PARENT = /span|p/i;
export const MAYBE_LIKE_ELEMENTS = /body|hentry|main/i;
//section https://mp.weixin.qq.com/s/zbcMXoJLG2ied3Ei82noaA
export const NODE_MAYBE_PARENT = /div|article|body|main/i;
// body https://www.cnblogs.com/Wayou/p/js_audio_recorder.html
export const LIKE_ELEMENTS = /article|body|post|content|entry/i;
export const TEXTNODE_PUNCTUATIONS = /：|。|；|，|,|\.|\?|、|“|“/;
export const NOISE_ELEMENTS = /comment|meta|replies|reply|footer|footnote|noise/;

export const BASIC_FEATURES_ELEMENTS = [
  'table',
];
export const TITLE_SELECTOR = [
  'h1',
  'h2',
];
// body 会导致失败 https://www.marxists.org/chinese/linbiao/mia-chinese-linbiao-193711.htm
export const TEXTNODE_TAG_TO_IGNORE = [
  'a',
  'style',
  'script',
  'button',
];
export const ENHANCED_FEATURES_ELEMENTS = [
  'h2',
  'h3',
  'h4',
  'em',
  'strong',
];
export const UNLIKE_ROLES = [
  'feed',
  'menu',
  'menubar',
  'dialog',
  'alert',
  'alertdialog',
  'navigation',
  'complementary',
];
export const MAYBE_TITLE_SELECTOR = [
  'h1',
  'h2',
  'h3',
  '[id*="title"]',
  '[id*="Title"]',
  '[class*="title"]',
  '[class*="Title"]',
  '[id*="headline"]',
  '[class*="headline"]',
];
