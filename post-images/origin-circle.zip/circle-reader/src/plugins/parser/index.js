import {
  commonText,
  filterNode,
  eachNodeText,
  highestScore,
  calculateImgScore,
  calculateNodeScore,
} from './utils';

import {
  TITLE_SELECTOR,
  MINI_ARTICLE_AREA,
  MAYBE_TITLE_SELECTOR,
  MINI_TEXTNODE_LENGTH,
  MAX_DISTANCE_FROM_TOP,
  TEXTNODE_PUNCTUATIONS,
  TEXTNODE_TAG_TO_IGNORE,
  MINI_COMMON_TEXT_LENGTH,
  ENHANCED_FEATURES_ELEMENTS,
  MINI_DISTANCE_ARTICLE_AND_TITLE,
} from './config';

App.register('parser', ['utils', 'dom'], function(utils, dom){
  let retry = 0;
  const app = this;

  // 获取页面 title
  app.on('title-adjust', function(){
    const title = document.title;
    if(!title){
      return;
    }
    return title.replace(/(.*)[|\-\\/>»] .*/gi, '$1');
  });
  app.on('parser-title', function(context, article){
    let maybeNode;
    let maybeNodeCounter = 0;
    // 标题规则（直接找正文顶部，指定范围不存在再去执行之前的逻辑） 100 -200 h1 h2
    const articleRect = dom.position(article);
    utils.each(context.body.querySelectorAll(TITLE_SELECTOR.join(',')), function(node){
      if(filterNode(node)){
        return;
      }
      // 标题需要在一个合理的长度才认为有效
      const nodeText = dom.nodeText(node);
      if(utils.length(nodeText) > 100 || utils.length(nodeText) < 4){
        return true;
      }
      const nodeRect = dom.position(node);
      const distanceX = Math.abs(articleRect.left - nodeRect.left);
      const distanceY = articleRect.top - nodeRect.top;
      // console.log('title', article, articleRect, node, nodeRect, distanceX, distanceY);
      // 标题在内容区域且存在补白，如：https://page.om.qq.com/page/OLK3MWsrtVhiV3fPVfxqSGDQ0
      if(distanceX < 80 && distanceY > 0 && distanceY <= 400){
        maybeNodeCounter++;
        maybeNode = node;
      }
    });
    if(maybeNodeCounter === 1 && utils.isElement(maybeNode)){
      return maybeNode;
    }
    // 常规查询
    let maybeNodeSize = 0;
    const title = context.title;
    if(!title){
      // https://mp.weixin.qq.com/s/Q9YR9AAL6iFTNN0V6T_snQ
      // console.log('---titile empty');
      return;
    }
    utils.each(context.body.querySelectorAll(MAYBE_TITLE_SELECTOR.join(',')), function(node){
      if(filterNode(node)){
        return;
      }
      // 标题需要在一个合理的长度才认为有效
      const nodeText = dom.nodeText(node);
      if(utils.length(nodeText) > 100){
        return true;
      }
      const size = commonText(title, nodeText).length;
      if(size < MINI_COMMON_TEXT_LENGTH){
        return;
      }
      if(maybeNodeSize < size){
        maybeNodeSize = size;
        maybeNode = node;
      }
    });
    if(!utils.isElement(maybeNode)){
      return;
    }
    // 计算位置信息 https://jelly.jd.com/article/6006b1045b6c6a01506c87f2
    return maybeNode;
  });
  app.on('parser-cover', function(article){
    let maybeNode;
    const context = article.ownerDocument;
    if(!context){
      return maybeNode;
    }
    const nodes = context.getElementsByTagName('img');
    if(nodes.length <= 0){
      return maybeNode;
    }
    const articleRect = dom.position(article);
    const articleRectTop = articleRect.top;
    utils.each(nodes, function(node){
      if(!dom.visible(node)){
        return;
      }
      const rect = dom.position(node);
      if(rect.top >= articleRectTop){
        return true;
      }
      if(rect.width > articleRect.width * 0.8){
        maybeNode = node;
        return true;
      }
    });
    return maybeNode;
  });
  app.on('parser-article', function(context, action){
    let maybeNode;
    let maybeScore = 0;
    let textCounter = 0;
    // 图片加权
    utils.each(context.body.querySelectorAll('img'), function(node){
      const score = calculateImgScore(node);
      if(score <= 0){
        return;
      }
      textCounter++;
      highestScore(node, score);
    });
    // 文本加权
    const paragraph = [];
    eachNodeText(context.body, function(node){
      const element = node.parentElement;
      if(!dom.visible(element)){
        return;
      }
      const elementName = element.nodeName.toLowerCase();
      if(TEXTNODE_TAG_TO_IGNORE.includes(elementName)){
        return;
      }
      const text = node.nodeValue.trim();
      if(text.split(TEXTNODE_PUNCTUATIONS).length <= 2){
        return;
      }
      const size = utils.length(text);
      if(ENHANCED_FEATURES_ELEMENTS.includes(elementName) && size > 4){
        return true;
      }
      if(size < MINI_TEXTNODE_LENGTH){
        return;
      }
      return true;
    }, function(text){
      paragraph.push(text);
    });
    paragraph.length <= 2 && utils.each(document.querySelectorAll('p'), function(node){
      paragraph.push(node);
    });
    if(paragraph.length <= 0){
      return;
    }
    utils.each(paragraph, function(node){
      const score = calculateNodeScore(node);
      if(score <= 0){
        return;
      }
      textCounter++;
      highestScore(node, score, function(item){
        if(maybeScore < item.score){
          maybeScore = item.score;
          maybeNode = item;
        }
      });
    });
    const size = utils.length(dom.nodeText(maybeNode));
    if(!maybeNode || maybeScore < 30 || textCounter < 4 || size < 100){
      // console.log('--article-', textCounter, maybeScore, maybeNode, utils.length(dom.nodeText(maybeNode)));
      return;
    }
    const rect = dom.position(maybeNode);
    if(action !=='nextpage' && rect.top > MAX_DISTANCE_FROM_TOP){
      // console.log('--fail--', maybeNode, rect.top, MAX_DISTANCE_FROM_TOP, rect);
      maybeNode.classList.add('noise');
      return;
    }
    // 宽高比例会导致大屏失败
    if(rect.width * rect.height < MINI_ARTICLE_AREA){
      // console.log('-rect--', rect, maybeNode);
      maybeNode.classList.add('noise');
      return;
    }
    const parentElement = maybeNode.parentElement;
    if(!parentElement){
      maybeNode.classList.add('noise');
      return;
    }
    // 溢出判断 https://www.youtube.com/watch?v=Rviv0IUxYD4
    const parentRect = dom.position(parentElement);
    if(parentRect.width * parentRect.height < MINI_ARTICLE_AREA){
      // console.log('-overflow--', parentRect, maybeNode);
      maybeNode.classList.add('noise');
      return;
    }
    // 300 需要判断小屏幕
    if(context.documentElement.offsetWidth > 800 && (rect.width < 300 || parentRect.width < 300)){
      // console.log('-lt 300--', rect, parentRect);
      maybeNode.classList.add('noise');
      return;
    }
    const divs = maybeNode.getElementsByTagName('div');
    // div 少不做链接判断
    if(divs.length < 2){
      return maybeNode;
    }
    // 对链接密度做限制
    const links = maybeNode.getElementsByTagName('a');
    // 维基百科 0.31 左右
    if(links.length > 16 && dom.linkDensity(maybeNode) > 0.35){
      // console.log('linkDensity --->', links.length, dom.linkDensity(maybeNode));
      return;
    }
    return maybeNode;
  });
  app.on('article-adjust', function(title, article){
    if(!utils.isElement(article)){
      return true;
    }
    // 导读导致距离太远 https://www.guancha.cn/wuxu2/2021_04_12_587052.shtml
    if(/article|post|content/i.test(`${article.className} ${article.id}`)){
      return true;
    }
    if(article.contains(title)){
      return true;
    }
    const titleRect = dom.position(title);
    const articleRect = dom.position(article);
    if(Math.abs(articleRect.top - (titleRect.top + titleRect.height / 2)) < MINI_DISTANCE_ARTICLE_AND_TITLE){
      return true;
    }
  });
  app.on('parser-done', function(article, title, url){
    // title 见 https://mp.weixin.qq.com/s/Q9YR9AAL6iFTNN0V6T_snQ
    if(!article){
      return;
    }
    app.fire('send', 'status', {action: 'wait'});
    app.cache('node', {
      url,
      title,
      article,
      cover: app.fire('parser-cover', article),
    });
    const hash = location.hash;
    if(hash.endsWith('circle=off')){
      const noHashURL = window.location.href.replace(/#.*$/, '');
      window.history.replaceState('', document.title, noHashURL);
    } else if(hash.endsWith('circle=on')){
      const noHashURL = window.location.href.replace(/#.*$/, '');
      window.history.replaceState('', document.title, noHashURL);
      dom.ready(function(){
        app.load('render');
      });
    } else {
      // 自动开启
      app.fire('send', 'db', {
        execute:'get',
        table: 'wrench',
        name:'autorun',
      }, function({error, data}){
        if(error){
          app.fire('error', error);
        } else {
          if(data){
            dom.ready(function(){
              app.load('render');
            });
          } else {
            // 白名单
            app.fire('send', 'db', {
              execute:'get',
              table: 'whitelist',
              name:location.hostname,
            }, function({error, data = []}){
              if(error){
                app.fire('error', error);
                return;
              }
              let render = false;
              const href = location.href.replace(/#.*$/, '');
              utils.each(data, item => {
                const url = item.url;
                if(url === href || href.split(url).length > 1){
                  render = true;
                  return true;
                }
              });
              render && dom.ready(function(){
                app.load('render');
              });
            });
          }
        }
      });
    }
  });
  app.on('parser', function(context, action){
    if(!context){
      return {};
    }
    const article = app.fire('parser-article', context, action);
    if(!utils.isElement(article)){
      return {};
    }
    const title = app.fire('parser-title', context, article);
    const url = context.URL.startsWith('http') ? context.URL : location.href;
    // console.log('---parser', article, title, url);
    if(!utils.isElement(title)){
      return {
        url,
        article,
        title: app.fire('title-adjust'),
      };
    }
    // 水平距离判断 https://huajiakeji.com/accessibility/2019-08/1001.html
    const titleRect = dom.position(title);
    const articleRect = dom.position(article);
    if(Math.abs(articleRect.left - titleRect.left) >= articleRect.width){
      return {
        url,
        article,
        title: app.fire('title-adjust'),
      };
    }
    let maybeArticle = article;
    while(!app.fire('article-adjust', title, maybeArticle)){
      if(dom.tag(maybeArticle, 'body')){
        break;
      }
      maybeArticle = maybeArticle.parentElement;
    }
    return {
      url,
      title,
      article: maybeArticle,
    };
  });
  app.on('parser-start', function(context){
    const { url, title, article } = app.fire('parser', context);
    if(utils.isElement(article)){
      retry = 0;
      app.fire('parser-done', article, title, url);
      return;
    }
    utils.wait(function(){
      if(retry < 5){
        retry++;
        app.fire('parser-start', context);
      } else {
        retry = 0;
        app.fire('parser-fail');
      }
    });
  });
  app.fire('parser-start', document);
});
