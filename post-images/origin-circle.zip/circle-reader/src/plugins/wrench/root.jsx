import React, { useState, useEffect } from 'react';
import { ConfigProvider } from 'antd';
import { AppContext } from 'app/context';
import zhCN from 'antd/lib/locale/zh_CN';
import enGB from 'antd/lib/locale/en_GB';
import Drawer from 'app/components/drawer';
import Entry from './entry';

export default function(props){
  const { app, container } = props;
  const option = app.cache('env') === 'option';
  const [ root, setRoot ] = useState(container);
  const [ visible, setVisible ] = useState(true);

  useEffect(() => {
    app.cache('module_setting') && app.fire('setting', false);
  }, []);

  useEffect(() => {
    const hook = app.on('wrench', function(hidden){
      const nextVisible = !utils.isUndefined(hidden) ? hidden : !visible;
      nextVisible && app.cache('module_setting') && app.fire('setting', false);
      setVisible(nextVisible);
    });
    return () => {
      app.remove(hook);
    };
  }, [ visible ]);

  useEffect(() => {
    app.fire('insert-style', `
      .wrench{
        padding-right: 300px;
      }
    `, true);
  }, []);

  useEffect(() => {
    const rootElement = app.fire('dom-root');
    if(!rootElement){
      return;
    }
    if(visible){
      rootElement.classList.add('wrench');
    } else {
      rootElement.classList.remove('wrench');
    }
  }, [ visible ]);

  return (
    <AppContext.Provider value={app}>
      <ConfigProvider
        componentSize="small"
        getPopupContainer={() => root}
        locale={app.i18n.getUILanguage() === 'zh-CN' ? zhCN : enGB}
      >
        <Drawer
          visible={visible}
          className="wrench"
          disabled={option}
          onClose={() => setVisible(false)}
          getRoot={target => !option && setRoot(target)}
        >
          <Entry />
        </Drawer>
      </ConfigProvider>
    </AppContext.Provider>
  );
}
