App.register('wrench', ['utils', 'user', 'database'], function(utils){
  let last = {}; // 缓存数据的副本，用来计算变化
  let cache = {}; // 缓存的配置数据
  let count = 10; // 10 步则同步服务
  const app = this;
  let ready = true;
  let changed = 1623917840040;
  const tables = app.cache('db_tables');
  const sync = (skip) => {
    !skip && (changed = +(new Date));
    if(count > 0){
      count--;
      return;
    }
    count = 10;
    if(utils.isEqualObject(last, cache)){
      return;
    }
    last = cache;
    app.fire('sync');
  };

  app.on('db_add', function(table, name, value, skip){
    !cache[table] && (cache[table] = {});
    if(utils.isBoolean(value) || value === 0 || value){
      cache[table][name] = value;
      // 开启则同步一次
      if(value && table === 'wrench' && name === 'autosync'){
        app.fire('sync');
      } else {
        sync(skip);
      }
    }
  });
  app.on('db_remove', function(table, name, skip){
    if(!cache[table] || !cache[table][name]){
      return;
    }
    const value = cache[table][name];
    if(utils.isBoolean(value) || value === 0 || value){
      delete cache[table][name];
      sync(skip);
    }
  });
  // 配置同步
  app.on('sync', function({callback} = {}){
    if(!ready){
      return;
    }
    ready = false;
    app.fire('db', {
      request:{
        execute: 'get',
        table: 'wrench',
        name: 'autosync',
      },
      callback: function(error, data){
        // 错误 or 没有开启
        if(error || !data){
          ready = true;
          callback && callback(error ? error : null);
          return;
        }
        const user = app.cache('user');
        // console.log('-user--', user, changed);
        // 没有登录则返回
        if(!user){
          ready = true;
          callback && callback(app.fire('i18n', 'please_login'));
          return;
        }
        if(!user.config || (user.changed && changed > user.changed)){
          // console.log('--remote-');
          changed = +(new Date);
          // 写入配置
          app.fire('user_config', {
            changed,
            config: cache,
          }, function(error){
            ready = true;
            callback && callback(error);
          });
          return;          
        }
        // console.log('--local diff---', cache, user.config);
        if(utils.isEqualObject(cache, user.config)){
          ready = true;
          callback && callback();
        } else {
          // console.log('--local---');
          // 线上配置较新且不同于本地
          app.fire('import', {
            request: {
              data: user.config,
            },
            callback: function(error, data){
              ready = true;
              callback && callback(error, data);
            },
          });
        }
      }
    });
  });
  // 配置导出
  app.on('export', function({callback}){
    Promise.all(tables.map(table => new Promise((resolve, reject) => {
      app.fire('db', {
        request: {
          table,
          execute: 'all',
        },
        callback: function(error, data){
          if(error){
            reject(error);
          } else {
            resolve({[table]:data});
          }
        },
      });
    }))).then((values) => {
      const settings = {};
      utils.each(values, function(items){
        utils.each(items, function(item, key){
          if(utils.isPlainObject(item)){
            Object.keys(item).length > 0 && (settings[key] = item);
          } else {
            !utils.isUndefined(item) && (settings[key] = item);
          }
        });
      });
      callback && callback(null, settings);
    }).catch(function(error){
      callback && callback(error.message);
    });
  });
  // 配置导入
  app.on('import', function({request, callback}){
    const result = request.data;
    // console.log('--request-', request);
    if(!result){
      callback && callback(app.fire('i18n', 'required'));
      return;
    }
    const results = utils.isString(result) ? JSON.parse(result) : result;
    const actions = [];
    // console.log('-----result', results);
    utils.each(results, function(item, table){
      const promises = [];
      tables.includes(table) && utils.each(item, function(value, name){
        promises.push(new Promise((resolve, reject) => {
          app.fire('db', {
            request: {
              name,
              value,
              table,
              execute: 'add',
            },
            callback: function(error){
              if(error){
                reject(error);
              } else {
                resolve();
              }
            },
          });
        }));
      });
      promises.length > 0 && actions.push(Promise.all(promises));
    });
    if(actions.length > 0){
      Promise.all(actions).then(function(){
        callback && callback();
      }).catch(function(error){
        callback && callback(error.message);
      });
    } else {
      callback && callback(app.fire('i18n', 'required'));
    }
  });
});
