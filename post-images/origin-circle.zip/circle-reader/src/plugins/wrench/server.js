App.register('wrench', ['utils', 'user', 'database'], function(utils){
  const app = this;
  const tables = app.cache('db_tables');

  // 配置导出
  app.on('export', function({callback}){
    Promise.all(tables.map(table => new Promise((resolve, reject) => {
      app.fire('db', {
        request: {
          table,
          execute: 'all',
        },
        callback: function(error, data){
          if(error){
            reject(error);
          } else {
            resolve({[table]:data});
          }
        },
      });
    }))).then((values) => {
      const settings = {};
      utils.each(values, function(items){
        utils.each(items, function(item, key){
          if(utils.isPlainObject(item)){
            Object.keys(item).length > 0 && (settings[key] = item);
          } else {
            !utils.isUndefined(item) && (settings[key] = item);
          }
        });
      });
      callback && callback(null, settings);
    }).catch(function(error){
      callback && callback(error.message);
    });
  });
  // 配置导入
  app.on('import', function({request, callback}){
    const result = request.data;
    // console.log('--request-', request);
    if(!result){
      callback && callback(app.fire('i18n', 'required'));
      return;
    }
    const results = utils.isString(result) ? JSON.parse(result) : result;
    const actions = [];
    // console.log('-----result', results);
    utils.each(results, function(item, table){
      const promises = [];
      tables.includes(table) && utils.each(item, function(value, name){
        promises.push(new Promise((resolve, reject) => {
          app.fire('db', {
            request: {
              name,
              value,
              table,
              execute: 'add',
            },
            callback: function(error){
              if(error){
                reject(error);
              } else {
                resolve();
              }
            },
          });
        }));
      });
      promises.length > 0 && actions.push(Promise.all(promises));
    });
    if(actions.length > 0){
      Promise.all(actions).then(function(){
        callback && callback();
      }).catch(function(error){
        callback && callback(error.message);
      });
    } else {
      callback && callback(app.fire('i18n', 'required'));
    }
  });
});
