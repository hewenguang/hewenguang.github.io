export default function(app, root, disabled){
  app.on('render-start-done', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('render-destory-done', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-before', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-after', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('wrench-change', function(visible){
    if(visible){
      const target = root.querySelector('.user a');
      target && target.focus && target.focus();
    }
  });
  !disabled && ['outline', 'backtop', 'nextpage', 'autorun'].forEach(function(item){
    app.on(item, function(){
      app.fire('message', {
        duration: 1,
        key: item,
        type: 'success',
        message: app.fire('i18n', 'refresh_to_active'),
      });
    });
  });
}
