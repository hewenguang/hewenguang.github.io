import React from 'react';
import ReactDOM from 'react-dom';
import { message } from 'antd';
import Root from './root';
import 'antd/dist/antd.css';
import './index.less';

App.register('wrench', ['shadow', 'dom', 'utils'], function(shadow, dom){
  const app = this;
  const root = dom.create('div', {className:'root'});
  shadow({
    mode: 'open', // closed 会导致 antd select 打不开
    root: document.documentElement,
    style: [
      'plugins/antd/index.css',
      'plugins/wrench/index.css',
    ],
    onReady: function(shadowRoot){
      shadowRoot.appendChild(root);
    },
  });

  app.on('render-start-done', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('render-destory-done', function(){
    dom.setStyle(root, 'display', 'none');
  });

  message.config({
    getContainer:() => root,
  });
  ReactDOM.render(<Root app={app} container={root} />, root);
});
