import React from 'react';
import ReactDOM from 'react-dom';
import { message } from 'antd';
import Drawer from 'app/components/drawer';
import controller from './controller';
import Entry from './entry';
import './index.less';

App.register('wrench', ['shadow', 'dom', 'utils'], function(shadow, dom){
  const app = this;
  const option = app.cache('env') === 'option';
  const root = dom.create('div');
  shadow({
    mode: 'open', // closed 会导致 antd select 打不开
    style: [
      'plugins/antd/index.css',
      'plugins/wrench/index.css',
    ],
    onReady: function(shadowRoot){
      shadowRoot.appendChild(root);
    },
  });

  controller(app, root, option);

  message.config({getContainer:() => root});
  ReactDOM.render((
    <Drawer
      app={app}
      size="small"
      plugin="wrench"
      disabled={option}
    >
      <Entry root={root} />
    </Drawer>
  ), root);
});
