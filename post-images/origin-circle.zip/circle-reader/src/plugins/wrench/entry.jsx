import { Collapse } from 'antd';
import Ctx from './modules/ctx';
import User from './modules/user';
import Links from './modules/links';
import Basic from './modules/basic';
import Config from './modules/config';
import Extra from './components/extra';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import Title from 'app/components/title';
import Shortcut from './modules/shortcut';
import Blacklist from './modules/blacklist';
import Whitelist from './modules/whitelist';
import Version from 'app/components/version';
// import Webenhance from './modules/webenhance';
import React, {useState,useEffect} from 'react';
import Stylesheet from './modules/stylesheet';
import Authorize from 'app/components/authorize';
import useCtx from 'plugin/wrench/context/useCtx';
import useLinks from 'plugin/wrench/context/useLinks';
import useBasic from 'plugin/wrench/context/useBasic';
import useRoster from 'plugin/wrench/context/useRoster';
import useConfig from 'plugin/wrench/context/useConfig';
import useShortcut from 'plugin/wrench/context/useShortcut';
import useStylesheet from 'plugin/wrench/context/useStylesheet';
// import useWebenhance from 'plugin/wrench/context/useWebenhance';

const { Panel } = Collapse;

export default function({root}){
  const app = useApp();
  const ctx = useCtx();
  const user = useUser();
  const links = useLinks();
  const basic = useBasic();
  const config = useConfig();
  const roster = useRoster();
  const shortcut = useShortcut();
  const stylesheet = useStylesheet();
  // const webenhance = useWebenhance();
  
  const [ activeKey, setActiveKey ] = useState(basic.field);
  const datasource = [{
    field: basic.field,
    label: basic.label,
    value: <Basic />,
  },{
    field: roster.white.field,
    label: roster.white.label,
    value: <Whitelist />,
  },{
    field: roster.black.field,
    label: roster.black.label,
    value: <Blacklist />,
  },{
    field: shortcut.field,
    label: shortcut.label,
    value: <Shortcut />,
    extra: shortcut.enabled,
    extraChange: function(checked){
      app.cache(shortcut.enabled, checked);
    },
  },{
    field: ctx.field,
    label: ctx.label,
    value: <Ctx />,
    extra: ctx.enabled,
    extraChange: function(checked){
      app.fire('send', 'ctx', {
        action: checked ? 'init' : 'removeall',
      });
    },
  },{
    field: config.field,
    label: config.label,
    value: <Config />,
  },
  // {
  //   field: webenhance.field,
  //   label: webenhance.label,
  //   value: <Webenhance />,
  // },
  {
    field: stylesheet.field,
    label: stylesheet.label,
    value: <Stylesheet />,
  },{
    field: links.field,
    label: links.label,
    value: <Links />,
  }];

  useEffect(() => {
    const hook = app.on('guide', function(key, selector){
      if(![basic.field, roster.white.field, roster.black.field, shortcut.field, ctx.field, config.field, stylesheet.field, links.field].includes(key)){
        return;
      }
      setActiveKey(key);
      selector && setTimeout(function(){
        const target = root.querySelector(`.${selector}`);
        if(!target){
          return;
        }
        dom.scrollIntoView(target);
        target.classList.add('twinkle');
        const focusable = target.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        focusable && focusable.focus();
      }, 1000);
    });
    return () => {
      app.remove(hook);
    };
  }, []);

  return (
    <>
      <User />
      <Collapse
        accordion
        bordered={false}
        className="collapse"
        activeKey={activeKey}
        onChange={val => {
          setActiveKey(val);
          app.fire('send', 'analytics', {event:`wrench-${val}`});
        }}
      >
        {datasource.map(item => (
          <Panel
            key={item.field}
            className={item.field}
            header={
              <Authorize
                field={item.field}
                access={user.member}
              >
                <Title label={item.label} />
              </Authorize>
            }
            extra={item.extra && (
              <Extra
                field={item.extra}
                onChange={item.extraChange}
              />
            )}
          >
            {item.value}
          </Panel>
        ))}
      </Collapse>
      <Version />
    </>
  );
}
