import React, { useState } from 'react';
import { Collapse } from 'antd';
import User from './modules/user';
import Basic from './modules/basic';
import Config from './modules/config';
import Extra from './components/extra';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import Title from 'app/components/title';
import Shortcut from './modules/shortcut';
import Blacklist from './modules/blacklist';
import Whitelist from './modules/whitelist';
// import Webenhance from './modules/webenhance';
import Stylesheet from './modules/stylesheet';
import Helpcenter from './modules/helpcenter';
import Contextmenu from './modules/contextmenu';
import useBasic from 'plugin/wrench/context/useBasic';
import useRoster from 'plugin/wrench/context/useRoster';
import useConfig from 'plugin/wrench/context/useConfig';
import useShortcut from 'plugin/wrench/context/useShortcut';
import Authorize, { authorize } from 'app/components/authorize';
import useHelpcenter from 'plugin/wrench/context/useHelpcenter';
import useStylesheet from 'plugin/wrench/context/useStylesheet';
// import useWebenhance from 'plugin/wrench/context/useWebenhance';
import useContextmenu from 'plugin/wrench/context/useContextmenu';

const { Panel } = Collapse;

export default function(){
  const app = useApp();
  const user = useUser();
  const basic = useBasic();
  const config = useConfig();
  const roster = useRoster();
  const shortcut = useShortcut();
  const helpcenter = useHelpcenter();
  const stylesheet = useStylesheet();
  // const webenhance = useWebenhance();
  const contextmenu = useContextmenu();
  const [ activeKey, setActiveKey ] = useState(basic.field);
  const datasource = [{
    field: basic.field,
    label: basic.label,
    value: <Basic />,
  },{
    field: roster.white.field,
    label: roster.white.label,
    value: <Whitelist />,
  },{
    field: roster.black.field,
    label: roster.black.label,
    value: <Blacklist />,
  },{
    field: shortcut.field,
    label: shortcut.label,
    value: <Shortcut />,
    extra: shortcut.enabled,
    extraChange: function(checked){
      app.cache(shortcut.enabled, checked);
    },
  },{
    field: contextmenu.field,
    label: contextmenu.label,
    value: <Contextmenu />,
    extra: contextmenu.enabled,
    extraChange: function(checked){
      app.fire('send', 'contextmenus', {
        action: checked ? 'init' : 'removeall',
      });
    },
  },{
    field: config.field,
    label: config.label,
    value: <Config />,
  },
  // {
  //   field: webenhance.field,
  //   label: webenhance.label,
  //   value: <Webenhance />,
  // },
  {
    field: stylesheet.field,
    label: stylesheet.label,
    value: <Stylesheet />,
  },{
    field: helpcenter.field,
    label: helpcenter.label,
    value: <Helpcenter />,
  }];

  return (
    <>
      <User />
      <Collapse
        accordion
        bordered={false}
        className="collapse"
        activeKey={activeKey}
        onChange={key => {
          if(user.member || authorize(key)){
            setActiveKey(key);
          } else {
            app.fire('upgrade', 'upgrade');
          }
        }}
      >
        {datasource.map(item => (
          <Panel
            key={item.field}
            header={
              <Authorize
                field={item.field}
                access={user.member}
              >
                <Title label={item.label} />
              </Authorize>
            }
            extra={item.extra && (
              <Extra
                field={item.extra}
                onChange={item.extraChange}
              />
            )}
          >
            {item.value}
          </Panel>
        ))}
      </Collapse>
    </>
  );
}
