import React from 'react';
import Field from './field';
import List from 'app/components/list';
import useContextmenu from 'plugin/wrench/context/useContextmenu';

export default function(){
  const contextmenu = useContextmenu();

  return (
    <List
      borderBottom
      data={contextmenu.data}
      renderItem={item => (
        <Field {...item} />
      )}
    />
  );
}
