import React from 'react';
import Alert from './alert';
import Field from './field';
import List from 'app/components/list';
import useShortcut from 'plugin/wrench/context/useShortcut';
import './index.less';

export default function(){
  const shortcut = useShortcut();

  return (
    <>
      <Alert
        field={shortcut.alert.field}
        message={shortcut.alert.message}
      />
      <List
        borderBottom
        className="shortcuts"
        data={shortcut.data}
        renderItem={item => (
          <Field {...item} />
        )}
      />
    </>
  );
}
