import React from 'react';
import Alert from './alert';
import Field from './field';
import List from 'app/components/list';
import useShortcut from 'plugin/wrench/context/useShortcut';

export default function(){
  const shortcut = useShortcut();

  return (
    <>
      <Alert
        field={shortcut.alert.field}
        message={shortcut.alert.message}
      />
      <List
        borderBottom
        data={shortcut.data}
        renderItem={item => (
          <Field {...item} />
        )}
      />
    </>
  );
}
