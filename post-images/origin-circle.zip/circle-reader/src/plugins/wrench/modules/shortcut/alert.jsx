import React from 'react';
import { Alert, Popconfirm } from 'antd';
import useStorage from 'app/context/useStorage';
import { CloseOutlined } from '@ant-design/icons';
import useShortcut from 'plugin/wrench/context/useShortcut';

export default function(props){
  const { field, message } = props;
  const shortcut = useShortcut();
  const [ option, optionChange, setOption ] = useStorage({
    field,
    defaultValue: false,
  });

  if(option){
    return null;
  }

  return (
    <Alert
      message={message}
      style={{
        fontSize: 12,
        margin: '12px 32px 0',
        alignItems: 'flex-start',
      }}
      action={
        <Popconfirm
          placement="left"
          title={shortcut.prompt.label}
          onCancel={() => setOption(true)}
          onConfirm={() => optionChange(true)}
        >
          <CloseOutlined />
        </Popconfirm>
      }
    />
  );
}
