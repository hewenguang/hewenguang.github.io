import React from 'react';
import Icon from 'app/components/icon';
import { Alert, Popconfirm } from 'antd';
import useApp from 'app/context/useApp';
import useStorage from 'app/context/useStorage';
import useShortcut from 'plugin/wrench/context/useShortcut';

export default function(props){
  const { field, message } = props;
  const app = useApp();
  const shortcut = useShortcut();
  const [ option, optionChange, setOption ] = useStorage({
    field,
    defaultValue:'false',
  });

  if(option === 'true'){
    return null;
  }

  return (
    <Alert
      message={message}
      style={{
        fontSize: 12,
        margin: '12px 32px 0',
        alignItems: 'flex-start',
      }}
      action={
        <Popconfirm
          placement="left"
          title={shortcut.prompt}
          onCancel={() => setOption('true')}
          onConfirm={() => optionChange('true')}
          okText={app.fire('i18n', 'ok')}
          cancelText={app.fire('i18n', 'cancel')}
        >
          <Icon name="close" />
        </Popconfirm>
      }
    />
  );
}
