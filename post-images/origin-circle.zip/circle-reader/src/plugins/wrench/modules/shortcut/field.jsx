import React from 'react';
import { Space, Input } from 'antd';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import Switch from 'app/components/switch';
import useOption from 'app/context/useOption';
import { authorize } from 'app/components/authorize';

export default function(props){
  const { field, table = 'shortcut' } = props;
  let timer;
  let keys = [];
  let count = 0;
  const app = useApp();
  const user = useUser();
  const [ option, optionChange ] = useOption({
    field,
    table,
    defaultValue: {value:'',checked:false},
  });
  const checked = !!option.checked;
  const change = (shortcut) => {
    optionChange(shortcut);
    // 实时更新配置
    app.cache('shortcut',{[field]: shortcut});
  };

  return (
    <Space align="start">
      {checked && (
        <Input
          value={option.value}
          onKeyDown={event => {
            if(event.key === 'Tab'){
              return;
            }
            event.preventDefault();
            event.stopPropagation();
            const key = dom.keyboard(event);
            key && keys.push(key);
            count++;
            if (count === 1){
              timer = setTimeout(function() {
                count = 0;
                if(keys.length <= 0){
                  return;
                }
                change(Object.assign({},option,{value:keys.join(' ')}));
                keys = [];
              }, 500);
            } else if (count === 2) {
              timer && clearTimeout(timer);
              count = 0;
              if(keys.length <= 0){
                return;
              }
              change(Object.assign({},option,{value:keys.join(' ')}));
              keys = [];
            }
          }}
        />
      )}
      <Switch
        checked={checked}
        onChange={checkedChange => {
          if(!checkedChange || user.member || authorize(field)){
            change(Object.assign({},option,{checked:checkedChange}));
          } else {
            app.fire('upgrade');
          }
        }}
      />
    </Space>
  );
}
