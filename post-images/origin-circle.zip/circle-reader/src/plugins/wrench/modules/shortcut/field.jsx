import React from 'react';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import Switch from 'app/components/switch';
import { message, Space, Input } from 'antd';
import useOption from 'app/context/useOption';
import { authorize } from 'app/components/authorize';

export default function(props){
  const { field, table = 'shortcut' } = props;
  const app = useApp();
  const user = useUser();
  const [ option, optionChange ] = useOption({
    field,
    table,
    defaultValue: {value:'',checked:false},
  });
  const change = (shortcut) => {
    optionChange(shortcut);
    // 实时更新配置
    app.cache('shortcut',{[field]: shortcut});
  };

  return (
    <Space align="start">
      <Input
        style={{width:80}}
        value={option.value}
        onKeyDown={event => {
          event.preventDefault();
          if(!user.member && !authorize(field)){
            app.fire('upgrade', 'upgrade');
            return;
          }
          const key = utils.toLower(event.key);
          if(['alt', 'control', 'meta', 'shift'].includes(key)){
            return;
          }
          const keyVal = [key];
          event.altKey && keyVal.unshift('alt');
          event.ctrlKey && keyVal.unshift('ctrl');
          event.metaKey && keyVal.unshift('meta');
          event.shiftKey && keyVal.unshift('shift');
          const shortcut = keyVal.join('+');
          app.fire('send', 'db', {
            table,
            execute: 'each',
            name: 'value',
            value: shortcut,
          }, function({error, data}){
            if(error){
              app.fire('error', error);
            } else {
              if(data){
                message.error(app.fire('i18n', 'existed'));
                return;
              }
              change(Object.assign({},option,{value:shortcut}));
            }
          });
        }}
      />
      <Switch
        checked={option.checked}
        onChange={checkedChange => {
          if(!user.member && !authorize(field)){
            app.fire('upgrade', 'upgrade');
            return;
          }
          change(Object.assign({},option,{checked:checkedChange}));
        }}
      />
    </Space>
  );
}
