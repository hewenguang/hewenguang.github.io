import React from 'react';
import List from 'app/components/list';
import useLinks from 'plugin/wrench/context/useLinks';

export default function(){
  const links = useLinks();

  return (
    <List
      borderBottom
      data={links.data}
      renderItem={item => (
        <a
          tabIndex="0"
          target="_blank"
          href={item.url}
          className="wrench-link"
        >
          {item.title}
        </a>
      )}
    />
  );
}
