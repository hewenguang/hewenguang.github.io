import React from 'react';
import { message, Upload } from 'antd';
import useApp from 'app/context/useApp';
import { InboxOutlined } from '@ant-design/icons';
import useConfig from 'plugin/wrench/context/useConfig';
import './import.less';

const { Dragger } = Upload;

export default function(){
  const app = useApp();
  const config = useConfig();

  return (
    <div className="import-upload">
      <Dragger
        name="file"
        maxCount={1}
        accept=".json"
        fileList={[]}
        multiple={false}
        beforeUpload={() => false}
        onChange={(info) => {
          const file = info.file;
          const reader = new FileReader();
          reader.addEventListener('load', function(){
            app.fire('send', 'import', {data:this.result}, function({error}){
              if(error){
                message.error(error);
              } else {
                message.success(app.fire('i18n', 'success'));
                utils.wait(function(){
                  location.reload();
                }, 1000);
              }
            });
          });
          reader.readAsText(file);
        }}
      >
        <p className="ant-upload-drag-icon"><InboxOutlined /></p>
        <p className="ant-upload-text">{config.upload}</p>
        <p className="ant-upload-hint">{config.limit}</p>
      </Dragger>
    </div>
  );
}
