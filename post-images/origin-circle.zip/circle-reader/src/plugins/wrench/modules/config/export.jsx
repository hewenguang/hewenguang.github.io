import { saveAs } from 'file-saver';
import { message, Button } from 'antd';
import React, { useState } from 'react';
import useApp from 'app/context/useApp';
import useConfig from 'plugin/wrench/context/useConfig';

export default function(){
  const app = useApp();
  const config = useConfig();
  const [ loading, setLoading ] = useState(false);

  return (
    <Button
      type="primary"
      loading={loading}
      onClick={() => {
        setLoading(true);
        app.fire('send', 'export', function({error, data}){
          if(error){
            message.error(error);
          } else {
            setLoading(false);
            saveAs(new Blob([JSON.stringify(data)], {type:'text/plain;charset=utf-8'}), 'circle_db.json');
            app.fire('send', 'analytics', {event:'config-export'});
          }
        });
      }}
    >
      {config.export}
    </Button>
  );
}

