import React from 'react';
import List from 'app/components/list';
import Switch from 'plugin/wrench/components/switch';
import useConfig from 'plugin/wrench/context/useConfig';

export default function(){
  const config = useConfig();

  return (
    <List
      borderBottom
      data={[config.data.autosync]}
      renderItem={item => (
        <Switch {...item} />
      )}
    />
  );
}
