import React from 'react';
import Import from './import';
import Export from './export';
import List from 'app/components/list';
import useConfig from 'plugin/wrench/context/useConfig';

export default function(){
  const config = useConfig();

  return (
    <List
      borderNone
      data={[{
        value: (
          <>
            <div>{config.import}</div>
            <Export />
          </>
        ),
      }, {
        value: <Import />,
      }]}
    >
      {item => item.value}
    </List>
  );
}
