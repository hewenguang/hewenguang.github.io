import React from 'react';
import Import from './import';
import Export from './export';
import Autosync from './autosync';
import List from 'app/components/list';
import useConfig from 'plugin/wrench/context/useConfig';

export default function(){
  const config = useConfig();

  return (
    <>
      <Autosync />
      <List
        borderNone
        data={[{
          value: (
            <>
              <div>{config.import}</div>
              <Export />
            </>
          ),
        }, {
          value: <Import />,
        }]}
      >
        {item => item.value}
      </List>
    </>
  );
}
