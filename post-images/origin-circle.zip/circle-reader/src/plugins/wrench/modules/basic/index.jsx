import React from 'react';
import List from 'app/components/list';
import Switch from 'plugin/wrench/components/switch';
import useBasic from 'plugin/wrench/context/useBasic';

export default function(){
  const basic = useBasic();

  return (
    <List
      borderBottom
      data={basic.data}
      renderItem={item => (
        <Switch {...item} />
      )}
    />
  );
}
