import cx from 'classnames';
import { Space } from 'antd';
import React, { useState } from 'react';
import { Controlled as CodeMirror } from 'react-codemirror2';
import 'codemirror/mode/css/css';
import 'codemirror/lib/codemirror.css';
import Copy from 'app/components/copy';
import Icon from 'app/components/icon';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import useOption from 'app/context/useOption';
import { authorize } from 'app/components/authorize';
import useStylesheet from 'plugin/wrench/context/useStylesheet';
import './editor.less';

let editorInstance;

export default function(){
  const app = useApp();
  const user = useUser();
  const stylesheet = useStylesheet();
  const field = stylesheet.field;
  const [ large, setLarge ] = useState(false);
  const allowed = user.member || authorize(field);
  const [ option, optionChange, setOption ] = useOption({
    field,
    defaultValue: stylesheet.defaultValue,
  });

  return (
    <div
      className={cx('wrench-editor', {
        'wrench-large-editor': large
      })}
      onMouseLeave={() => {
        if(!editorInstance){
          return;
        }
        allowed && optionChange(editorInstance.getValue());
      }}
    >
      <Space className="wrench-editor-tools">
        {large ? (
          <Icon
            name="shrink"
            tooltip={stylesheet.narrow}
            onClick={() => setLarge(false)}
          />
        ) : (
          <>
            <Copy text={option} />
            <Icon
              name="arrowsalt"
              tooltip={stylesheet.enlarge}
              onClick={() => {
                if(allowed){
                  setLarge(true);
                } else {
                  app.fire('upgrade');
                }
              }}
            />
          </>
        )}
      </Space>
      <CodeMirror
        value={option}
        options={{
          mode: 'css',
          lineNumbers: true,
        }}
        editorDidMount={editor => {
          editorInstance = editor;
        }}
        editorWillUnmount={() => {
          editorInstance = null;
        }}
        onBeforeChange={(editor, data, value) => {
          if(allowed){
            setOption(value);
          } else {
            app.fire('upgrade');
          }
        }}
      />
    </div>
  );
}
