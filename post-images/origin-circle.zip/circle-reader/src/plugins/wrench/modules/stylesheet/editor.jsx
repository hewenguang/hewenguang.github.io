import cx from 'classnames';
import { Space, Tooltip } from 'antd';
import React, { useState } from 'react';
import { Controlled as CodeMirror } from 'react-codemirror2';
import 'codemirror/mode/css/css';
import 'codemirror/lib/codemirror.css';
import useUser from 'app/context/useUser';
import useOption from 'app/context/useOption';
import Copy from 'plugin/wrench/components/copy';
import { authorize } from 'app/components/authorize';
import useStylesheet from 'plugin/wrench/context/useStylesheet';
import { ArrowsAltOutlined, ShrinkOutlined } from '@ant-design/icons';
import './editor.less';

let editorInstance;

export default function(){
  const user = useUser();
  const stylesheet = useStylesheet();
  const field = stylesheet.field;
  const [ large, setLarge ] = useState(false);
  const [ option, optionChange, setOption ] = useOption({
    field,
    defaultValue: stylesheet.defaultValue,
  });

  return (
    <div
      className={cx('wrench-editor', {
        'wrench-large-editor': large
      })}
      onMouseLeave={() => {
        editorInstance && (user.member || authorize(field)) && optionChange(editorInstance.getValue());
      }}
    >
      <Space className="wrench-editor-tools">
        {large ? (
          <Tooltip title={stylesheet.narrow}>
            <ShrinkOutlined onClick={() => setLarge(false)} />
          </Tooltip>
        ) : (
          <>
            <Copy text={option} />
            <Tooltip title={stylesheet.enlarge}>
              <ArrowsAltOutlined
                onClick={() => {
                  (user.member || authorize(field)) && setLarge(true);
                }}
              />
            </Tooltip>
          </>
        )}
      </Space>
      <CodeMirror
        value={option}
        options={{
          mode: 'css',
          lineNumbers: true,
        }}
        editorDidMount={editor => {
          editorInstance = editor;
        }}
        editorWillUnmount={() => {
          editorInstance = null;
        }}
        onBeforeChange={(editor, data, value) => {          
          (user.member || authorize(field)) && setOption(value);
        }}
      />
    </div>
  );
}
