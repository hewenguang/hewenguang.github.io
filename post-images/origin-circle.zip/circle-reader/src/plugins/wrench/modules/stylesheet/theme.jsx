import React from 'react';
import { Select } from 'antd';
import useStylesheet from 'plugin/wrench/context/useStylesheet';

export default function(){
  const stylesheet = useStylesheet();

  return (
    <>
      <div>{stylesheet.theme.label}</div>
      <Select
        style={{width:132}}
        options={stylesheet.theme.data}
      />
    </>
  );
}
