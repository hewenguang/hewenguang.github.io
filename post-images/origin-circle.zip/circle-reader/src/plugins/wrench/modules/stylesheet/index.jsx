import React from 'react';
import { List } from 'antd';
// import Theme from './theme';
import Editor from './editor';

export default function(){

  return (
    <List>
      {/* <List.Item>
        <Theme />
      </List.Item> */}
      <List.Item>
        <Editor />
      </List.Item>
    </List>
  );
}
