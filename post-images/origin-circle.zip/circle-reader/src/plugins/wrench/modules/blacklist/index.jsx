import React from 'react';
import Table from 'plugin/wrench/components/table';
import useRoster from 'plugin/wrench/context/useRoster';

export default function(){
  const roster = useRoster();

  return (
    <Table
      label={roster.black.label}
      table={roster.black.field}
    />
  );
}
