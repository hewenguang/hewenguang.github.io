import React from 'react';
import List from 'app/components/list';
import Switch from 'app/components/switch/option';
import useWebenhance from 'plugin/wrench/context/useWebenhance';

export default function(){
  const webenhance = useWebenhance();

  return (
    <List
      borderBottom
      data={webenhance.data}
      renderItem={item => (
        <Switch {...item} />
      )}
    />
  );
}
