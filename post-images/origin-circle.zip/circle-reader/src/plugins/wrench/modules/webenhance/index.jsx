import React from 'react';
import List from 'app/components/list';
import Switch from 'plugin/wrench/components/switch';
import useWebenhance from 'plugin/wrench/context/useWebenhance';

export default function(){
  const webenhance = useWebenhance();

  return (
    <List
      borderBottom
      data={webenhance.data}
      renderItem={item => (
        <Switch {...item} />
      )}
    />
  );
}
