import React from 'react';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import Switch from 'app/components/switch';
import useOption from 'app/context/useOption';
import { authorize } from 'app/components/authorize';

export default function(props){
  const { field, label } = props;
  const app = useApp();
  const user = useUser();
  const [ option, optionChange ] = useOption({
    field,
    table: 'contextmenu',
    defaultValue: {label,checked:false,create:+(new Date)},
  });

  return (
    <Switch
      checked={!!option.checked}
      onChange={checked => {
        if(!checked || user.member || authorize(field)){
          optionChange({label,checked,create:+(new Date)});
          app.fire('send', 'db', {
            execute: 'get',
            table: 'wrench',
            name: 'contextmenu-enabled',
          }, function({error, data}){
            if(error){
              app.fire('error', error);
            } else {
              data && app.fire('send', 'ctx', {
                id: field,
                title: label,
                action: checked ? 'create' : 'remove',
              });
            }
          });
        } else {
          app.fire('upgrade');
        }
      }}
    />
  );
}
