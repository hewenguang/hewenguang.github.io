import React from 'react';
import Field from './field';
import List from 'app/components/list';
import useCtx from 'plugin/wrench/context/useCtx';

export default function(){
  const ctx = useCtx();

  return (
    <List
      borderBottom
      data={ctx.data}
      renderItem={item => (
        <Field {...item} />
      )}
    />
  );
}
