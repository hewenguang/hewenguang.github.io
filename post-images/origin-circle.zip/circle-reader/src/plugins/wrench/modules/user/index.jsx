import React from 'react';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import { UserOutlined } from '@ant-design/icons';
import { Space, Typography, Popconfirm } from 'antd';
import './index.less';

const { Paragraph } = Typography;

export default function(){
  const app = useApp();
  const user = useUser();

  if(!user || !user.name){
    return (
      <div className="wrench-user">
        <Paragraph>
          <Space>
            <UserOutlined />
            <a
              className="wrench-link"
              onClick={() => app.fire('upgrade', 'login')}
            >
              {app.fire('i18n', 'login')}
            </a>
            <a
              className="wrench-link"
              onClick={() => app.fire('upgrade', 'register')}
            >
              {app.fire('i18n', 'register')}
            </a>
          </Space>
        </Paragraph>
        <Paragraph>
          <a className="wrench-link" onClick={() => app.fire('upgrade', 'upgrade')}>
            {app.fire('i18n', 'upgrade_tooltip')}
          </a>
        </Paragraph>
      </div>
    );
  }

  const expire = user.expire;

  return (
    <div className="wrench-user">
      <Paragraph>
        <Space align="start">
          <UserOutlined />
          <div
            title={user.name}
            className="user-name"
          >
            {user.name}
          </div>
          <Popconfirm
            placement="bottomLeft"
            title={app.fire('i18n', 'confirm_exit')}
            onConfirm={() => {
              app.fire('send', 'loginout', function({error}){
                if(error){
                  app.fire('message', {
                    key: 'loginout',
                    message: error,
                  });
                  return;
                }
                app.fire('login');
              });
            }}
          >
            <a className="user-loginout">{app.fire('i18n', 'exit')}</a>
          </Popconfirm>
        </Space>
      </Paragraph>
      {user.member && expire && (
        <Paragraph style={{fontSize: 14}}>
          {app.fire('i18n', 'expire_tooltip', expire)}
        </Paragraph>
      )}
      {!user.member && (
        <Paragraph>
          <a className="wrench-link" onClick={() => app.fire('upgrade')}>
            {app.fire('i18n', 'upgrade_tooltip')}
          </a>
        </Paragraph>
      )}
    </div>
  );
}
