import React from 'react';
import Link from 'app/components/link';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import UserOutlined from '@ant-design/icons/UserOutlined';
import CrownOutlined from '@ant-design/icons/CrownOutlined';
import { Tag, Space, Typography, Popconfirm } from 'antd';
import Login from './login';
import './index.less';

const { Paragraph } = Typography;

export default function(){
  const app = useApp();
  const user = useUser();

  if(!user || !user.name){
    return (
      <div className="user">
        <Paragraph>
          <Space>
            <UserOutlined className="icon-user" />
            <Login app={app} user={user} />
          </Space>
        </Paragraph>
        <Paragraph>
          <Link
            style={{fontSize:14}}
            className="wrench-link"
            onClick={() => {
              if(!user.called || !utils.isUndefined(user.id)){
                return;
              }
              app.fire('send', 'retrieve', function({error}){
                if(error){
                  app.fire('message', {
                    type: 'error',
                    duration: 1,
                    key: 'login',
                    message: error,
                  });
                } else {
                  app.fire('login');
                }
              });
            }}
          >
            {app.fire('i18n', 'sync_account')}
          </Link>
        </Paragraph>
      </div>
    );
  }

  const expire = user.expire;

  return (
    <div className="user">
      <Paragraph>
        <Space align="start">
          <UserOutlined />
          <div
            title={user.name}
            className="user-name"
          >
            {user.name}
          </div>
          <Popconfirm
            placement="bottomLeft"
            title={app.fire('i18n', 'confirm_exit')}
            okText={app.fire('i18n', 'ok')}
            cancelText={app.fire('i18n', 'cancel')}
            onConfirm={() => {
              app.fire('send', 'loginout', function({error}){
                if(error){
                  app.fire('message', {
                    key: 'loginout',
                    message: error,
                  });
                  return;
                }
                app.fire('login');
              });
            }}
          >
            <Link className="user-loginout">{app.fire('i18n', 'exit')}</Link>
          </Popconfirm>
        </Space>
      </Paragraph>
      {user.member && (
        <Paragraph style={{fontSize: 14}}>
          {expire ? app.fire('i18n', 'expire_tooltip', expire) : (
            <Tag icon={<CrownOutlined />} color="#52c41a">{app.fire('i18n', 'forever')}</Tag>
          )}
        </Paragraph>
      )}
      {!user.member && (
        <Paragraph>
          <Link onClick={() => app.fire('upgrade')}>
            {app.fire('i18n', 'upgrade_tooltip')}
          </Link>
        </Paragraph>
      )}
    </div>
  );
}
