import React, { useEffect } from 'react';

export default function(props){
  const { app, user } = props;

  useEffect(() => {
    const hook = app.on('visiblechange', function(visible){
      if(!app.cache('login') || !visible || !user.called || !utils.isUndefined(user.id)){
        return;
      }
      app.fire('send', 'retrieve', function({error}){
        if(error){
          return;
        }
        app.cache('login', false);
        app.fire('login');
      });
    });
    return () => {
      app.remove(hook);
    };
  }, [ user ]);

  return (
    <>
      <a
        target="_blank"
        className="wrench-link"
        href={app.to('user/login')}
        onClick={() => app.cache('login', true)}
      >
        {app.fire('i18n', 'login')}
      </a>
      <a
        target="_blank"
        className="wrench-link"
        href={app.to('user/register')}
        onClick={() => app.cache('login', true)}
      >
        {app.fire('i18n', 'register')}
      </a>
    </>
  );
}
