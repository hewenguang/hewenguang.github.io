import React from 'react';
import List from 'app/components/list';
import useHelpcenter from 'plugin/wrench/context/useHelpcenter';

export default function(){
  const helpcenter = useHelpcenter();

  return (
    <List
      borderBottom
      data={helpcenter.data}
      renderItem={item => (
        <a
          target="_blank"
          href={item.url}
          className="wrench-link"
        >
          {item.title || '--'}
        </a>
      )}
    />
  );
}
