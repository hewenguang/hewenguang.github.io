import { useContext } from 'react';
import { AppContext } from 'app/context';

export default function(){
  const app = useContext(AppContext);

  return {
    field: 'basic',
    label: app.fire('i18n', 'basic'),
    data: [{
      field: 'outline',
      label: app.fire('i18n', 'outline'),
      tooltip: app.fire('i18n', 'outline_tooltip'),
      learn_more: app.to('node/35'),
    },{
      field: 'backtop',
      label: app.fire('i18n', 'backtop'),
    },{
      field: 'nextpage',
      label: app.fire('i18n', 'nextpage'),
      tooltip: app.fire('i18n', 'nextpage_tooltip'),
      learn_more: app.to('node/36'),
    },{
      field: 'autoscroll',
      label: app.fire('i18n', 'autoscroll'),
      tooltip: app.fire('i18n', 'autoscroll_tooltip'),
    },{
      field: 'autofullscreen',
      label: app.fire('i18n', 'autofullscreen'),
      tooltip: app.fire('i18n', 'autofullscreen_tooltip'),
    },{
      field: 'autorun',
      label: app.fire('i18n', 'autorun'),
      tooltip: app.fire('i18n', 'autorun_tooltip'),
      tooltipStyle: {
        color: '#ef7777',
        marginLeft: 3,
      }
    }]
  };
}
