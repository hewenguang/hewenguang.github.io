import { useContext } from 'react';
import { AppContext } from 'app/context';

export default function useBasic(){
  const app = useContext(AppContext);

  return {
    field: 'basic',
    label: app.fire('i18n', 'basic'),
    data: [
      {
        field: 'paper',
        label: app.fire('i18n', 'paper'),
        tooltip: app.fire('i18n', 'paper_tooltip'),
      },{
        field: 'outline',
        label: app.fire('i18n', 'outline'),
        tooltip: app.fire('i18n', 'outline_tooltip'),
      },{
        field: 'backtop',
        label: app.fire('i18n', 'backtop'),
      },{
        field: 'exitclose',
        label: app.fire('i18n', 'exitclose'),
        tooltip: app.fire('i18n', 'exitclose_tooltip'),
      },{
        field: 'nextpage',
        label: app.fire('i18n', 'nextpage'),
        tooltip: app.fire('i18n', 'nextpage_tooltip'),
      },{
        field: 'autorun',
        label: app.fire('i18n', 'autorun'),
        tooltip: app.fire('i18n', 'autorun_tooltip'),
        tooltipStyle: {
          color: '#ef7777',
          marginLeft: 3,
        }
      },
      // {
      //   field: 'autoupdate',
      //   label: app.fire('i18n', 'autoupdate'),
      //   tooltip: app.fire('i18n', 'autoupdate_tooltip'),
      // }
      // ,{
      //   field: 'removefooter',
      //   label: app.fire('i18n', 'removefooter'),
      // },{
      //   field: 'sendkindle',
      //   label: app.fire('i18n', 'sendkindle'),
      // },{
      //   field: 'wordcounter',
      //   label: app.fire('i18n', 'wordcounter'),
      // },{
      //   field: 'readprogress',
      //   label: app.fire('i18n', 'readprogress'),
      // },
    ]
  };
}
