import { useContext } from 'react';
import { AppContext } from 'app/context';

export default function useConfig(){
  const app = useContext(AppContext);

  return {
    field: 'config',
    label: app.fire('i18n', 'config'),
    export: app.fire('i18n', 'export'),
    import: app.fire('i18n', 'import'),
    upload: app.fire('i18n', 'upload'),
    limit: app.fire('i18n', 'upload_limit'),
    data: {
      autosync: {
        field: 'autosync',
        label: app.fire('i18n', 'autosync'),
      }
    }
  };
}
