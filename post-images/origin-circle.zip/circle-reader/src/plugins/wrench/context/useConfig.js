import { useContext } from 'react';
import { AppContext } from 'app/context';

export default function(){
  const app = useContext(AppContext);

  return {
    field: 'config',
    label: app.fire('i18n', 'config'),
    export: app.fire('i18n', 'export'),
    import: app.fire('i18n', 'import'),
    upload: app.fire('i18n', 'upload'),
  };
}
