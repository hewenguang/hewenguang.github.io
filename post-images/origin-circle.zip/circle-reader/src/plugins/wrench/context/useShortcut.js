import { useContext } from 'react';
import { AppContext } from 'app/context';

export default function useShortcut(){
  const app = useContext(AppContext);

  return {
    field: 'shortcut',
    label: app.fire('i18n', 'shortcut'),
    enabled: 'shortcut-enabled',
    prompt: {
      label: app.fire('i18n', 'prompt'),
    },
    alert: {
      field: 'shortcut-alert',
      message: app.fire('i18n', 'shortcut_alert'),
    },
    data: [{
      field: 'srt-enter-or-exit',
      label: app.fire('i18n', 'enter_or_exit'),
    },{
      field: 'srt-exit',
      label: app.fire('i18n', 'exit'),
    },{
      field: 'srt-whitelist',
      label: app.fire('i18n', 'whitelist'),
    },{
      field: 'srt-blacklist',
      label: app.fire('i18n', 'blacklist'),
    },{
      field: 'srt-focus',
      label: app.fire('i18n', 'focus'),
      tooltip: app.fire('i18n', 'focus_tooltip'),
    },{
      field: 'srt-option',
      label: app.fire('i18n', 'setting'),
    },
    // {
    //   field:'srt-paper',
    //   label:app.fire('i18n', 'paper'),
    // },{
    //   field:'srt-outline',
    //   label:app.fire('i18n', 'outline'),
    // },{
    //   field:'srt-backtop',
    //   label:app.fire('i18n', 'backtop'),
    // },{
    //   field:'srt-exitclose',
    //   label:app.fire('i18n', 'exitclose'),
    // },{
    //   field:'srt-nextpage',
    //   label:app.fire('i18n', 'nextpage'),
    // },{
    //   field:'srt-autorun',
    //   label:app.fire('i18n', 'autorun'),
    // },{
    //   field:'srt-shortcut-enabled',
    //   label:app.fire('i18n', 'shortcut'),
    // },{
    //   field:'srt-contextmenu-enabled',
    //   label:app.fire('i18n', 'contextmenu'),
    // },{
    //   field:'srt-export',
    //   label:app.fire('i18n', 'export'),
    // }
    ]
  };
}
