import useApp from 'app/context/useApp';
import useShortcut from 'app/context/useShortcut';

export default function(){
  const app = useApp();
  const shortcut = useShortcut();

  return {
    field: 'shortcut',
    label: app.fire('i18n', 'shortcut'),
    enabled: 'shortcut-enabled',
    prompt: app.fire('i18n', 'got_it'),
    data: shortcut,
    alert: {
      field: 'shortcut-alert',
      message: app.fire('i18n', 'shortcut_alert'),
    },
  };
}
