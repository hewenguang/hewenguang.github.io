
import { useContext } from 'react';
import { AppContext } from 'app/context';

export default function useContextmenu(){
  const app = useContext(AppContext);

  return {
    field:'contextmenu',
    label:app.fire('i18n', 'contextmenu'),
    enabled:'contextmenu-enabled',
    data:[{
      field:'ctx-whitelist',
      label:app.fire('i18n', 'whitelist'),
    },{
      field:'ctx-blacklist',
      label:app.fire('i18n', 'blacklist'),
    },{
      field:'ctx-focus',
      label:app.fire('i18n', 'focus'),
      tooltip: app.fire('i18n', 'focus_tooltip'),
    },{
      field:'ctx-option',
      label:app.fire('i18n', 'setting'),
    },
    // {
    //   field:'ctx-paper',
    //   label:app.fire('i18n', 'paper'),
    // },{
    //   field:'ctx-outline',
    //   label:app.fire('i18n', 'outline'),
    // },{
    //   field:'ctx-backtop',
    //   label:app.fire('i18n', 'backtop'),
    // },{
    //   field:'ctx-exitclose',
    //   label:app.fire('i18n', 'exitclose'),
    // },{
    //   field:'ctx-nextpage',
    //   label:app.fire('i18n', 'nextpage'),
    // },{
    //   field:'ctx-autorun',
    //   label:app.fire('i18n', 'autorun'),
    // },{
    //   field:'ctx-shortcut-enabled',
    //   label:app.fire('i18n', 'shortcut'),
    // },{
    //   field:'ctx-contextmenu-enabled',
    //   label:app.fire('i18n', 'contextmenu'),
    // },{
    //   field:'ctx-export',
    //   label:app.fire('i18n', 'export'),
    // }
    ],
  };
}
