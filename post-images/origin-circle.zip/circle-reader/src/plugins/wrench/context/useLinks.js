import useApp from 'app/context/useApp';

export default function(){
  const app = useApp();

  return {
    field: 'links',
    label: app.fire('i18n', 'links'),
    data: [{
      title: app.fire('i18n', 'website'),
      url: app.to(),
    },{
      title: app.fire('i18n', 'useage'),
      url: app.to('usage'),
    },{
      title: app.fire('i18n', 'agreement'),
      url: app.to('agreement'),
    },{
      title: app.fire('i18n', 'privacy'),
      url: app.to('privacy'),
    },{
      title: app.fire('i18n', 'faq'),
      url: app.to('faq'),
    },{
      title: app.fire('i18n', 'update'),
      url: app.to('changelog'),
    },{
      title: app.fire('i18n', 'feedback'),
      url: app.to('feedback'),
    },{
      title: app.fire('i18n', 'download'),
      url: app.to('download'),
    },{
      title: app.fire('i18n', 'donate'),
      url: app.to('donate'),
    }],
  };
}
