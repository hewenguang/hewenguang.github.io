import useApp from 'app/context/useApp';

export default function(){
  const app = useApp();

  return {
    field:'contextmenu',
    label:app.fire('i18n', 'contextmenu'),
    enabled:'contextmenu-enabled',
    data:[{
      field:'ctx-whitelist',
      label:app.fire('i18n', 'togglewhitelist'),
    },{
      field:'ctx-blacklist',
      label:app.fire('i18n', 'toggleblacklist'),
    },{
      field:'ctx-focus',
      label:app.fire('i18n', 'focus'),
      tooltip: app.fire('i18n', 'focus_tooltip'),
      learn_more: app.to('node/37'),
    },{
      field:'ctx-option',
      label:app.fire('i18n', 'setting'),
    }],
  };
}
