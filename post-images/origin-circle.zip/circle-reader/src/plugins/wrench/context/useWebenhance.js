import useApp from 'app/context/useApp';

export default function(){
  const app = useApp();

  return {
    field: 'webenhance',
    label: app.fire('i18n', 'webenhance'),
    data: [{
      field: 'enhance-outline',
      label: app.fire('i18n', 'outline'),
      tooltip: app.fire('i18n', 'outline_tooltip'),
    },{
      field: 'enhance-backtop',
      label: app.fire('i18n', 'backtop'),
    }],
  };
}
