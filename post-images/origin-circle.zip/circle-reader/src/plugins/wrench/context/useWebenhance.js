import { useContext } from 'react';
import { AppContext } from 'app/context';

export default function useWebenhance(){
  const app = useContext(AppContext);

  return {
    field: 'webenhance',
    label: app.fire('i18n', 'webenhance'),
    data: [{
      field: 'enhance-outline',
      label: app.fire('i18n', 'outline'),
      tooltip: app.fire('i18n', 'outline_tooltip'),
    },{
      field: 'enhance-backtop',
      label: app.fire('i18n', 'backtop'),
    }],
  };
}
