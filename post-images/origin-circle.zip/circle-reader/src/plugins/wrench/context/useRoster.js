import useApp from 'app/context/useApp';

export default function(){
  const app = useApp();

  return {
    white: {
      field: 'whitelist',
      label: app.fire('i18n', 'whitelist'),
    },
    black:{
      field: 'blacklist',
      label: app.fire('i18n', 'blacklist'),
    },
    url: app.fire('i18n', 'url'),
    filter: app.fire('i18n', 'filter'),
    url_message: app.fire('i18n', 'url_message'),
    title: app.fire('i18n', 'title'),
    title_message: app.fire('i18n', 'title_message'),
  };
}
