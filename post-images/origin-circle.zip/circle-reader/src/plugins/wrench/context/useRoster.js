import { useContext } from 'react';
import { AppContext } from 'app/context';

export default function useRoster(){
  const app = useContext(AppContext);

  return {
    white: {
      field: 'whitelist',
      label: app.fire('i18n', 'whitelist'),
    },
    black:{
      field: 'blacklist',
      label: app.fire('i18n', 'blacklist'),
    },
    add: app.fire('i18n', 'add'),
    url: app.fire('i18n', 'url'),
    url_message: app.fire('i18n', 'url_message'),
    title: app.fire('i18n', 'title'),
    title_message: app.fire('i18n', 'title_message'),
    filter: app.fire('i18n', 'filter'),
    remove: app.fire('i18n', 'remove'),
  };
}
