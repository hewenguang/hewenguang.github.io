import useApp from 'app/context/useApp';

export default function(){
  const app = useApp();

  return {
    defaultValue: '',
    field: 'stylesheet',
    narrow: app.fire('i18n', 'narrow'),
    enlarge: app.fire('i18n', 'enlarge'),
    label: app.fire('i18n', 'stylesheet'),
  };
}
