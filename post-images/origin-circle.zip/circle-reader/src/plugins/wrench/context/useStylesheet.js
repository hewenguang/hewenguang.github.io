import { useContext } from 'react';
import { AppContext } from 'app/context';

export default function useStylesheet(){
  const app = useContext(AppContext);

  return {
    field: 'stylesheet',
    defaultValue: '',
    narrow: app.fire('i18n', 'narrow'),
    enlarge: app.fire('i18n', 'enlarge'),
    copy: app.fire('i18n', 'copy'),
    copy_success: app.fire('i18n', 'copy_success'),
    copy_fail: app.fire('i18n', 'copy_fail'),
    label: app.fire('i18n', 'stylesheet'),
    theme: {
      label: app.fire('i18n', 'stylesheet_theme'),
      data: [{
        label: '123',
        value: '123'
      }],
    },
  };
}
