import { useContext } from 'react';
import { AppContext } from 'app/context';

export default function useHelpcenter(){
  const app = useContext(AppContext);

  return {
    field: 'helpcenter',
    label: app.fire('i18n', 'helpcenter'),
    data: [
      {
        title: app.fire('i18n', 'feedback'),
        url: 'https://support.qq.com/products/317910',
      },{
        title: app.fire('i18n', 'useage'),
        url: 'https://ranhe.xyz/circle-usage/',
      },{
        title: app.fire('i18n', 'update'),
        url: 'https://ranhe.xyz/circle-changelog/',
      },{
        title: app.fire('i18n', 'faq'),
        url: 'https://ranhe.xyz/circle-faq/',
      },
    ],
  };
}
