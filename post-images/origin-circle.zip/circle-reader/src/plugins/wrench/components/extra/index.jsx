import React from 'react';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import Switch from 'app/components/switch';
import useOption from 'app/context/useOption';
import { authorize } from 'app/components/authorize';

export default function(props){
  const { field, onChange } = props;
  const app = useApp();
  const user = useUser();
  const [ option, change ] = useOption({
    field,
    defaultValue: false,
  });

  return (
    <div onClick={event => {event.stopPropagation()}}>
      <Switch
        checked={option}
        placement="left"
        tooltip={app.fire('i18n', option ? 'global_enabled' : 'global_disabled')}
        onChange={checked => {
          if(!user.member && !authorize(field)){
            app.fire('upgrade', 'upgrade');
            return;
          }
          change(checked);
          onChange && onChange(checked);
        }}
      />
    </div>
  );
}
