import React from 'react';
import { message, Tooltip } from 'antd';
import copy from 'copy-to-clipboard';
import { CopyOutlined } from '@ant-design/icons';
import useStylesheet from 'plugin/wrench/context/useStylesheet';

export default function(props){
  const { text, options } = props;
  const disabled = !text;
  const stylesheet = useStylesheet();

  return (
    <Tooltip title={stylesheet.copy}>
      <CopyOutlined
        style={disabled ? {color:'#ccc'}: undefined}
        onClick={() => {
          if(disabled){
            return;
          }
          if(copy(text, options)){
            message.success(stylesheet.copy_success);
          } else {
            message.error(stylesheet.copy_fail);
          }
        }}
      />
    </Tooltip>
  );
}

