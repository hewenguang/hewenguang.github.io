import useApp from 'app/context/useApp';
import { Modal, Form, Input, Alert } from 'antd';
import React, { useState, useEffect } from 'react';
import useRoster from 'plugin/wrench/context/useRoster';

export default function(props){
  const { data, table, label, onCancel, onSuccess } = props;
  const app = useApp();
  const roster = useRoster();
  const [ form ] = Form.useForm();
  const [ error, setError ] = useState('');
  const visible = data && data.url;
  const update = data && data.create;
  const initialValues = !update && location.href.startsWith('chrome') ? {} : data;

  useEffect(() => {
    if(!visible){
      return;
    }
    form.resetFields();
  },[ visible ]);

  return (
    <Modal
      width={430}
      className="modal"
      visible={visible}
      okText={app.fire('i18n', 'ok')}
      cancelText={app.fire('i18n', 'cancel')}
      title={`${app.fire('i18n', update ? 'edit' : 'add')}${label}`}
      onCancel={() => {
        form.resetFields();
        onCancel && onCancel();
      }}
      onOk={() => {
        setError('');
        form.validateFields().then(values => {
          app.fire('send', 'roster', {
            table,
            url: values.url,
            title: values.title,
            id: update ? initialValues.url : '',
          }, function({error}){
            if(error){
              setError(error);
            } else {
              onSuccess && onSuccess();
            }
          });
        });
      }}
    >
      {error && (
        <Alert
          showIcon
          type="error"
          message={error}
        />
      )}
      <Form
        form={form}
        labelCol={{span:5}}
        wrapperCol={{span:18}}
        initialValues={initialValues}
      >
        <Form.Item
          label={roster.title}
          name="title"
          rules={[{
            required: true,
            message: roster.title_message,
          }]}
        >
          <Input
            allowClear
            type="text"
          />
        </Form.Item>
        <Form.Item
          label={roster.url}
          name="url"
          rules={[{
            required: true,
            message: roster.url_message,
          }]}
        >
          <Input
            allowClear
            type="url"
            onChange={() => setError('')}
          />
        </Form.Item>
        {/* todo 自动全屏，自动滚动 */}
      </Form>
    </Modal>
  );
}
