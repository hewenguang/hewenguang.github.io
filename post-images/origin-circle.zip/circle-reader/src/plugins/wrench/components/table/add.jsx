import { AppContext } from 'app/context';
import { Modal, Form, Input, Alert } from 'antd';
import React, { useState, useContext } from 'react';
import useRoster from 'plugin/wrench/context/useRoster';

export default function(props){
  const { table, label, visible, onCancel, onSuccess } = props;
  const roster = useRoster();
  const [ form ] = Form.useForm();
  const app = useContext(AppContext);
  const [ error, setError ] = useState('');
  const initialValues = location.href.startsWith('chrome') ? {} : {
    url: location.href,
    title: document.title,
  };

  return (
    <Modal
      width={430}
      className="modal"
      visible={visible}
      title={`${roster.add}${label}`}
      onCancel={() => {
        form.resetFields();
        onCancel && onCancel();
      }}
      onOk={() => {
        setError('');
        form.validateFields().then(values => {
          app.fire('send', 'roster', {
            table,
            url: values.url,
            title: values.title,
          }, function({error}){
            if(error){
              setError(error);
            } else {
              onSuccess && onSuccess();
            }
          });
        });
      }}
    >
      {error && (
        <Alert
          showIcon
          type="error"
          message={error}
        />
      )}
      <Form
        form={form}
        labelCol={{span:5}}
        wrapperCol={{span:18}}
        initialValues={initialValues}
      >
        <Form.Item
          label={roster.title}
          name="title"
          rules={[{
            required: true,
            message: roster.title_message,
          }]}
        >
          <Input
            allowClear
            type="text"
          />
        </Form.Item>
        <Form.Item
          label={roster.url}
          name="url"
          rules={[{
            required: true,
            message: roster.url_message,
          }]}
        >
          <Input
            allowClear
            type="url"
            onChange={() => setError('')}
          />
        </Form.Item>
      </Form>
    </Modal>
  );
}
