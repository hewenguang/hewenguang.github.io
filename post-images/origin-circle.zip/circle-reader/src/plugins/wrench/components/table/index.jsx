import Icon from 'app/components/icon';
import useApp from 'app/context/useApp';
import React, { useState, useEffect } from 'react';
import { List, Button, Input, Table, Popconfirm, Menu, Dropdown } from 'antd';
import Add from './add';
import useTable from 'app/context/useTable';
import useRoster from 'plugin/wrench/context/useRoster';
import './index.less';

export default function(props){
  const { table, label } = props;
  const app = useApp();
  const roster = useRoster();
  const [ action, setAction ] = useState({});
  const [ data, params, change ] = useTable({ table });

  useEffect(() => {
    const hook = app.on(`roster-${table}`, function({callback} = {}){
      change.refetch();
      callback && callback();
    });
    return () => {
      app.remove(hook);
    };
  }, []);

  return (
    <>
      <List>
        <List.Item>
          <Add
            table={table}
            label={label}
            data={action}
            onCancel={() => {
              setAction({});
            }}
            onSuccess={() => {
              change.refetch();
              setAction({});
            }}
          />
          <Button
            type="primary"
            onClick={() => {
              setAction({
                url: location.href,
                title: document.title,
              });
              app.fire('send', 'analytics', {event:`action-add-${table}`});
            }}
          >
            {app.fire('i18n', 'add')}
          </Button>
          <Input
            style={{width:132}}
            defaultValue={params.filter}
            placeholder={roster.filter}
            prefix={<Icon name="search" />}
            onChange={event => {
              utils.wait(function(){
                change.setStart(1);
                change.setFilter(event.target.value);
                app.fire('send', 'analytics', {event:`action-search-${table}`});
              });
            }}
          />
        </List.Item>
      </List>
      <Table
        rowKey="url"
        dataSource={data}
        className="table"
        locale={{
          emptyText:(
            <div className="empty">
              {app.fire('i18n', 'empty')}
            </div>
          ),
        }}
        pagination={{
          simple:true,
          size: 'small',
          pageSize: params.limit,
          current: params.start,
          total: params.total,
          onChange: change.setStart,
          position: ['bottomCenter'],
        }}
        columns={[{
          width:'48%',
          title: roster.title,
          dataIndex:'title',
          render: val => (
            <div className="table-cell">
              {val}
            </div>
          ),
        },
        {
          width:'48%',
          title: roster.url,
          dataIndex: 'url',
          render: (val) => (
            <div className="table-cell">
              {val}
            </div>
          ),
        },
        {
          title:'',
          dataIndex:'action',
          render: (val, record) => (
            <Dropdown
              trigger="click"
              overlay={
                <Menu>
                  <Menu.Item
                    key="edit"
                    onClick={() => {
                      setAction(record);
                      app.fire('send', 'analytics', {event:`action-edit-${table}`});
                    }}
                  >
                    {app.fire('i18n', 'edit')}
                  </Menu.Item>
                  <Menu.Item key="delete">
                    <Popconfirm
                      placement="left"
                      okText={app.fire('i18n', 'ok')}
                      cancelText={app.fire('i18n', 'cancel')}
                      title={`${app.fire('i18n', 'remove')} ${record.title} ?`}
                      onConfirm={() => {
                        const url = record.url;
                        const location = utils.location(url);
                        const host = location.host;
                        app.fire('send', 'db', { execute:'get', table, name:host }, function({error, data = []}){
                          if(error){
                            app.fire('error', error);
                          } else {
                            if(data.length === 1 && data[0].url === url){
                              app.fire('send', 'db', {execute:'remove', table, name:host}, function(result){
                                if(result.error){
                                  app.fire('error', result.error);
                                } else {
                                  change.refetch();
                                }
                              });
                            } else {
                              const newData = [];
                              data.forEach(function(item){
                                if(item.url !== url){
                                  newData.push(item);
                                }
                              });
                              app.fire('send', 'db', Object.assign({execute:'add', table, name:host, value:newData}), function(result){
                                if(result.error){
                                  app.fire('error', result.error);
                                } else {
                                  change.refetch();
                                }
                              });
                            }
                          }
                          app.fire('send', 'analytics', {event:`action-remove-${table}`});
                        });
                      }}
                    >
                      {app.fire('i18n', 'remove')}
                    </Popconfirm>
                  </Menu.Item>
                </Menu>
              }
            >
              <Icon name="more" className="icon-menu" />
            </Dropdown>
          ),
        }]}
      />
    </>
  );
}
