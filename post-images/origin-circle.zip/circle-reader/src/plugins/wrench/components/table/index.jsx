import { AppContext } from 'app/context';
import React, { useState, useContext, useEffect } from 'react';
import { CloseOutlined, SearchOutlined } from '@ant-design/icons';
import { List, Button, Input, Table, Popconfirm } from 'antd';
import Add from './add';
import useTable from 'app/context/useTable';
import useRoster from 'plugin/wrench/context/useRoster';
import './index.less';

export default function(props){
  const { table, label } = props;
  const roster = useRoster();
  const app = useContext(AppContext);
  const [ data, params, change ] = useTable({ table });
  const [ visible, setVisible ] = useState(false);

  useEffect(() => {
    const hook = app.on(`roster-${table}`, function({callback} = {}){
      change.refetch();
      callback && callback();
    });
    return () => {
      app.remove(hook);
    };
  }, []);

  return (
    <>
      <List>
        <List.Item>
          <Add
            table={table}
            label={label}
            visible={visible}
            onCancel={() => {
              setVisible(false);
            }}
            onSuccess={() => {
              change.refetch();
              setVisible(false);
            }}
          />
          <Button
            type="primary"
            onClick={() => setVisible(true)}
          >
            {roster.add}
          </Button>
          <Input
            style={{width:132}}
            defaultValue={params.filter}
            prefix={<SearchOutlined />}
            placeholder={roster.filter}
            onChange={event => {
              utils.wait(function(){
                change.setStart(1);
                change.setFilter(event.target.value);
              });
            }}
          />
        </List.Item>
      </List>
      <Table
        rowKey="title"
        dataSource={data}
        className="table"
        pagination={{
          simple:true,
          size: 'small',
          pageSize: params.limit,
          current: params.start,
          total: params.total,
          onChange: change.setStart,
          position: ['bottomCenter'],
        }}
        columns={[{
          width:'48%',
          title: roster.title,
          dataIndex:'title',
          render: val => (
            <div className="table-cell">
              {val}
            </div>
          ),
        },
        {
          width:'48%',
          title: roster.url,
          dataIndex: 'url',
          render: (val) => (
            <div className="table-cell">
              {val}
            </div>
          ),
        },
        {
          title:'',
          dataIndex:'action',
          render: (val, record) => (
            <Popconfirm
              placement="left"
              title={`${roster.remove} ${record.title} ?`}
              onConfirm={() => {
                const url = record.url;
                const location = utils.location(url);
                const host = location.host;
                app.fire('send', 'db', { execute:'get', table, name:host }, function({error, data = []}){
                  if(error){
                    app.fire('error', error);
                  } else {
                    if(data.length === 1 && data[0].url === url){
                      app.fire('send', 'db', {execute:'remove', table, name:host}, function(result){
                        if(result.error){
                          app.fire('error', result.error);
                        } else {
                          change.refetch();
                        }
                      });
                    } else {
                      const newData = [];
                      data.forEach(function(item){
                        if(item.url !== url){
                          newData.push(item);
                        }
                      });
                      app.fire('send', 'db', Object.assign({execute:'add', table, name:host, value:newData}), function(result){
                        if(result.error){
                          app.fire('error', result.error);
                        } else {
                          change.refetch();
                        }
                      });
                    }
                  }
                });
              }}
            >
              <CloseOutlined />
            </Popconfirm>
          ),
        }]}
      />
    </>
  );
}
