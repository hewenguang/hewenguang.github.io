import React from 'react';
import useApp from 'app/context/useApp';
import Switch from 'app/components/switch';
import useOption from 'app/context/useOption';

export default function(props){
  const { field, table, onChange } = props;
  const app = useApp();
  const [ option, optionChange ] = useOption({
    field,
    table,
    defaultValue: false,
  });

  return (
    <Switch
      checked={option}
      onChange={checked => {
        if(onChange(checked)){
          optionChange(checked);
          app.fire(field, checked);
        }
      }}
    />
  );
}
