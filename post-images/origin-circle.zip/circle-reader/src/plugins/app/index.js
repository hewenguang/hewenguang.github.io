import controller from './client';

App.register('app', ['utils', 'dom'], function(utils, dom){
  const app = this;

  // 控制器
  controller(app);

  function blacklist(callback){
    app.fire('send', 'db',{
      execute: 'get',
      table: 'blacklist',
      name: location.hostname,
    }, function({error, data = []}){
      if(error){
        app.fire('loading', false);
        app.fire('error', error);
        return;
      }
      let parser = true;
      const href = location.href.replace(/#.*$/, '');
      utils.each(data, item => {
        const url = item.url;
        if(url === href || href.split(url).length > 1){
          parser = false;
          return true;
        }
      });
      if(parser){
        callback && callback();
      } else {
        app.fire('loading', false);
        app.fire('send', 'status', {action: 'disable'});
        // 如果在黑名单直接退出
        app.fire('render-destory');
      }
    });
  }
  function shortcuts(){
    app.fire('send', 'db', {
      execute: 'get',
      table: 'wrench',
      name: 'shortcut-enabled',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        app.cache('shortcut-enabled', !!data);
      }
    });
    app.fire('send', 'db', {
      table: 'shortcut',
      execute: 'all',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        if(!data){
          return;
        }
        app.cache('shortcut', data);
      }
    });
  }

  app.on('visiblechange', function(visible){
    if(!visible){
      return;
    }
    // 快捷键恢复
    blacklist();
    // 黑名单恢复
    shortcuts();
  });

  // 禁用当前页面
  app.fire('send', 'status');

  // 启动应用
  blacklist(function(){
    dom.ready(function(){
      if(document.contentType.indexOf('text/html') >= 0){
        app.load('parser');
      } else if(document.contentType.indexOf('text/plain') >= 0){
        app.load('plain');
      }
    });
  });

  // 快捷键系统
  shortcuts();

  // 加载调试工具
  app.cache('debug') && app.load('debug');

  // location.hostname === 'circlereader' && setTimeout(function(){
  //   const target = document.getElementById('app');
  //   if(!utils.isElement(target)){
  //     return;
  //   }
  //   target.setAttribute('circlereader', 'installed');
  // }, 500);
});
