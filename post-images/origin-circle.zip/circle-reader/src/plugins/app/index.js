App.register('app', ['utils', 'dom'], function(utils, dom){
  const app = this;

  // action 当前页面禁用
  app.fire('send', 'status');

  // 渲染
  app.on('action-browser', function({callback} = {}){
    app.fire('render');
    app.load('render');
    callback && callback();
  });
  // 黑名单判断
  app.on('blacklist-config', function(callback){
    app.fire('send', 'db',{
      execute: 'get',
      table: 'blacklist',
      name: location.hostname,
    }, function({error, data = []}){
      if(error){
        app.fire('error', error);
        return;
      }
      let parser = true;
      const href = location.href.replace(/#.*$/, '');
      utils.each(data, item => {
        const url = item.url;
        if(url === href || href.split(url).length > 1){
          parser = false;
          return true;
        }
      });
      if(parser){
        callback && callback();
      } else {
        app.fire('send', 'status', {action: 'disable'});
        // 如果在黑名单直接退出
        app.fire('render-destory');
      }
    });
  });
  app.fire('blacklist-config', function(){
    dom.ready(function(){
      if(document.contentType.indexOf('text/html') >= 0){
        app.load('parser');
      } else if(document.contentType.indexOf('text/plain') >=0 ){
        app.load('plain');
      }
    });
  });

  // 快捷键
  app.on('shortcut-config', function(){
    app.fire('send', 'db', {
      execute: 'get',
      table: 'wrench',
      name: 'shortcut-enabled',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        app.cache('shortcut-enabled', !!data);
      }
    });
    app.fire('send', 'db', {
      table: 'shortcut',
      execute: 'all',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        if(!data){
          return;
        }
        app.cache('shortcut', data);
      }
    });
  });
  app.fire('shortcut-config');

  // 切换回来更新配置
  app.on('visiblechange', function(visible){
    if(!visible){
      return;
    }
    // 快捷键恢复
    app.fire('blacklist-config');
    // 黑名单恢复
    app.fire('shortcut-config');
  });
  // 后端消息
  app.on('notice', function({request, callback} = {}){
    app.fire('message', {
      key: request.key,
      type: request.status,
      message: request.message,
      description: request.description,
    });
    callback && callback();
  });
  // 聚焦模式
  app.on('focusmode', function({callback} = {}){
    app.fire('focus');
    app.load('focus');
    callback && callback();
  });
  // 升级高级帐户
  app.on('upgrade', function(action){
    app.load('user', function(){
      app.fire('upgrade', action);
    }, true);
  }, true);
  app.on('srt-enter-or-exit', function(){
    const node = app.cache('node');
    if(!node.article){
      return;
    }
    app.fire('render');
    app.load('render');
  });
  app.on('srt-whitelist', function(){
    app.fire('send', 'roster', {
      table: 'whitelist',
      url: location.href,
      title: document.title,
    });
  });
  app.on('srt-blacklist', function(){
    app.fire('send', 'roster', {
      table: 'blacklist',
      url: location.href,
      title: document.title,
    });
  });
  app.on('srt-focus', function(){
    app.fire('focusmode');
  });
  app.on('srt-option', function(){
    app.fire('send', 'open-option-page');
  });

  window.addEventListener('scroll', function(){
    if(!app.cache('running')){
      return;
    }
    utils.wait(function(){
      app.fire('scroll', dom.scrollTop());
    }, 200);
  });
  window.addEventListener('resize', function(){
    if(!app.cache('running')){
      return;
    }
    utils.wait(function(){
      app.fire('resize', dom.clientHeight());
    }, 200);
  });
  document.addEventListener('keydown', function(event){
    if(!app.cache('shortcut-enabled')){
      return;
    }
    const key = utils.toLower(event.key);
    if(['alt', 'control', 'meta', 'shift'].includes(key)){
      return;
    }
    const activeElement = document.activeElement;
    if(activeElement && !dom.tag(activeElement, 'body')){
      return;
    }
    if(utils.isFunction(window.getSelection)){
      const select = window.getSelection();
      if(select.type === 'Range' && utils.isTextNode(select.focusNode)){
        return;
      }
    }
    let hook;
    const keys = [key];
    event.altKey && keys.unshift('alt');
    event.ctrlKey && keys.unshift('ctrl');
    event.metaKey && keys.unshift('meta');
    event.shiftKey && keys.unshift('shift');
    const keysValue = keys.join('+');
    utils.each(app.cache('shortcut'), function(item, key){
      if(item.checked && item.value === keysValue){
        hook = key;
        return true;
      }
    });
    hook && app.fire(hook, key, event);
  });
  document.addEventListener('visibilitychange', function(){
    app.fire('visiblechange', document.visibilityState === 'visible');
  });
  // 开发辅助工具
  app.cache('debug') && app.load('debug');
});
