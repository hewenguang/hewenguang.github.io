import pjax from './pjax';

export default function(app){
  // pjax 支持
  pjax(app);

  // 渲染引擎
  function render(){
    const node = app.cache('node');
    if(!node || !node.article){
      return;
    }
    app.fire('render');
    app.load('render');
  }
  app.on('srt-enter-or-exit', render);
  app.on('action-browser', function({callback} = {}){
    callback && callback();
    render();
  });

  // 黑/白名单
  utils.each(['whitelist','blacklist'], function(table){
    app.on(`roster-${table}`, function({callback} = {}){
      callback && callback();
      if(table === 'whitelist'){
        const node = app.cache('node');
        if(node && node.article && !app.cache('running')){
          app.fire('render-start');
          app.load('render');
        } else {
          app.fire('message', {
            key: table,
            type: 'success',
            message: app.fire('i18n', 'refresh_to_active'),
          });
        }
      } else {
        if(app.cache('running')){
          app.fire('render-destory');
        } else {
          app.fire('message', {
            key: table,
            type: 'success',
            message: app.fire('i18n', 'refresh_to_active'),
          });
        }
        app.fire('send', 'status', {action: 'disable'});
      }
    });
    app.on(table, function(url, title){
      app.fire('send', 'roster', {
        table,
        url: url || location.href,
        title: title || document.title,
      }, function(){
        app.fire(`roster-${table}`);
      });
    });
    app.on(`srt-${table}`, function(){
      app.fire(table);
    });
    app.on(`srt-${table}-site`, function(){
      app.fire(table, location.hostname, location.hostname);
    });
  });

  // 聚焦模式(注：共用)
  app.on('srt-focus', function({callback} = {}){
    callback && callback();
    app.fire('focus');
    app.load('focus');
  });

  // 选项页面
  app.on('srt-option', function(){
    app.fire('send', 'open-option-page');
  });

  //打开新页面
  app.on('to', function(url){
    app.fire('send', 'tab', {
      action: 'create',
      value: {url},
    });
  });

  // 升级高级帐户
  app.on('upgrade', function(){
    app.fire('user');
    app.load('user');
  });

  window.addEventListener('scroll', function(){
    if(!app.cache('running')){
      return;
    }
    utils.wait(function(){
      app.fire('scroll', dom.scrollTop());
    }, 200);
  });
  window.addEventListener('resize', function(){
    if(!app.cache('running')){
      return;
    }
    utils.wait(function(){
      app.fire('resize', dom.clientHeight());
    }, 200);
  });
  document.addEventListener('visibilitychange', function(){
    app.fire('visiblechange', document.visibilityState === 'visible');
  });

  let timer;
  let count = 0;
  let keys = [];
  function fire(keys, event){
    let hook;
    utils.each(app.cache('shortcut'), function(item, key){
      if(item.checked && item.value === keys){
        hook = key;
        return true;
      }
    });
    if(!hook){
      return;
    }
    if(['srt-enter-or-exit', 'srt-focus', 'srt-option'].includes(hook)){
      app.fire(hook, event);
      app.fire('send', 'analytics', {event:hook});
    } else {
      if(app.cache('running')){
        app.fire(hook, event);
        app.fire('send', 'analytics', {event:hook});
      }
    }
  }
  document.addEventListener('keydown', function(event){
    if(!app.cache('shortcut-enabled')){
      return;
    }
    if(!app.cache('running')){
      const activeElement = document.activeElement;
      if(activeElement && !dom.tag(activeElement, 'body')){
        return;
      }
      if(utils.isFunction(window.getSelection)){
        const select = window.getSelection();
        if(select.type === 'Range' && utils.isTextNode(select.focusNode)){
          return;
        }
      }
    }
    const key = dom.keyboard(event);
    key && keys.push(key);
    count++;
    if (count === 1){
      timer = setTimeout(function() {
        count = 0;
        if(keys.length <= 0){
          return;
        }
        fire(keys.join(' '));
        keys = [];
      }, 500);
    } else if (count === 2) {
      timer && clearTimeout(timer);
      count = 0;
      if(keys.length <= 0){
        return;
      }
      fire(keys.join(' '));
      keys = [];
    }
  });
}
