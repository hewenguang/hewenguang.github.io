export default function(app){
  app.on('render-ready', function(){
    app.cache('pjax-changeurl', location.href);
    app.fire('send', 'pjax-start', {
      hostname: location.hostname,
    });
  });
  app.on('pjax-change', function({request, callback} = {}){
    callback && callback();
    if(!app.cache('pjax-changeurl')){
      return;
    }
    if(!request || !request.url || request.url === app.cache('pjax-changeurl')){
      return;
    }
    utils.wait(function(){
      app.fire('send', 'status', function(){
        const { url, title, article } = app.fire('parser', document);
        if(utils.isElement(article)){
          // 清除记录
          app.cache('lastnodeurl', '');
          app.fire('send', 'status', {action: 'wait'});
          app.cache('node', {
            url,
            title,
            article,
            cover: app.fire('parser-cover', article),
          });
          app.fire('empty-anchor');
          app.fire('empty-page', function(){
            app.fire('render-page');
          });
        } else {
          app.fire('parser-fail');
        }
      });
    }, 1000);
  });
}
