App.register('app', ['utils', 'database', 'wrench', 'user', 'cron', 'pjax', 'analytics'], function(utils){
  const app = this;

  // 延迟触发系统动作
  app.on('install', function(){
    app.tabs.create({url: 'https://ranhe.xyz/circle-usage'});
    app.runtime.setUninstallURL('https://ranhe.xyz/circle-uninstall');
  });
  app.on('update', function(){
    app.runtime.setUninstallURL('https://ranhe.xyz/circle-uninstall');
  });
  app.fire('system-install');
  app.fire('system-update');

  // 看门狗
  app.on('watchdog', function({callback}){
    callback && callback();
    app.fire('cron', function(){
      // 检查用户权限
      const user = app.cache('user');
      if(!user || !user.member){
        app.fire('db', {
          request:{
            skip: true,
            value: false,
            execute: 'add',
            table: 'wrench',
            name: 'autosync',
          },
        });
        return;
      }
      if(!user.expire){
        return;
      }
      const now = +new Date;
      const expire = +new Date(user.expire);
      if(expire - now > 0){
        return;
      }
      app.fire('user_clean', function(){
        app.fire('retrieve');
        app.fire('db', {
          request:{
            skip: true,
            value: false,
            execute: 'add',
            table: 'wrench',
            name: 'autosync',
          },
        });
      });
    });
  });
  // 修改状态
  app.on('status', function({request: { action }, sender, callback} = {}){
    const tabId = sender.tab.id;
    switch(action){
      case 'wait':
        app.browserAction.enable(tabId);
        app.browserAction.setIcon({
          tabId,
          path: {
            16: 'icons/16-wait.png',
            32: 'icons/32-wait.png',
          },
        });
        break;
      case 'done':
        app.browserAction.setIcon({
          tabId,
          path: {
            16: 'icons/16-done.png',
            32: 'icons/32-done.png',
          },
        });
        break;
      case 'disable':
        app.browserAction.disable(tabId);
        app.browserAction.setIcon({
          tabId,
          path: {
            16: 'icons/16-disable.png',
            32: 'icons/32-disable.png',
          },
        });
        break;
      default:
        app.browserAction.disable(tabId);
        app.browserAction.setIcon({
          tabId,
          path: {
            16: 'icons/16-default.png',
            32: 'icons/32-default.png',
          },
        });
        break;
    }
    callback && callback();
  });
  // tab 操作相关
  app.on('tab', function({request: { action }, sender, callback}){
    const tabId = sender.tab.id;
    switch(action){
      case 'remove':
        app.tabs.remove(tabId, callback);
        break;
    }
  });
  // whitelist blacklist
  app.on('roster', function({request, callback} = {}){
    const table = request.table;
    const url = request.url.replace(/#.*$/, '');
    const title = request.title;
    const location = utils.location(url);
    const host = location.host;
    app.fire('db', {
      request: {
        table,
        name:host,
        execute:'get',
      },
      callback: function(error, data = []){
        if(error){
          callback && callback(error);
        } else {
          let exist;
          utils.each(data, function(item){
            if(item.url === url){
              exist = true;
              return true;
            }
          });
          if(exist){
            if(data.length === 1){
              app.fire('db', {
                request: {
                  table,
                  name:host,
                  execute:'remove',
                },
                callback: function(error){
                  callback && callback(error);
                  app.fire('send', 'notice', {
                    key: `${table}_${host}`,
                    status: error ? 'error' : 'success',
                    message: error || `${app.fire('i18n', 'removed_roster', title)} -- ${app.fire('i18n', 'refresh_to_active')}`,
                  });
                  // app.fire('status');
                },
              });
            } else {
              app.fire('db', {
                request: {
                  table,
                  name:host,
                  execute:'add',
                  value: utils.filter(data, item => item.url !== url),
                },
                callback: function(error){
                  callback && callback(error);
                  app.fire('send', 'notice', {
                    key: `${table}_${host}`,
                    status: error ? 'error' : 'success',
                    message: error || `${app.fire('i18n', 'removed_roster', title)} -- ${app.fire('i18n', 'refresh_to_active')}`,
                  });
                  // app.fire('status');
                },
              });
            }
          } else {
            data.push({url, title, create: +(new Date)});
            app.fire('db', {
              request: {
                table,
                name:host,
                value: data,
                execute:'add',
              },
              callback: function(error){
                callback && callback(error);
                app.fire('send', 'notice', {
                  key: `${table}_${host}`,
                  status: error ? 'error' : 'success',
                  message: error || `${app.fire('i18n', 'added_roster', title)} -- ${app.fire('i18n', 'refresh_to_active')}`,
                });
              },
            });
          }
        }
      }
    });
  });
  app.on('open-option-page', function({callback} = {}){
    app.runtime.openOptionsPage();
    callback && callback();
  });
  app.on('contextmenus-click', function(info, tab){
    switch(info.menuItemId){
      case 'ctx-whitelist':
        app.fire('roster', {
          request: {
            table: 'whitelist',
            url: tab.url,
            title: tab.title,
          },
          callback: function(){
            app.fire('send', 'roster-whitelist');
          }
        });
        break;
      case 'ctx-blacklist':
        app.fire('roster', {
          request: {
            table: 'blacklist',
            url: tab.url,
            title: tab.title,
          },
          callback: function(){
            app.fire('send', 'roster-blacklist');
          }
        });
        break;
      case 'ctx-focus':
        app.fire('send', 'focusmode', {tab});
        break;
      case 'ctx-option':
        app.fire('open-option-page');
        break;
    }
  });
  // 右键菜单
  app.on('contextmenus', function({request: { id, title, enabled, action }, callback}){
    switch(action){
      case 'create':
        app.contextMenus.create({
          id,
          title,
          onclick: (info, tab) => {
            const url = info.pageUrl;
            if(utils.isString(url) && url.startsWith('chrome')){
              return;
            }
            app.fire('contextmenus-click', info, tab);
          },
        }, callback);
        break;
      case 'update':
        app.contextMenus.update(id, {enabled}, callback);
        break;
      case 'remove':
        app.contextMenus.remove(id, callback);
        break;
      case 'removeall':
        app.contextMenus.removeAll(callback);
        break;
      case 'init':
        app.fire('db', {
          request: {
            execute: 'all',
            table: 'contextmenu',
          },
          callback: function(error, data = []){
            if(error){
              callback(error);
            } else {
              const contextmenus = [];
              utils.each(data, function(item, key){
                if(!item.checked){
                  return;
                }
                contextmenus.push(Object.assign({id:key}, item));
              });
              if(contextmenus.length <= 0){
                return;
              }
              utils.each(contextmenus.sort(function(prev,next){
                return prev.create - next.create;
              }), function(item){
                item.checked && app.contextMenus.create({
                  id: item.id,
                  title: item.label,
                  onclick: (info, tab) => {
                    const url = info.pageUrl;
                    if(utils.isString(url) && url.startsWith('chrome')){
                      return;
                    }
                    app.fire('contextmenus-click', info, tab);
                  },
                });
              });
              callback && callback();
            }
          },
        });
        break;
    }
  });
  app.browserAction.onClicked.addListener(tab => {
    app.fire('send', 'action-browser', {tab});
  });
  // 启用右键菜单配置
  app.fire('db', {
    request: {
      execute: 'get',
      table: 'wrench',
      name: 'contextmenu-enabled',
    },
    callback: function(error, data){
      if(error){
        app.fire('error', error);
      } else {
        utils.isBoolean(data) && data && app.fire('contextmenus', {
          request: {
            action: 'init'
          },
          callback: function(error){
            error && app.fire('error', error);
          },
        });
      }
    },
  });
  // 开发辅助工具
  app.cache('debug') && app.load('debug');
});
