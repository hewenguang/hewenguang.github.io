import controller from './server/index';
import { initialValues, toolbarValues, MODULE_TO_UPDATE } from './server/utils';

App.register('app', ['utils', 'database', 'wrench', 'user'], function(){
  const app = this;

  function ctx(){
    app.fire('db', {
      request: {
        execute: 'get',
        table: 'wrench',
        name: 'contextmenu-enabled',
      },
      callback: function(error, data){
        if(error || !data){
          error && app.fire('error', error);
          return;
        }
        app.fire('ctx', {
          request: {
            action:'init'
          },
          callback: function(error){
            error && app.fire('error', error);
          },
        });
      },
    });
  }

  // 安装时写入初始配置
  app.on('install', function(){
    app.fire('import', {
      request: {
        data:initialValues(app),
      },
      callback: function(){
        ctx();
        if(app.cache('debug')){
          return;
        }
        app.runtime.setUninstallURL(app.to('uninstall'));
        app.tabs.create({url:app.to('usage')});
      },
    });
  });

  // 更新时写入数据
  app.on('update', function(){
    // 更新工具栏到布局配置
    app.fire('db', {
      request: {
        execute:'get',
        name: 'toolbar',
        table: 'setting',
      },
      callback: function(error, toolbar){
        if(error || !toolbar){
          return;
        }
        app.fire('db', {
          request: {
            execute:'get',
            name: 'layout',
            table: 'setting',
          },
          callback: function(error, data){
            if(error){
              return;
            }
            app.fire('db', {
              request: {
                execute:'add',
                name: 'layout',
                table: 'setting',
                value: Object.assign({}, toolbar, data),
              },
            });
          },
        });
      },
    });
    // 判断是否写入过
    app.fire('db', {
      request: {
        execute:'get',
        name: 'toolbar',
        table: 'wrench',
      },
      callback: function(error, data){
        if(app.cache('debug')){
          return;
        }
        app.runtime.setUninstallURL(app.to('uninstall'));
        if(error){
          app.fire('error', error);
          app.tabs.create({url:app.to('node/59')});
        } else {
          const toolbars = [];
          utils.each(data, function(item){
            if(item.field && MODULE_TO_UPDATE.includes(item.field)){
              toolbars.push(Object.assign(item, {field: `srt-${item.field}`}));
            } else {
              toolbars.push(item);
            }
          });
          app.fire('db', {
            request: {
              execute:'add',
              table: 'wrench',
              name: 'toolbar',
              value: toolbars.length > 0 ? toolbars : toolbarValues(app),
            },
            callback: function(){
              app.tabs.create({url:app.to('node/59')});
            },
          });
        }
      }
    });
  });

  // 看门狗
  app.on('watchdog', function({callback}){
    callback && callback();
    app.fire('cron', function(){
      // 检查用户权限
      const user = app.cache('user');
      if(!user || !user.member){
        return;
      }
      if(!user.expire){
        return;
      }
      const now = +new Date;
      const expire = +new Date(user.expire);
      if(expire - now > 0){
        return;
      }
      app.fire('user_clean', function(){
        app.fire('retrieve');
      });
    });
  });

  // 控制器
  controller(app);

  // 初始化右键菜单
  ctx();

  // 加载调试工具
  app.cache('debug') && app.load('debug');
});
