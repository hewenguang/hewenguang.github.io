export default function(app){
  app.tabs.onCreated.addListener(function(tab){
    app.fire('tab-created', tab);
  });
  app.tabs.onUpdated.addListener(function(tabId, changeInfo, tab){
    app.fire('tab-updated', tabId, changeInfo, tab);
  });
  app.browserAction.onClicked.addListener(tab => {
    app.fire('send', 'action-browser', {tab});
  });
}
