export const MODULE_TO_UPDATE = [
  'fullscreen',
  'print',
  'scrollpage',
  'speak',
  'setting',
  'wrench',
  'whitelist',
  'blacklist',
  'search',
  'edit',
  'remove',
  'copy',
  'word',
  'image',
  'text',
  'marked',
  'mail',
  'feedback',
];

export function initialValues(app){
  return {
    "wrench": {
      "skin": "light",
      "dark": "gray",
      "light": "green",
      "paper": true,
      "outline": true,
      "backtop": true,
      "nextpage": true,
      "shortcut-enabled": true,
      "contextmenu-enabled": true,
      "toolbar": [{
        "group": 0,
        "priority": 0,
        "name": "close",
        "field": "srt-exit",
        "label": app.fire('i18n', 'exit'),
      }, {
        "group": 0,
        "priority": 1,
        "name": "fullscreen",
        "field": "srt-fullscreen",
        "label": app.fire('i18n', 'fullscreen'),
      }, {
        "group": 0,
        "priority": 3,
        "name": "print",
        "field": "srt-print",
        "label": app.fire('i18n', 'print'),
      }, {
        "group": 0,
        "priority": 7,
        "name": "setting",
        "field": "srt-setting",
        "label": app.fire('i18n', 'adjust'),
      }, {
        "group": 0,
        "priority": 8,
        "name": "tool",
        "field": "srt-wrench",
        "label": app.fire('i18n', 'setting'),
      }, {
        "group": 0,
        "priority": 9,
        "name": "whitelist",
        "field": "srt-whitelist",
        "label": app.fire('i18n', 'togglewhitelist'),
      }, {
        "group": 0,
        "priority": 10,
        "name": "blacklist",
        "field": "srt-blacklist",
        "label": app.fire('i18n', 'toggleblacklist'),
      }, {
        "group": 1,
        "priority": 11,
        "name": "search",
        "field": "srt-search",
        "label": app.fire('i18n', 'find'),
      },{
        "group": 3,
        "priority": 21.8,
        "name": 'question',
        "field": 'srt-help',
        "label": app.fire('i18n', 'helpcenter'),
      },{
        "group": 3,
        "priority": 22,
        "name": "feedback",
        "field": "srt-feedback",
        "label": app.fire('i18n', 'feedback'),
      }]
    },
    "setting": {
      "dark": {
        "color": "#b0b0b0",
        "link": "#5ac8fa",
        "hover": "#3ea4d2",
        "visited": "#3ea4d2",
        "select": "#fffefe",
        "selectbg": "#43b0e2",
        "bg": "#4a4a4d",
        "track": "#4e4e50",
        "thumb": "#83838c",
        "radius": "4px"
      },
      "light": {
        "color": "#282d2b",
        "link": "#507964",
        "hover": "#3e6b54",
        "visited": "#3e6b54",
        "select": "#000",
        "selectbg": "#addab4",
        "bg": "#c7edcc",
        "track": "#8fbd95",
        "thumb": "#638c6d",
        "radius": "4px"
      },
      "skin": {
        "color": "#1b1b1b",
        "link": "#416ed2",
        "hover": "#305ab7",
        "visited": "#305ab7",
        "select": "#1b1b1b",
        "selectbg": "#bbd6fc",
        "bg": "#fff",
        "track": "#e2e2e2",
        "thumb": "#9e9e9e",
        "radius": "4px"
      }
    },
    "shortcut": {
      "srt-basic": {
        "value": "b s",
        "checked": true
      },
      "srt-scrollpage": {
        "value": "s p",
        "checked": false
      },
      "srt-togglescrollpage": {
        "value": "s s",
        "checked": false
      },
      "srt-speak": {
        "value": "t s",
        "checked": false
      },
      "srt-togglespeak": {
        "value": "g s",
        "checked": false
      },
      "srt-blacklist": {
        "value": "b l",
        "checked": true
      },
      "srt-blacklist-site": {
        "value": "b s",
        "checked": true
      },
      "srt-bottom": {
        "value": "G",
        "checked": true
      },
      "srt-config": {
        "value": "c f",
        "checked": true
      },
      "srt-contextmenu": {
        "value": "c m",
        "checked": true
      },
      "srt-copy": {
        "value": "c p",
        "checked": false
      },
      "srt-edit": {
        "value": "e t",
        "checked": true
      },
      "srt-enter-or-exit": {
        "value": "a a",
        "checked": true
      },
      "srt-exit": {
        "value": "escape",
        "checked": true
      },
      "srt-exitclose": {
        "value": "x x",
        "checked": true
      },
      "srt-exitcode": {
        "value": "x c",
        "checked": true
      },
      "srt-exitimg": {
        "value": "x p",
        "checked": true
      },
      "srt-feedback": {
        "value": "f d",
        "checked": true
      },
      "srt-focus": {
        "value": "a s",
        "checked": true
      },
      "srt-fullscreen": {
        "value": "f u",
        "checked": true
      },
      "srt-help": {
        "value": "?",
        "checked": true
      },
      "srt-image": {
        "value": "s n",
        "checked": false
      },
      "srt-imagehide": {
        "value": "h p",
        "checked": true
      },
      "srt-layout": {
        "value": "l y",
        "checked": true
      },
      "srt-links": {
        "value": "l k",
        "checked": true
      },
      "srt-lnk": {
        "value": "l k",
        "checked": true
      },
      "srt-mail": {
        "value": "m a",
        "checked": false
      },
      "srt-manage-blacklist": {
        "value": "m b",
        "checked": true
      },
      "srt-manage-whitelist": {
        "value": "m w",
        "checked": true
      },
      "srt-marked": {
        "value": "m d",
        "checked": false
      },
      "srt-option": {
        "value": "o p",
        "checked": true
      },
      "srt-paper": {
        "value": "p r",
        "checked": true
      },
      "srt-print": {
        "value": "p p",
        "checked": true
      },
      "srt-remove": {
        "value": "c l",
        "checked": true
      },
      "srt-search": {
        "value": "/ /",
        "checked": true
      },
      "srt-setting": {
        "value": "s t",
        "checked": true
      },
      "srt-shortcut": {
        "value": "k b",
        "checked": true
      },
      "srt-skin": {
        "value": "t m",
        "checked": true
      },
      "srt-style": {
        "value": "s l",
        "checked": true
      },
      "srt-stylesheet": {
        "value": "c s",
        "checked": true
      },
      "srt-text": {
        "value": "t t",
        "checked": false
      },
      "srt-toolbar": {
        "value": "t b",
        "checked": true
      },
      "srt-top": {
        "value": "g g",
        "checked": true
      },
      "srt-whitelist": {
        "value": "w l",
        "checked": true
      },
      "srt-whitelist-site": {
        "value": "w s",
        "checked": true
      },
      "srt-word": {
        "value": "w d",
        "checked": false
      },
    },
    "contextmenu": {
      "ctx-blacklist": {
        "label": app.fire('i18n', 'toggleblacklist'),
        "checked": true,
        "create": 1627958971076
      },
      "ctx-focus": {
        "label": app.fire('i18n', 'focus'),
        "checked": true,
        "create": 1627958971696
      },
      "ctx-option": {
        "label": app.fire('i18n', 'setting'),
        "checked": true,
        "create": 1627958972277
      },
      "ctx-whitelist": {
        "label": app.fire('i18n', 'togglewhitelist'),
        "checked": true,
        "create": 1627958970488
      }
    }
  };
}

export function toolbarValues(app){
  return [{
    "group": 0,
    "priority": 0,
    "name": "close",
    "field": "srt-exit",
    "label": app.fire('i18n', 'exit'),
  }, {
    "group": 0,
    "priority": 1,
    "name": "fullscreen",
    "field": "srt-fullscreen",
    "label": app.fire('i18n', 'fullscreen'),
  }, {
    "group": 0,
    "priority": 3,
    "name": "print",
    "field": "srt-print",
    "label": app.fire('i18n', 'print'),
  }, {
    "group": 0,
    "priority": 7,
    "name": "setting",
    "field": "srt-setting",
    "label": app.fire('i18n', 'adjust'),
  }, {
    "group": 0,
    "priority": 8,
    "name": "tool",
    "field": "srt-wrench",
    "label": app.fire('i18n', 'setting'),
  }, {
    "group": 0,
    "priority": 9,
    "name": "whitelist",
    "field": "srt-whitelist",
    "label": app.fire('i18n', 'togglewhitelist'),
  }, {
    "group": 0,
    "priority": 10,
    "name": "blacklist",
    "field": "srt-blacklist",
    "label": app.fire('i18n', 'toggleblacklist'),
  }, {
    "group": 1,
    "priority": 11,
    "name": "search",
    "field": "srt-search",
    "label": app.fire('i18n', 'find'),
  },{
    "group": 3,
    "priority": 21.8,
    "name": 'question',
    "field": 'srt-help',
    "label": app.fire('i18n', 'helpcenter'),
  },{
    "group": 3,
    "priority": 22,
    "name": "feedback",
    "field": "srt-feedback",
    "label": app.fire('i18n', 'feedback'),
  }];
}
