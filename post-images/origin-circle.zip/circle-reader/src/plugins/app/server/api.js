export default function(app){
  // 修改状态
  app.on('status', function({request: { action }, sender, callback} = {}){
    callback && callback();
    const tabId = sender.tab.id;
    switch(action){
      case 'wait':
        app.browserAction.enable(tabId);
        app.browserAction.setIcon({
          tabId,
          path: {
            16: 'icons/16-wait.png',
            32: 'icons/32-wait.png',
          },
        });
        break;
      case 'done':
        app.browserAction.setIcon({
          tabId,
          path: {
            16: 'icons/16-done.png',
            32: 'icons/32-done.png',
          },
        });
        break;
      case 'disable':
        app.browserAction.disable(tabId);
        app.browserAction.setIcon({
          tabId,
          path: {
            16: 'icons/16-disable.png',
            32: 'icons/32-disable.png',
          },
        });
        break;
      default:
        app.browserAction.disable(tabId);
        app.browserAction.setIcon({
          tabId,
          path: {
            16: 'icons/16-default.png',
            32: 'icons/32-default.png',
          },
        });
        break;
    }
  });
  // tab 操作相关
  app.on('tab', function({request, sender, callback}){
    const tabId = sender.tab.id;
    const property = request.value || {};
    switch(request.action){
      case 'create':
        app.tabs.create(property, function(tab){
          callback && callback(null, tab);
        });
        break;
      case 'update':
        app.tabs.update(tabId, property, function(tab){
          callback && callback(null, tab);
        });
        break;
      case 'remove':
        app.tabs.remove(tabId, callback);
        break;
      case 'captureVisibleTab':
        app.tabs.captureVisibleTab(property, function(dataUrl){
          callback && callback(null, dataUrl);
        });
        break;
      case 'query':
        app.tabs.query(property, function(tabs){
          callback && callback(null, tabs);
        });
        break;
    }
  });
  // windows 操作
  app.on('windows', function({request, callback}){
    switch(request.action){
      case 'current':
        app.windows.getCurrent(function(instance){
          callback && callback(null, instance);
        });
        break;
      case 'create':
        app.windows.create({
          url: request.url,
        }, function(instance){
          callback && callback(null, instance);
        });
        break;
      case 'get':
        app.windows.get(app.windows.WINDOW_ID_CURRENT, function(instance){
          callback && callback(null, instance);
        });
        break;
      case 'update':
        // "normal", "minimized", "maximized", "fullscreen", or "locked-fullscreen"
        app.windows.update(app.windows.WINDOW_ID_CURRENT, {
          state: request.state,
        }, function(instance){
          callback && callback(null, instance);
        });
        break;
    }
  });
   // 右键菜单
  app.on('ctx', function({request: { id, title, enabled, action }, callback}){
    switch(action){
      case 'create':
        app.contextMenus.create({
          id,
          title,
          onclick: (info, tab) => {
            const url = info.pageUrl;
            if(utils.isString(url) && url.startsWith('chrome')){
              return;
            }
            app.fire('ctx-click', info, tab);
          },
        }, function(){
          console.log(app.runtime.lastError);
          callback && callback();
        });
        break;
      case 'update':
        app.contextMenus.update(id, {title, enabled}, callback);
        break;
      case 'remove':
        app.contextMenus.remove(id, callback);
        break;
      case 'removeall':
        app.contextMenus.removeAll(callback);
        break;
      case 'init':
        app.fire('db', {
          request: {
            execute: 'all',
            table: 'contextmenu',
          },
          callback: function(error, data = []){
            if(error){
              callback && callback(error);
              return;
            }
            callback && callback();
            const ctxs = [];
            utils.each(data, function(item, key){
              if(!item.checked){
                return;
              }
              ctxs.push(Object.assign({id:key}, item));
            });
            if(ctxs.length <= 0){
              return;
            }
            app.contextMenus.removeAll(function(){
              utils.each(ctxs.sort(function(prev,next){
                return prev.create - next.create;
              }), function(item){
                item.checked && app.contextMenus.create({
                  id: item.id,
                  title: item.label,
                  onclick: (info, tab) => {
                    const url = info.pageUrl;
                    if(utils.isString(url) && url.startsWith('chrome')){
                      return;
                    }
                    app.fire('ctx-click', info, tab);
                  },
                });
              });
            });
          },
        });
        break;
    }
  });
}
