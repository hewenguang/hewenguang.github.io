export default function(app){
  app.on('pjax-start', function({request, callback}){
    callback && callback();
    const hostname = request.hostname;
    hostname && app.cache('pjax-hostname', hostname);
  });
  app.on('tab-created', function(){
    app.cache('pjax-hostname', null);
  });
  app.on('tab-updated', function(tabId, changeInfo, tab){
    const url = changeInfo.url;
    url && app.cache('pjax-changeurl', url);
    if(changeInfo.status !== 'complete' || !app.cache('pjax-changeurl') || !app.cache('pjax-hostname')){
      return;
    }
    const location = utils.location(app.cache('pjax-changeurl'));
    if(location.hostname !== app.cache('pjax-hostname')){
      return;
    }
    app.fire('send', 'pjax-change', {tab, url:app.cache('pjax-changeurl')});
    app.cache('pjax-changeurl', null);
  });
}
