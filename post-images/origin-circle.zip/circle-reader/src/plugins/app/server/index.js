import api from './api';
import pjax from './pjax';
import event from './event';
import analytics from './analytics';

export default function(app){

  // 黑/白名单
  app.on('roster', function({request, callback} = {}){
    const id = request.id;
    const table = request.table;
    const title = request.title;
    const url = request.url.replace(/#.*$/, '');
    const location = utils.location(url);
    const host = location.host;
    app.fire('db', {
      request: {
        table,
        name:host,
        execute:'get',
      },
      callback: function(error, data = []){
        if(error){
          callback && callback(error);
          return;
        }
        if(id){
          app.fire('db', {
            callback,
            request: {
              table,
              name:host,
              execute:'add',
              value:data.map(function(item){
                if(item.url === id){
                  return {url, title, create: +(new Date)};
                }
                return item;
              }),
            },
          });
        } else {
          let exist;
          utils.each(data, function(item){
            if(item.url === url){
              exist = true;
              return true;
            }
          });
          // 删除操作
          if(exist){
            if(data.length === 1){
              app.fire('db', {
                callback,
                request: {
                  table,
                  name:host,
                  execute:'remove',
                },
              });
            } else {
              app.fire('db', {
                callback,
                request: {
                  table,
                  name:host,
                  execute:'add',
                  value: utils.filter(data, item => item.url !== url),
                },
              });
            }
          } else {
            // 新增操作
            data.push({url, title, create: +(new Date)});
            app.fire('db', {
              callback,
              request: {
                table,
                name:host,
                value: data,
                execute:'add',
              },
            });
          }
        }
      }
    });
  });

  // 选项页面
  app.on('open-option-page', function({callback} = {}){
    callback && callback();
    app.runtime.openOptionsPage();
  });

  // 右键菜单
  app.on('ctx-click', function(info, tab){
    const table = info.menuItemId.split('-').pop();
    switch(info.menuItemId){
      case 'ctx-whitelist':
      case 'ctx-blacklist':
        app.fire('roster', {
          request: {
            table,
            url: tab.url,
            title: tab.title,
          },
          callback: function(error){
            if(error){
              app.fire('error', error);
            } else {
              // 通知前端
              app.fire('send', `roster-${table}`, {tab});
            }
          }
        });
        break;
      case 'ctx-focus':
        app.fire('send', 'srt-focus', {tab});
        break;
      case 'ctx-option':
        app.fire('open-option-page');
        break;
    }
  });

  // 默认 2 小时更新一次
  app.on('cron', function(callback, duration = 2){
    const now = +(new Date);
    const name = `corn_${duration}`;
    const timer = duration * 60 * 60 * 1000;
    app.fire('storage', {
      request: {
        name,
        execute: 'get',
      },
      callback: function(error, data = now){
        if(error){
          app.fire('error', error);
        } else {
          if(data > now){
            return;
          }
          app.fire('storage', {
            request: {
              name,
              execute: 'add',
              value: now + timer,
            },
            callback: function(error){
              if(error){
                app.fire('error', error);
              } else {
                callback && callback();
              }
            },
          });
        }
      },
    });
  });

  // 接口操作
  api(app);
  // pjax 支持
  pjax(app);
  // 事件监听
  event(app);
  // 数据统计
  analytics(app);
}
