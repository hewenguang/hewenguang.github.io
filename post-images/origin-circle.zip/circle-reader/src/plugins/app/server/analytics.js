export default function(app){
  if (navigator.userAgent.indexOf('Firefox') >= 0){
    window.ga = function(action, type, value, event){
      try {
        let request = new XMLHttpRequest();
        let message = `v=1&tid=UA-156433061-4&cid=891391123.1617281018&aip=1&ds=add-on&t=event&ec=${value}&ea=${event}`;
        request.open('POST', 'https://www.google-analytics.com/collect', true);
        request.send(message);
      } catch (e) {
        // console.log('Error sending report to Google Analytics.\n' + e);
      }
    }
  } else {
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-156433061-4', 'auto');
    ga('set', 'checkProtocolTask', function(){});
    ga('send', 'pageview', '/circle.html');
  }
  
  app.on('analytics', function({request:{event, type = 'click'}, callback}){
    if(app.cache('debug')){
      console.log('analytics', event, type);
    } else {
      utils.isString(event) && ga('send', 'event', event, type);
    }
    callback && callback();
  });
}
