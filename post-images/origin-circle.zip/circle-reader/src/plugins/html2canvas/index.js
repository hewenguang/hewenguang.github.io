App.register('html2canvas', ['utils', 'dom'], function(utils, dom){
  let width = 0; // dom 宽度
  let height = 0; // dom 高度
  let viewport = 0; // 视口高度
  let transform; // 原 transform 样式
  let translateY = 0; // 滚动偏移值
  let pageYOffset = 0; // 记录当前滚动值
  const app = this;
  const root = document.documentElement;
  const canvas = dom.create('canvas');
  const context = canvas.getContext('2d');
  app.on('html2canvas-block', function(callback){
    app.fire('send', 'tab', {action:'captureVisibleTab', value:{
      quality: 100,
      format: 'png',
    }}, function({error, data}){
      if(error){
        app.fire('error', error);
        return;
      }
      const image = new Image;
      image.addEventListener('load', function(){
        context.drawImage(this, 0, translateY, width, viewport);
        translateY += viewport;
        if(translateY <= height){
          // 开启硬件加速（360 问题解决）
          root.style.setProperty('transform', `translate3d(0,-${translateY}px,0)`);
          utils.wait(function(){
            app.fire('html2canvas-block', callback);
          }, 750);
        } else {
          // 恢复样式
          if(transform){
            root.style.setProperty('transform', transform);
          } else {
            root.style.removeProperty('transform');
          }
          // 操作完成恢复现场(顺序很重要)
          callback && callback(canvas);
          app.fire('pure-after');
          // 恢复滚动值
          window.scrollTo({
            left: 0,
            top: pageYOffset,
            behavior: 'instant',
          });
        }
      });
      image.src = data;
    });
  });
  app.on('html2canvas', function(callback){
    pageYOffset = window.pageYOffset;
    // 滚动到顶部开始捕捉
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'instant',
    });
    translateY = 0;
    // 隐藏页面噪音
    app.fire('pure-before');
    width = root.scrollWidth;
    height = root.scrollHeight;
    canvas.width = width;
    canvas.height = height;
    context.clearRect(0, 0, width, height);
    viewport = window.innerHeight;
    const transformStyle = root.style.transform;
    transformStyle && (transform = transformStyle);
    utils.wait(function(){
      app.fire('html2canvas-block', callback);
    }, 1000);
  });
});
