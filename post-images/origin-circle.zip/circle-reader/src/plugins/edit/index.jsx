import React from 'react';
import ReactDOM from 'react-dom';
import { ConfigProvider } from 'antd';
import Entry from './entry';
import 'antd/dist/antd.css';
import './index.less';

App.register('edit', ['shadow', 'dom', 'utils'], function(shadow, dom){
  const app = this;
  const root = dom.create('div', {className:'root'});
  shadow({
    style: [
      'plugins/antd/index.css',
      'plugins/edit/index.css',
    ],
    onReady: function(shadowRoot){
      shadowRoot.appendChild(root);
    }
  });
  app.on('render-start-done', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('render-destory-done', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-before', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-after', function(){
    dom.setStyle(root, 'display', 'block');
  });

  ReactDOM.render((
    <ConfigProvider
      componentSize="small"
      getPopupContainer={() => root}
    >
      <Entry app={app} />
    </ConfigProvider>
  ), root);
});
