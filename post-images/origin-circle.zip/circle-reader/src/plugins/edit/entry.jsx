import { Input } from 'antd';
import React, { useState, useEffect } from 'react';

export default function({app}){
  const root = app.fire('dom-container');
  const [ value, setValue ] = useState('');
  const [ style, setStyle ] = useState({});
  const [ target, setTarget ] = useState(null);
  const exit = () => {
    app.cache('edit', false);
    app.fire('toolbar-key', '');
    setTarget(null);
  };

  useEffect(() => {
    const hook = app.on('click', function(node){
      if(!app.cache('edit')){
        return;
      }
      if(!root.contains(node)){
        exit();
        return;
      }
      if(node.classList.contains('page')){
        return;
      }
      if(['IMG', 'BR'].includes(node.nodeName) || node.querySelectorAll('*').length > 0){
        app.fire('message', {
          duration: 1,
          type: 'error',
          key: 'edit_limit',
          message: app.fire('i18n', 'edit_limit'),
        });
        return;
      }
      const rect = node.getBoundingClientRect();
      setTarget(node);
      setValue(node.innerText);
      setStyle({
        width:rect.width,
        height:rect.height,
        top:rect.top + window.pageYOffset,
        left:rect.left + window.pageXOffset,
      });
    });
    return () => {
      app.remove(hook);
    };
  }, []);

  useEffect(() => {
    const hook = app.on('edit', function(){
      if(app.cache('edit')){
        exit();
      } else {
        app.cache('edit', true);
        app.fire('toolbar-key', 'srt-edit');
        app.fire('send', 'storage', {
          execute:'get',
          name: 'edit-alert',
        }, function({error, data}){
          if(error || data){
            error && app.fire('error', error);
            return;
          }
          app.fire('message', {
            key: 'edit',
            btnText: app.fire('i18n', 'got_it'),
            message: app.fire('i18n', 'edit_alert'),
          }, function(){
            app.fire('send', 'storage', {
              execute: 'add',
              name: 'edit-alert',
              value: true,
            }, function({error}){
              error && app.fire('error', error);
            });
          });
        });
      }
      app.fire('send', 'analytics', {event:'edit'});
    });
    app.fire('edit');
    return () => {
      app.remove(hook);
    };
  }, []);

  useEffect(() => {
    const hook = app.on('resize', exit);
    const resizehook = app.on('resize-conatiner', exit);
    return () => {
      app.remove(hook);
      app.remove(resizehook);
    };
  }, []);

  if(!target){
    return null;
  }

  return (
    <Input.TextArea
      style={style}
      value={value}
      className="textarea"
      onChange={event => setValue(event.target.value)}
      onBlur={event => {
        const text = event.target.value;
        target.innerHTML = text;
        setTarget(null);
      }}
      onPressEnter={event => {
        const text = event.target.value;
        target.innerHTML = text;
        setTarget(null);
      }}
    />
  );
}
