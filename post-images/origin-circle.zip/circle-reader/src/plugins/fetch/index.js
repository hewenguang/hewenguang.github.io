App.register('fetch', 'utils', function(utils){
  const app = this;

  return function(url, option, type = 'json'){
    return fetch(url, option).then(function(response){
      const promise = response[type]();
      if (response.ok){
        return promise;
      }
      app.fire(`fetch_${response.status}`);
      return promise.then(function(result){
        if(result.form_errors){
          const errors = [];
          utils.each(result.form_errors, function(error){
            errors.push(error);
          });
          throw new Error(errors.toString());
        } else {
          throw new Error(result && result.toString ? result.toString() : result);
        }        
      });
    });
  };
});
