import Tooltip from './tooltip';
import Release from './release';
import useApp from 'app/context/useApp';
import React, { useState, useEffect } from 'react';
import {
  ToolOutlined,
  CloseOutlined,
  PrinterOutlined,
  SettingOutlined,
  FullscreenOutlined,
  FullscreenExitOutlined,
} from '@ant-design/icons';

export default function(){
  const app = useApp();
  const [ style, setStyle ] = useState({display:'none'});
  const locate = () => {
    const page = app.fire('dom-container');
    const rect = page.getBoundingClientRect();
    const clientWidth = dom.clientWidth(document);
    if(clientWidth - rect.right > 50){
      const topValue = rect.top;
      setStyle({
        top: topValue <= 0 ? 81 : topValue,
        display:'block',
        right: clientWidth - rect.right - 44,
      });
    } else {
      setStyle({display:'block'});
    }
  };

  useEffect(() => {
    ['fullscreen', 'print', 'setting', 'wrench'].forEach(function(item){
      app.on(item, function(){
        app.load(item);
      }, true);
    });
    app.on('resize', locate);
    const resize = new ResizeObserver(locate);
    const root = app.fire('dom-root');
    root && resize.observe(root);
    const page = app.fire('dom-container');
    page && resize.observe(page);
  }, []);

  return (
    <div
      style={style}
      className="toolbar"
    >
      <Tooltip title={app.fire('i18n', 'exit')}>
        <CloseOutlined onClick={() => app.fire('render-destory')} />
      </Tooltip>
      <Tooltip title={app.fire('i18n', 'fullscreen')}>
        <FullscreenOutlined onClick={() => app.fire('fullscreen')} />
      </Tooltip>
      <Tooltip title={app.fire('i18n', 'fullscreen_exit')}>
        <FullscreenExitOutlined onClick={() => app.fire('fullscreen-exit')} />
      </Tooltip>
      <Tooltip title={app.fire('i18n', 'print')}>
        <PrinterOutlined onClick={() => app.fire('print')} />
      </Tooltip>
      <Tooltip title={app.fire('i18n', 'adjust')}>
        <SettingOutlined onClick={() => app.fire('setting')} />
      </Tooltip>
      <Tooltip title={app.fire('i18n', 'setting')}>
        <ToolOutlined onClick={() => app.fire('wrench')} />
      </Tooltip>
      <Release />
      {/* <SearchOutlined />
      <CopyOutlined />
      <CommentOutlined />
      <ShareAltOutlined />
      <StarOutlined />
      <SaveOutlined />
      <MailOutlined />
      <FileWordOutlined />
      <EditOutlined /> */}
    </div>
  );
}
