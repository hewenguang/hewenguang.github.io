import cx from 'classnames';
import Icon from 'app/components/icon';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import useOption from 'app/context/useOption';
import React, { useState, useEffect } from 'react';
import { authorize } from 'app/components/authorize';
import { builtIn, groupBy } from './utils';

export default function(){
  const app = useApp();
  const user = useUser();
  const [ activeKey, setActiveKey ] = useState('');
  const [ loadingKey, setLoadingKey ] = useState('');
  const [ toolbars, setToolbars ] = useState(builtIn(app));
  const [ data ] = useOption({
    defaultValue:[],
    field: 'toolbar',
  });

  useEffect(() => {
    const keyHook = app.on('toolbar-key', function(key){
      setActiveKey(key);
    });
    const loadingHook = app.on('toolbar-loading', function(key){
      setLoadingKey(key);
    });
    return () => {
      app.remove(keyHook);
      app.remove(loadingHook);
    };
  }, []);

  useEffect(() => {
    const hook = app.on('toolbar-item', function(toolbar){
      if(utils.isString(toolbar)){
        setToolbars(toolbars.filter(item => item.field !== toolbar));
      } else {
        const items = [].concat(toolbars);
        items.push(toolbar);
        setToolbars(items);
      }
    });
    return () => {
      app.remove(hook);
    };
  }, [ toolbars ]);

  useEffect(() => {
    if(!utils.isArray(data)){
      return;
    }
    setToolbars(builtIn(app).concat(data));
  }, [ data ]);

  const groups = groupBy(toolbars.sort(function(prev,next){
    return prev.priority - next.priority;
  }), function(item){
    return item.group;
  });

  return Object.keys(groups).map(key => (
    <div
      key={key}
      className="items"
    >
      {groups[key].map(item => (
        <Icon
          tabIndex={0}
          key={item.label}
          placement="right"
          tooltip={item.label}
          mouseEnterDelay={0.7}
          name={loadingKey === item.field ? 'loading' : item.name}
          className={cx(item.field, {
            active: activeKey === item.field,
            'anticon-spin': loadingKey === item.field,
          })}
          onClick={() => {
            if(user.member || authorize(item.field)){
              app.fire(item.field);
              app.fire('send', 'analytics', {event:`toolbar-${item.field}`});
            } else {
              app.fire('upgrade');
              app.fire('send', 'analytics', {event:`toolbar-upgrade-${item.field}`});
            }
          }}
        >
          {item.children}
        </Icon>
      ))}
    </div>
  ));
}
