import React from 'react';
import Tooltip from './tooltip';
import useApp from 'app/context/useApp';
import useStorage from 'app/context/useStorage';
import { BulbOutlined, QuestionCircleOutlined } from '@ant-design/icons';

export default function(){
  const app = useApp();
  const [ option, optionChange ] = useStorage({
    field: 'update',
    defaultValue: '',
  });

  if(option){
    return (
      <Tooltip title={app.fire('i18n', 'new_release')}>
        <a
          href={option}
          target="_blank"
          onClick={() => optionChange('remove')}
        >
          <BulbOutlined className="light" />
        </a>
      </Tooltip>
    );
  }

  return (
    <Tooltip title={app.fire('i18n', 'feedback')}>
      <a
        target="_blank"
        href="https://support.qq.com/products/317910"
      >
        <QuestionCircleOutlined />
      </a>
    </Tooltip>
  );
}
