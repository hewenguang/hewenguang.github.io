import React from 'react';
import { Tooltip } from 'antd';

export default function(props){
  const { title, children } = props;

  return (
    <Tooltip
      title={title}
      placement="right"
      overlayClassName="tooltip"
    >
      {children}
    </Tooltip>
  );
}
