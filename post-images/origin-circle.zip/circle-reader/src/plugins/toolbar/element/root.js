export default function(app){
  const element = dom.create('div', {
    className: 'root sticky',
  });
  app.on('dom-toolbar', element);
  // 纸张效果
  app.on('paper', function(paper){
    if(paper){
      element.classList.add('sticky');
    } else {
      element.classList.remove('sticky');
    }
    app.fire('toolbar-sticky');
  });
  return element;
}
