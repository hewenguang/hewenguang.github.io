import React from 'react';
import ReactDOM from 'react-dom';
import { ConfigProvider } from 'antd';
import { AppContext } from 'app/context';
import zhCN from 'antd/lib/locale/zh_CN';
import 'antd/dist/antd.css';
import './index.less';
import Entry from './entry';

App.register('toolbar', ['shadow', 'dom', 'utils'], function(shadow, dom){
  const app = this;
  const shadowRoot = shadow({
    root: document.documentElement,
    style: [
      'plugins/antd/index.css',
      'plugins/toolbar/index.css',
    ],
  });
  const root = dom.create('div', {className:'root'});
  app.on('dom-toolbar', root);
  shadowRoot.appendChild(root);
  app.on('theme', function(value, key){
    utils.each(utils.isPlainObject(value) ? value : {
      [key]: value
    }, (style, styleKey) => {
      if(styleKey !== 'color'){
        return;
      }
      root.style.setProperty(`--${styleKey}`, style);
    });
  });
  app.on('fullscreenchange', function(fullscreen){
    if(fullscreen){
      root.classList.add('fullscreen');
    } else {
      root.classList.remove('fullscreen');
    }
  });
  app.on('render-start-done', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('render-destory-done', function(){
    dom.setStyle(root, 'display', 'none');
  });

  ReactDOM.render((
    <AppContext.Provider value={app}>
      <ConfigProvider
        locale={zhCN}
        componentSize="small"
        getPopupContainer={() => root}
      >
        <Entry />
      </ConfigProvider>
    </AppContext.Provider>
  ), root);
});
