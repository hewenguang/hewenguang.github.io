import React from 'react';
import ReactDOM from 'react-dom';
import { ConfigProvider } from 'antd';
import { AppContext } from 'app/context';
import controller from './controller';
import generateRoot from './element/root';
import 'antd/dist/antd.css';
import './index.less';
import Root from './root';

App.register('toolbar', ['shadow', 'dom', 'utils'], function(shadow){
  const app = this;
  const root = generateRoot(app);
  shadow({
    style: [
      'plugins/antd/index.css',
      'plugins/toolbar/index.css',
    ],
    onReady: function(shadowRoot){
      shadowRoot.appendChild(root);
    }
  });

  controller(app, root);

  ReactDOM.render((
    <AppContext.Provider value={app}>
      <ConfigProvider
        componentSize="small"
        getPopupContainer={() => root}
      >
        <Root app={app} />
      </ConfigProvider>
    </AppContext.Provider>
  ), root);
});
