import cx from 'classnames';
import React, { useRef, useState, useEffect } from 'react';
import Entry from './entry';

export default function({ app }){
  const root = useRef(null);
  const [ visible, setVisible ] = useState(true);

  useEffect(() => {
    const hook = app.on('toolbar-sticky', function(){
      if(!root || !root.current){
        return;
      }
      let offset = 26;
      const target = root.current;
      const toolbar = app.fire('dom-toolbar');
      const clientHeight = dom.clientHeight();
      if(toolbar.classList.contains('sticky')){
        const page = app.fire('dom-container');
        const rect = page.getBoundingClientRect();
        const clientWidth = dom.clientWidth();
        if(clientWidth - rect.right > 50){
          const top = rect.top;
          const topValue = top <= 0 ? 81 : top;
          offset = topValue + 20;
          target.style.setProperty('top', `${topValue}px`);
          target.style.setProperty('right', `${clientWidth - rect.right - 44}px`);
        } else {
          offset += 60;
          target.style.removeProperty('top');
          target.style.removeProperty('right');
        }
      } else {
        offset += 80;
        target.style.removeProperty('top');
        target.style.removeProperty('right');
      }
      target.style.setProperty('max-height', `${clientHeight - offset}px`);
    });
    return () => {
      app.remove(hook);
    };
  }, [ root ]);

  useEffect(() => {
    const hook = app.on('resize', function(){
      app.fire('toolbar-sticky');
    });
    const rootHook = app.on('resize-root', function(){
      app.fire('toolbar-sticky');
    });
    const containerHook = app.on('resize-conatiner', function(){
      app.fire('toolbar-sticky');
    });
    // 延迟更新位置
    utils.lazy(function(){
      app.fire('toolbar-sticky');
    });
    return () => {
      app.remove(hook);
      app.remove(rootHook);
      app.remove(containerHook);
    };
  }, []);

  useEffect(() => {
    const hook = app.on('toolbar-hide', function(hide){
      setVisible(!hide);
    });
    return () => {
      app.remove(hook);
    };
  }, []);

  useEffect(() => {
    // 样式设置
    app.fire('send', 'db', {
      table: 'setting',
      name: 'layout',
      execute: 'get',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        if(!data){
          return;
        }
        !utils.isUndefined(data.itemspace) && app.fire('theme', data.itemspace, 'itemspace');
        !utils.isUndefined(data.groupspace) && app.fire('theme', data.groupspace, 'groupspace');
        if(utils.isUndefined(data.autohide)){
          return;
        }
        app.cache('autohide', data.autohide);
        app.fire('toolbar-hide', data.autohide);
      }
    });
  }, []);

  return (
    <div
      ref={root}
      className={cx('toolbar', {
        visible,
      })}
      onMouseEnter={() => {
        if(!app.cache('autohide')){
          return;
        }
        setVisible(true);
      }}
      onMouseLeave={() => {
        if(!app.cache('autohide')){
          return;
        }
        setVisible(false);
      }}
    >
      <Entry />
    </div>
  );
}
