export function groupBy(target, callback){
  let items = {};
  target.sort(function(prev,next){
    return prev.priority - next.priority;
  }).forEach(function(item){
    const groupKey = callback(item);
    const key = typeof groupKey !== 'undefined' ? groupKey : '_';
    !items[key] && (items[key] = []);
    items[key].push(item);
  });
  return items;
}

export function builtIn(app){
  return [{
    group: 3,
    priority: 23,
    name: 'appstore_add',
    field: 'srt-toolbar',
    label: app.fire('i18n', 'toolbar'),
  },{
    group: 0,
    priority: 2,
    field: 'fullscreen_exit',
    name: 'fullscreen_exit',
    label: app.fire('i18n', 'fullscreen_exit'),
  }];
}
