export default function(app, root){
  app.on('render-start-done', function(){
    dom.setStyle(root, 'display', 'block');
    app.fire('windows_state', function(state){
      app.fire('fullscreenchange', state === 'fullscreen');
    });
  });
  app.on('render-destory-done', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-before', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-after', function(){
    dom.setStyle(root, 'display', 'block');
  });

  app.on('theme', function(value, key){
    if(utils.isUndefined(value)){
      return;
    }
    utils.each(utils.isPlainObject(value) ? value : {
      [key]: value
    }, (style, styleKey) => {
      if(!['autohide', 'itemspace', 'groupspace', 'color'].includes(styleKey)){
        return;
      }
      if(styleKey === 'autohide'){
        if(utils.isUndefined(style)){
          return;
        }
        app.cache('autohide', style);
        app.fire('toolbar-hide', style);
      } else {
        root.style.setProperty(`--${styleKey}`, style);
      }
    });
  });

  app.on('fullscreenchange', function(visible){
    const fullscreen = root.classList.contains('fullscreen');
    if(visible){
      !fullscreen && root.classList.add('fullscreen');
    } else {
      fullscreen && root.classList.remove('fullscreen');
    }
  });
  // 初始就是全屏幕
  app.fire('windows_state', function(state){
    state === 'fullscreen' && app.fire('fullscreenchange', true);
  });
}
