import Icon from 'app/components/icon';
import useApp from 'app/context/useApp';
import { Space, Checkbox, List } from 'antd';
import useStorage from 'app/context/useStorage';
import React, { useState, useEffect } from 'react';
import Input from './components/input';

export default function(){
  const app = useApp();
  const [ index, setIndex ] = useState(0);
  const [ marks, setMarks ] = useState([]);
  const [ keyword, setKeyword ] = useState('');
  const [ option, setOption ] = useState([
    'separateWord',
    'diacritics',
    'accuracy',
  ]);
  const [ filter, setFilter ] = useStorage({
    field:'search-filter',
    defaultValue: 'true',
  });

  useEffect(function(){
    const dataHook = app.on('search-data', setMarks);
    const indexHook = app.on('search-index', setIndex);
    const keywordHook = app.on('search-keyword', setKeyword);
    return () => {
      app.remove(dataHook);
      app.remove(indexHook);
      app.remove(keywordHook);
    }
  }, []);

  useEffect(function(){
    const hook = app.on('search-navigate', function(prev){
      if(marks.length <= 0){
        return;
      }
      let navIndex = 0;
      const next = prev ? index - 1 : index + 1;
      const size = marks.length - 1;
      if(next < 0){
        navIndex = size;
      } else if(next > size) {
        navIndex = 0;
      } else {
        navIndex = next;
      }
      const node = marks[navIndex];
      if(!node){
        return;
      }
      app.fire('hightlight', node, 'hightlight');
      dom.scrollIntoView(node);
      setIndex(navIndex);
    });
    return () => {
      app.remove(hook);
    };
  }, [ index, marks ]);

  useEffect(function(){
    app.fire('search-do', keyword, option);
  }, [ keyword, option ]);

  return (
    <>
      <Space style={{display:'flex'}}>
        <Input
          value={keyword}
          onChange={val => {
            setKeyword(val);
            app.fire('send', 'analytics', {event:'search-input'});
          }}
        />
        <div style={{fontSize:14}}>{marks.length <= 0 ? 0 : index + 1}/{marks.length}</div>
        <Icon
          name="up"
          tabIndex={0}
          disabled={marks.length <= 0}
          onClick={() => {
            app.fire('search-navigate', true);
            app.fire('send', 'analytics', {event:'search-up'});
          }}
        />
        <Icon
          name="down"
          tabIndex={0}
          disabled={marks.length <= 0}
          onClick={() => {
            app.fire('search-navigate');
            app.fire('send', 'analytics', {event:'search-down'});
          }}
        />
        <Icon
          tabIndex={0}
          name={filter === 'true' ? 'filter_close' : 'filter_open'}
          onClick={() => {
            setFilter(filter === 'true' ? 'false' : 'true');
            app.fire('send', 'analytics', {event:`search-filter-${filter}`});
          }}
        />
      </Space>
      {filter === 'true' && (
        <Checkbox.Group
          value={option}
          style={{
            display:'block',
            margin:'16px auto 0 -15px',
          }}
          onChange={val => {
            setOption(val);
            app.fire('send', 'analytics', {event:`search-filter-${val}`});
          }}
        >
          <List
            size="small"
            split={false}
            bordered={false}
            dataSource={[{
              label: app.fire('i18n', 'separateword'), value: 'separateWord',
            },{
              label: app.fire('i18n', 'casesensitive'), value: 'caseSensitive',
            },{
              label: app.fire('i18n', 'diacritics'), value: 'diacritics',
            },{
              label: app.fire('i18n', 'wildcards'), value: 'wildcards',
            },{
              label: app.fire('i18n', 'accuracy'), value: 'accuracy',
            }]}
            renderItem={item => (
              <List.Item key={item.value}>
                <Checkbox value={item.value}>{item.label}</Checkbox>
              </List.Item>
            )}
          />
        </Checkbox.Group>
      )}
    </>
  );
}
