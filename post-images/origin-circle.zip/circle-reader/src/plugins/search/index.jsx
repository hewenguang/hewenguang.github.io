import React from 'react';
import ReactDOM from 'react-dom';
import Drawer from 'app/components/drawer';
import controller from './controller';
import Entry from './entry';

App.register('search', ['shadow', 'dom', 'utils'], function(shadow, dom){
  const app = this;
  const root = dom.create('div');
  shadow({
    style: [
      'plugins/antd/index.css',
      'plugins/search/index.css',
    ],
    onReady: function(shadowRoot){
      shadowRoot.appendChild(root);
    },
  });

  // 加载控制器
  controller(app, root);

  ReactDOM.render((
    <Drawer
      app={app}
      type="toolbar"
      plugin="search"
    >
      <Entry />
    </Drawer>
  ), root);
});
