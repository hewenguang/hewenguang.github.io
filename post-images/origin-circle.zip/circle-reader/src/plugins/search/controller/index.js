import Mark from 'mark.js/dist/mark.es6';

export default function(app, root){
  app.on('render-start-done', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('render-destory-done', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-before', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-after', function(){
    dom.setStyle(root, 'display', 'block');
  });

  const container = app.fire('dom-container');
  const instance = new Mark(container);
  app.on('search-do', function(keyword, option){
    if(keyword.length <= 0){
      instance.unmark();
      app.fire('hightlight');
      app.fire('search-index', 0);
      app.fire('search-data', []);
      return;
    }
    const options = {
      acrossElements: true,
      className:'hightlight-block',
      noMatch: function(){
        app.fire('search-index', 0);
        app.fire('search-data', []);
      },
      done: function() {
        const hightlights = container.querySelectorAll('.hightlight-block');
        if(hightlights.length <= 0){
          return;
        }
        app.fire('search-index', 0);
        app.fire('search-data', hightlights);
        app.fire('search-navigate');
      },
    };
    options.separateWordSearch = option.includes('separateWord');
    options.caseSensitive = option.includes('caseSensitive');
    options.diacritics = option.includes('diacritics');
    options.wildcards = option.includes('wildcards') ? 'enabled' : 'disabled'; 
    options.accuracy = option.includes('accuracy') ? 'partially' : 'complementary';
    instance.unmark({
      done: function() {
        instance.mark(keyword, options);
      }
    });
  });
  app.on('search-change', function(visible){
    if(visible){
      return;
    }
    instance.unmark();
    app.fire('hightlight', null, 'hightlight-block');
    app.fire('search-index', 0);
    app.fire('search-data', []);
    app.fire('search-keyword', '');
  });
}
