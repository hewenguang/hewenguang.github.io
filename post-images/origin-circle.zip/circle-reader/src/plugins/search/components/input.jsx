import { Input } from 'antd';
import Icon from 'app/components/icon';
import useApp from 'app/context/useApp';
import React, { useRef, useEffect } from 'react';

export default function(props){
  const { value, onChange } = props;
  const app = useApp();
  const container = useRef(null);

  useEffect(() => {
    const hook = app.on('search-change', function(visible){
      if(!container || !container.current){
        return;
      }
      if(visible){
        setTimeout(function(){
          container.current.focus({cursor: 'end'});
        }, 1000);
      } else {
        container.current.blur();
      }
    });
    return () => {
      app.remove(hook);
    };
  }, []);

  return (
    <Input
      allowClear
      value={value}
      ref={container}
      prefix={<Icon name="search" />}
      placeholder={app.fire('i18n', 'enter_keyword')}
      onChange={event => onChange(event.target.value)}
      onPressEnter={event => {
        event.preventDefault();
        event.stopPropagation();
        app.fire('search-navigate');
      }}
    />
  );
}
