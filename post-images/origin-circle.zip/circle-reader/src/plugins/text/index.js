import { saveAs } from 'file-saver';

App.register('text', function(){
  const app = this;
  const root = app.fire('dom-container');
  if(!root){
    return;
  }
  app.on('text', function(){
    saveAs(new Blob([root.innerText], {type:'text/plain;charset=utf-8'}), `${document.title || 'circle'}.txt`);
    app.fire('send', 'analytics', {event:'text-export'});
  });
  app.fire('text');
});
