export const TINY_IMAGE_SIZE = 78;
export const ELEMENT_FLOAT_MINI_HEIGHT = 130;
export const ELEMENTS_FLEX_DISPLAY = ['div'];
export const ELEMENTS_AFFECT_FONTSTYLE = ['i', 'em'];
export const ATTRIBUTES_TO_REMOVE_REG = /^on|^data|^id$|^class$|^style$/;
export const FONT_ATTRIBUTES_TO_REMOVE = ['size', 'face', 'color'];
export const MAYBE_COMMENT_SELECTOR = ['[id*="comment"]', '[class*="comment"]'];
export const MAYBE_MODAL_SELECTOR = ['[id*="Modal"]', '[class*="Modal"]', '[id*="modal"]', '[class*="modal"]']; // https://www.zhihu.com/question/37503039
export const ELEMENTS_AFFECT_FLOAT = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'];
export const IMAGE_ATTRIBUTES_TO_REMOVE = ['border', 'hspace', 'vspace', 'align'];
// 删除 ins 和 iframe 是为了去广告
export const ELEMENTS_TO_REMOVE = ['noscript', 'form', 'input', 'textarea', 'button', 'style', 'script', 'link', 'ins', 'iframe', 'canvas', 'footer', 'aside'];
export const ELEMENTS_AFFECT_FONTWEIGHT = ['b', 'strong', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'th'];
