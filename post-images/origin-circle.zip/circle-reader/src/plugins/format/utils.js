export function findBlockElement(node, callback){
  let current = node;
  while(current && (utils.isTextNode(current) || (utils.isElement(current) && ['a','span'].includes(current.nodeName.toLowerCase())))){
    current = callback(current);
  }
}

export function text2P(article){
  let current = article.firstChild;
  while(current){
    if(!utils.isTextNode(current)){
      current = current.nextSibling;
      continue;
    }
    // text -> p
    // a + text + a => p
    const text = dom.nodeText(current);
    if(utils.length(text) <= 0){
      current = current.nextSibling;
      continue;
    }
    const replaceNode = dom.create('p');
    const textNode = dom.create('span');
    textNode.textContent = text;
    replaceNode.appendChild(textNode);
    const previousElement = current.previousSibling;
    findBlockElement(previousElement, function(node) {
      replaceNode.insertBefore(node, textNode);
      return node.previousSibling;
    });
    current.parentElement.replaceChild(replaceNode, current);
    current = replaceNode.nextSibling;
    if(!current){
      break;
    }
    findBlockElement(current, function(node) {
      replaceNode.appendChild(node);
      current = replaceNode.nextSibling;
      return current;
    });
    if(!current){
      break;
    }
    current = current.nextSibling;
  }
}

function nextSibling(node){
  let sibling = node.nextSibling;
  while(sibling && utils.isTextNode(sibling) && dom.isNodeWhitespace(sibling)){
    sibling = sibling.nextSibling;
  }
  return sibling;
}

function previousSibling(node){
  let sibling = node.previousSibling;
  while(sibling && utils.isTextNode(sibling) && dom.isNodeWhitespace(sibling)){
    sibling = sibling.previousSibling;
  }
  return sibling;
}

export function removeBr(article){
  const brs = article.querySelectorAll('br');
  if(brs.length < 2){
    return;
  }
  utils.each(brs, function(node){
    const sibling = nextSibling(node);
    const previous = previousSibling(node);
    // 前后节点都不存在，如 p>br
    if(!sibling && !previous){
      dom.remove(node);
      return;
    }
    if(!utils.isTextNode(previous) && !utils.isTextNode(sibling)){
      dom.remove(node);
    }
  });
}

export function formatP(article){
  utils.each(article.querySelectorAll('p'), function(node){
    if(dom.counterNode(node) <= 0){
      dom.remove(node);
      return;
    }
    if(node.childNodes.length !== 1){
      return;
    }
    const firstChild = node.firstChild;
    if(!utils.isTextNode(firstChild)){
      return;
    }
    const text = dom.nodeText(firstChild);
    if(text.length > 0){
      node.textContent = text;
    } else {
      dom.remove(node);
    }
  });
}

export function makesureRootIsDiv(article){
  let articleElement = article;
  if(dom.onlyOneNode(articleElement)){
    const parentElement = articleElement.parentElement;
    const firstElementChild = articleElement.firstElementChild;
    parentElement.replaceChild(firstElementChild, articleElement);
    articleElement = firstElementChild;
  }
  if(dom.tag(articleElement, 'div')){
    dom.removeAttr(articleElement);
  } else{
    const parentElement = articleElement.parentElement;
    const articleMirrorElement = articleElement.mirrorElement;
    const newArticleElement  = dom.replaceNode(articleElement, dom.create('div'));
    newArticleElement.mirrorElement = articleMirrorElement;
    parentElement.replaceChild(newArticleElement, articleElement);
    articleElement = newArticleElement;
  }
  articleElement.classList.add('article');
  return articleElement;
}

