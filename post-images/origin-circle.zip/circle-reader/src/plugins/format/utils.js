import { TINY_IMAGE_SIZE } from './config';

export function findBlockElement(node, callback){
  let current = node;
  while(current && (utils.isTextNode(current) || (utils.isElement(current) && ['a','span'].includes(current.nodeName.toLowerCase())))){
    current = callback(current);
  }
}

export function text2P(article){
  let current = article.firstChild;
  while(current){
    if(!utils.isTextNode(current)){
      current = current.nextSibling;
      continue;
    }
    // text -> p
    // a + text + a => p
    const text = dom.nodeText(current);
    if(utils.length(text) <= 0){
      current = current.nextSibling;
      continue;
    }
    const replaceNode = dom.create('p');
    const textNode = dom.create('span');
    textNode.textContent = text;
    replaceNode.appendChild(textNode);
    const previousElement = current.previousSibling;
    findBlockElement(previousElement, function(node) {
      replaceNode.insertBefore(node, textNode);
      return node.previousSibling;
    });
    current.parentElement.replaceChild(replaceNode, current);
    current = replaceNode.nextSibling;
    if(!current){
      break;
    }
    findBlockElement(current, function(node) {
      replaceNode.appendChild(node);
      current = replaceNode.nextSibling;
      return current;
    });
    if(!current){
      break;
    }
    current = current.nextSibling;
  }
}

function nextSibling(node){
  let sibling = node.nextSibling;
  while(sibling && utils.isTextNode(sibling) && dom.isNodeWhitespace(sibling)){
    sibling = sibling.nextSibling;
  }
  return sibling;
}

function previousSibling(node){
  let sibling = node.previousSibling;
  while(sibling && utils.isTextNode(sibling) && dom.isNodeWhitespace(sibling)){
    sibling = sibling.previousSibling;
  }
  return sibling;
}

export function removeBr(article){
  const brs = article.querySelectorAll('br');
  if(brs.length < 2){
    return;
  }
  utils.each(brs, function(node){
    const sibling = nextSibling(node);
    const previous = previousSibling(node);
    // 前后节点都不存在，如 p>br
    if(!sibling && !previous){
      dom.remove(node);
      return;
    }
    if(!utils.isTextNode(previous) && !utils.isTextNode(sibling)){
      dom.remove(node);
    }
  });
}

export function formatBr(article){
  utils.each(article.querySelectorAll('p'), function(p){
    const brs = p.getElementsByTagName('br');
    if(brs.length <= 1){
      return;
    }
    const brsToRemove = [];
    const parent = p.parentElement;
    const nextSibling = p.nextSibling;
    utils.each(brs, function(node){
      if(!node){
        return; // https://towardsdatascience.com/negative-binomial-regression-f99031bb25b4
      }
      let sibling = node.nextSibling;
      if(!sibling){
        return;
      }
      const replaceNode = dom.create('p');
      let nextsibling;
      while(sibling && !dom.tag(sibling, 'br')){
        nextsibling = sibling.nextSibling;
        replaceNode.appendChild(sibling);
        sibling = nextsibling;
      }
      if(nextSibling){
        parent.insertBefore(replaceNode, nextSibling);
      } else {
        parent.appendChild(replaceNode);
      }
      brsToRemove.push(node);
    });
    utils.each(brsToRemove, function(node){
      dom.remove(node);
    });
  });
}

export function copyStyle(node, styles, style){
  utils.each(styles, function(item){
    const value = style[item];
    value && value !== 'normal' && dom.setStyle(node, item, value);
  });
}

export function adjust(node){
  const src = node.src;
  src && src.startsWith('data') && node.classList.add('base64');
  const width = node.naturalWidth;
  const height = node.naturalHeight;
  if(width <= 0 || height <= 0){
    return;
  }
  if (width < TINY_IMAGE_SIZE && height < TINY_IMAGE_SIZE){
    node.classList.add('tiny');
  } else {
    node.classList.add('large');
  }
}
