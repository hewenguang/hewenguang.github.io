// Inspired by safari reader mode

import {
  TINY_IMAGE_SIZE,
  ELEMENTS_TO_REMOVE,
  ELEMENTS_AFFECT_FLOAT,
  ATTRIBUTES_TO_REMOVE_REG,
  ELEMENT_FLOAT_MINI_HEIGHT,
  FONT_ATTRIBUTES_TO_REMOVE,
  IMAGE_ATTRIBUTES_TO_REMOVE,
  ELEMENTS_AFFECT_FONTSTYLE,
  RATIO_IMAGE_WIDTH_TO_PARENT,
  ELEMENTS_AFFECT_FONTWEIGHT,
} from './config';

import {
  text2P,
  formatP,
  removeBr,
  makesureRootIsDiv,
} from './utils';

App.register('format', ['utils', 'dom'], function(utils, dom){
  const app = this;
  app.on('format', function(article, title, page){
    let inFloat = 0;
    let inTable = 0;
    let inFontStyle = 0;
    let inFontWeight = 0;

    function depthLevels(delta){
      inFloat && (inFloat += delta);
      inTable && (inTable += delta);
      inFontStyle && (inFontStyle += delta);
      inFontWeight && (inFontWeight += delta);
    }

    function depthLevelsAfter(){
      inFloat === 1 && (inFloat = 0);
      inTable === 1 && (inTable = 0);
      inFontStyle === 1 && (inFontStyle = 0);
      inFontWeight === 1 && (inFontWeight = 0);
    }
    let current = article;
    const elementsToRemove = [];
    const articleRect = dom.position(article.mirrorElement || article);
    while(current){
      let elementToRemove;
      let target = current.mirrorElement;
      if(target){
        let nodeName = current.nodeName.toLowerCase();
        const style = window.getComputedStyle(target);
        const float = style.float;
        const display = style.display;
        display === 'none' && (elementToRemove = current);
        if(!elementToRemove){
          const text = dom.nodeText(current);
          const outline = ['目录', '大纲'];
          title && outline.push(title);
          outline.includes(text) && (elementToRemove = current);
        }
        !elementToRemove && dom.removeAttr(current, attributeName => ATTRIBUTES_TO_REMOVE_REG.test(attributeName));
        if(!elementToRemove){
          // 清除浮动
          const clearStyle = style.clear;
          clearStyle && clearStyle === 'both' && current.classList.add('both');
          const targetStyle = window.getComputedStyle(target, ':after');
          const afterClearStyle = targetStyle.clear;
          afterClearStyle && afterClearStyle === 'both' && current.classList.add('both');
        }
        if(!elementToRemove && nodeName === 'div' && current !== article){
          const elements = target.querySelectorAll('blockquote, dl, div, ol, p, pre, table, ul');
          if (!(inFloat || float !== 'none') && elements.length <= 0){
            const replaceNode = dom.create('p');
            replaceNode.mirrorElement = current.mirrorElement;
            while(current.firstChild) {
              replaceNode.appendChild(current.firstChild);
            }
            utils.each(current.attributes, function(attr){
              const attrName = attr.nodeName;
              const attrValue = attr.nodeValue;
              attrValue && dom.setAttr(replaceNode, attrName, attrValue);
            });
            current.parentElement.replaceChild(replaceNode, current);
            nodeName = 'p';
            current = replaceNode;
            target = replaceNode.mirrorElement;
          }
          ['inline-block'].includes(display) && dom.setStyle(current, 'display', display);
        }
        if(!elementToRemove){
          const targetRect = dom.position(target);
          if(nodeName !== 'img' && current !== article){
            if(!inFloat && float !== 'none' && (targetRect.height >= ELEMENT_FLOAT_MINI_HEIGHT || target.childElementCount > 0)
            ){
              inFloat = 1;
            }
            if (!inFontStyle && style.fontStyle !== 'normal'){
              current !== article && !ELEMENTS_AFFECT_FONTSTYLE.includes(nodeName) && (current.style.fontStyle = style.fontStyle);
              inFontStyle = 1;
            }
            if (!inFontWeight && style.fontWeight !== 'normal' && style.fontWeight > 400){
              current !== article && !ELEMENTS_AFFECT_FONTWEIGHT.includes(nodeName) && (current.style.fontWeight = style.fontWeight);
              inFontWeight = 1;
            }
          }
          const widthValue = style.width || targetRect.width;
          if (inFloat) {
            if(inFloat === 1){
              if(targetRect.width === articleRect.width){
                current.classList.add('full-width');
              } else {
                if(float && !ELEMENTS_AFFECT_FLOAT.includes(nodeName)){
                  // 包含图片再设置浮动
                  const elements = target.querySelectorAll('img');
                  elements.length > 0 && current.classList.add(float);
                }
              }
              // 数值大于 10 才设置
              if(!ELEMENTS_AFFECT_FLOAT.includes(nodeName)
                && widthValue
                && widthValue !== 'auto'
                && parseFloat(widthValue) > 10){
                dom.setStyle(current, 'maxWidth', widthValue);
              }
            }
          }
          let temp;
          switch(nodeName){
            case 'svg':
              // https://zhuanlan.zhihu.com/p/355030710
              if(style.position === 'absolute' && widthValue && widthValue !== 'auto' && parseFloat(widthValue) < 80){
                elementToRemove = current;
              }
              break;
            case 'table':
              !inTable && (inTable = 1);
              break;
            case 'img':
              if(inFloat) {
                dom.setStyle(current, 'float', float);
              } else if(targetRect.width > 0 && targetRect.height > 0){
                if (targetRect.width < TINY_IMAGE_SIZE && targetRect.height < TINY_IMAGE_SIZE){
                  current.classList.add('tiny');
                } else if ((targetRect.width / articleRect.width) > RATIO_IMAGE_WIDTH_TO_PARENT) {
                  current.classList.add('large');
                }
              }
              if(!inTable && widthValue && widthValue !== 'auto' && parseFloat(widthValue) > 10){
                dom.setStyle(current, 'maxWidth', widthValue);
              }
              break;
            case 'a':
              temp = dom.getAttr(current, 'href');
              if (temp && temp.length && (temp[0] === '#' || temp.substring(0, 11) === 'javascript:')){
                elementToRemove = current;
              }
              break;
          }
        }
      }
      const firstElementChild = current.firstElementChild;
      if (firstElementChild) {
        current = firstElementChild;
        depthLevels(1);
      }else{
        let nextSibling;
        while (current !== article && !(nextSibling = current.nextElementSibling)){
          current = current.parentElement;
          depthLevels(-1);
        }
        if(current === article){
          elementToRemove && dom.remove(elementToRemove);
          break;
        }
        current = nextSibling;
        depthLevelsAfter();
      }
      elementToRemove && elementsToRemove.push(elementToRemove);
    }
    utils.each(elementsToRemove, function(elementToRemove){
      dom.remove(elementToRemove);
    });
    // 转换根 text 为 p
    text2P(article);
    // 删除无用 br
    removeBr(article);
    // 格式化 p
    formatP(article);
    // 清除空元素
    utils.each(article.querySelectorAll('div, ol, ul, section'), function(node){
      dom.counterNode(node) <= 0 && dom.remove(node);
    });
    // 删除空的 ul 和 ol 如目录
    utils.each(article.querySelectorAll('ul, ol'), function(node){
      if(node.querySelectorAll('*').length > node.innerText.replace(/\n/ig, '').length){
        dom.remove(node);
      }
    });
    // 删除空的 li todo https://www.smashingmagazine.com/2016/05/a-guide-to-personal-side-projects/
    // utils.each(article.querySelectorAll('li'), function(node){
    //   // 空格处理
    //   if(node.querySelectorAll('*').length > node.innerText.replace(/\n/ig, '').length){
    //     dom.remove(node);
    //   }
    // });
    // 正文容器必须是 div
    utils.wait(function(){
      app.fire('format-done', makesureRootIsDiv(article), title, page);
    });
  });
  app.on('format-start', function(article, title, page){
    //删除不需要的元素
    utils.each(article.querySelectorAll(ELEMENTS_TO_REMOVE.join(',')), function(node){
      dom.remove(node);
    });
    // 校验 li 包含 div 和 img ，同时链接密度很大(0.8)
    utils.each(article.querySelectorAll('li'), function(node){
      const divs = node.querySelectorAll('div');
      const imgs = node.querySelectorAll('img');
      if(divs.length > 0 && imgs.length > 0 && dom.linkDensity(node) > 0.8){
        dom.remove(node);
      }
    });
    // 删除 font 属性
    utils.each(article.querySelectorAll('font'), function(node){
      dom.removeAttr(node, attributeName => FONT_ATTRIBUTES_TO_REMOVE.includes(attributeName));
    });
    // 处理图片
    utils.each(article.querySelectorAll('img'), function(node){
      // 删除无用属性
      dom.removeAttr(node, attributeName => IMAGE_ATTRIBUTES_TO_REMOVE.includes(attributeName));
      // 删除加载失败的图片
      dom.imgFilter(node);
      const mirrorElement = node.mirrorElement;
      const url = dom.imgUrl(mirrorElement);
      if(url && dom.getAttr(node, 'src') !== url){
        dom.setAttr(node, 'src', url);
      } else {
        mirrorElement.addEventListener('load', function(){
          dom.setAttr(node, 'src', mirrorElement.src);
        });
      }
      // 删除仍然找不到地址的图片
      !dom.getAttr(node, 'src') && dom.remove(node);
    });
    app.fire('format', article, title, page);
  });
});
