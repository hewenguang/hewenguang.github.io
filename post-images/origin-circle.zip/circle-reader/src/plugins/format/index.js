// Inspired by safari reader mode

import {
  ELEMENTS_TO_REMOVE,
  MAYBE_MODAL_SELECTOR,
  ELEMENTS_FLEX_DISPLAY,
  ELEMENTS_AFFECT_FLOAT,
  MAYBE_COMMENT_SELECTOR,
  ATTRIBUTES_TO_REMOVE_REG,
  ELEMENT_FLOAT_MINI_HEIGHT,
  FONT_ATTRIBUTES_TO_REMOVE,
  IMAGE_ATTRIBUTES_TO_REMOVE,
  ELEMENTS_AFFECT_FONTSTYLE,
  ELEMENTS_AFFECT_FONTWEIGHT,
} from './config';

import {
  adjust,
  text2P,
  removeBr,
  formatBr,
  copyStyle,
} from './utils';

App.register('format', ['utils', 'dom'], function(utils, dom){
  const app = this;
  function format(article, title){
    let inFloat = 0;
    let inTable = 0;
    let inFontStyle = 0;
    let inFontWeight = 0;

    function depthLevels(delta){
      inFloat && (inFloat += delta);
      inTable && (inTable += delta);
      inFontStyle && (inFontStyle += delta);
      inFontWeight && (inFontWeight += delta);
    }

    function depthLevelsAfter(){
      inFloat === 1 && (inFloat = 0);
      inTable === 1 && (inTable = 0);
      inFontStyle === 1 && (inFontStyle = 0);
      inFontWeight === 1 && (inFontWeight = 0);
    }
    let current = article;
    const elementsToRemove = [];
    const articleRect = dom.position(article.mirrorElement || article);
    while(current){
      let elementToRemove;
      let target = current.mirrorElement;
      if(target){
        let nodeName = current.nodeName.toLowerCase();
        const style = window.getComputedStyle(target);
        const float = style.float;
        const display = style.display;
        if(display === 'none' || style.opacity === '0' || style.visibility === 'hidden'){
          elementToRemove = current;
        }
        if(!elementToRemove){
          const text = dom.nodeText(current);
          const outline = ['目录', '大纲'];
          title && outline.push(title);
          outline.includes(text) && (elementToRemove = current);
        }
        if(current !== article){
          !elementToRemove && dom.removeAttr(current, attributeName => ATTRIBUTES_TO_REMOVE_REG.test(attributeName));
          if(!elementToRemove){
            // 清除浮动
            const clearStyle = style.clear;
            clearStyle && clearStyle === 'both' && current.classList.add('both');
            const targetStyle = window.getComputedStyle(target, ':after');
            const afterClearStyle = targetStyle.clear;
            afterClearStyle && afterClearStyle === 'both' && current.classList.add('both');
          }
        }
        if(!elementToRemove && current !== article){
          if(nodeName === 'div'){
            const elements = target.querySelectorAll('blockquote, dl, div, ol, p, pre, table, ul');
            if (!(inFloat || float !== 'none') && elements.length <= 0){
              const replaceNode = dom.create('p');
              replaceNode.mirrorElement = current.mirrorElement;
              while(current.firstChild) {
                replaceNode.appendChild(current.firstChild);
              }
              utils.each(current.attributes, function(attr){
                const attrName = attr.nodeName;
                const attrValue = attr.nodeValue;
                attrValue && dom.setAttr(replaceNode, attrName, attrValue);
              });
              current.parentElement.replaceChild(replaceNode, current);
              nodeName = 'p';
              current = replaceNode;
              target = replaceNode.mirrorElement;
            }
            display === 'inline-block' && current.classList.add('inline-block');
          } else if(nodeName.includes('-') && nodeName.indexOf('inner') <= -1){ // https://xueqiu.com/7667646479/160391318
            // 自定义元素
            ['block', 'inline-block', 'flex', 'inline-flex'].includes(display) && current.classList.add(display);
          }
          if(ELEMENTS_FLEX_DISPLAY.includes(nodeName)){
            const elements = target.querySelectorAll('img');
            if(elements.length > 0 && ['flex', 'inline-flex'].includes(display)){
              current.classList.add(display);
              copyStyle(current, ['align-items', 'justify-content'], style);
            }
          }
        }
        if(!elementToRemove){
          const targetRect = dom.position(target);
          if(nodeName !== 'img' && current !== article){
            if(!inFloat && float && float !== 'none' && (targetRect.height >= ELEMENT_FLOAT_MINI_HEIGHT || target.childElementCount > 0)
            ){
              inFloat = 1;
            }
            if (!inFontStyle && style.fontStyle && style.fontStyle !== 'normal'){
              current !== article && !ELEMENTS_AFFECT_FONTSTYLE.includes(nodeName) && (current.style.fontStyle = style.fontStyle);
              inFontStyle = 1;
            }
            if (!inFontWeight && style.fontWeight && style.fontWeight !== 'normal' && style.fontWeight > 400){
              current !== article && !ELEMENTS_AFFECT_FONTWEIGHT.includes(nodeName) && (current.style.fontWeight = style.fontWeight);
              inFontWeight = 1;
            }
          }
          const widthValue = style.width || targetRect.width;
          if (inFloat) {
            if(inFloat === 1){
              if(targetRect.width === articleRect.width){
                current.classList.add('full-width');
              } else {
                // 包含图片再设置浮动
                const elements = target.querySelectorAll('img');
                if(elements.length > 0){
                  float && float !== 'none' && !ELEMENTS_AFFECT_FLOAT.includes(nodeName) && current.classList.add(float);
                  // 数值大于 10 才设置
                  if(!ELEMENTS_AFFECT_FLOAT.includes(nodeName) && widthValue && widthValue !== 'auto' && parseFloat(widthValue) > 10){
                    dom.setStyle(current, 'maxWidth', widthValue);
                  }
                }
              }
            }
          }
          let temp;
          switch(nodeName){
            case 'svg':
              // https://zhuanlan.zhihu.com/p/355030710
              if(style.position === 'absolute' && widthValue && widthValue !== 'auto' && parseFloat(widthValue) < 80){
                elementToRemove = current;
              }
              break;
            case 'table':
              !inTable && (inTable = 1);
              break;
            case 'img':
              inFloat && float && float !== 'none' && dom.setStyle(current, 'float', float);
              if(!inTable && widthValue && widthValue !== 'auto' && parseFloat(widthValue) > 10){
                dom.setStyle(current, 'maxWidth', widthValue);
              }
              copyStyle(current, ['border-radius'], style);
              break;
            case 'a':
              temp = dom.getAttr(current, 'href');
              if (temp && temp.length && (temp[0] === '#' || temp.substring(0, 11) === 'javascript:')){
                elementToRemove = current;
              }
              break;
          }
        }
      }
      const firstElementChild = current.firstElementChild;
      if (firstElementChild) {
        current = firstElementChild;
        depthLevels(1);
      }else{
        let nextSibling;
        while (current !== article && !(nextSibling = current.nextElementSibling)){
          current = current.parentElement;
          depthLevels(-1);
        }
        if(current === article){
          elementToRemove && dom.remove(elementToRemove);
          break;
        }
        current = nextSibling;
        depthLevelsAfter();
      }
      elementToRemove && elementsToRemove.push(elementToRemove);
    }
    utils.each(elementsToRemove, function(elementToRemove){
      dom.remove(elementToRemove);
    });
    // 清除空元素
    utils.each(article.querySelectorAll('div, ol, ul, li, section'), function(node){
      dom.counterNode(node) <= 0 && dom.remove(node);
    });
    // 删除空的 ul 和 ol 如目录
    utils.each(article.querySelectorAll('ul, ol'), function(node){
      if(node.querySelectorAll('*').length > node.innerText.replace(/\n/ig, '').length){
        dom.remove(node);
      }
    });
    // 转换根 text 为 p
    text2P(article);
    // 删除无用 br
    removeBr(article);
    // 转换 p + 多个 br -> p + p
    formatBr(article);
    // 处理空格
    utils.each(article.querySelectorAll('a, p, span, li'), function(node){
      const childNodes = node.childNodes;
      if(childNodes.length <= 0){
        dom.remove(node);
        return;
      }
      // 只有一个 br
      if(childNodes.length === 1 && dom.tag(childNodes[0], 'br')){
        dom.remove(node);
        return;
      }
      const item = childNodes[0];
      if(!utils.isTextNode(item)){
        return;
      }
      const text = item.nodeValue;
      text.length > 0 && /^\s+/.test(text) && (item.nodeValue = text.trim());
    });
    // table + pre https://eligrey.com/blog/saving-generated-files-on-the-client-side/
    utils.each(article.querySelectorAll('pre'), function(node){
      const td = node.parentElement;
      if(!td || !dom.tag(td, 'td')){
        return;
      }
      const table = td.closest('table');
      if(!table){
        return;
      }
      const tds = table.querySelectorAll('td');
      if(tds.length !== 1){
        return;
      }
      table.parentElement.replaceChild(node, table);
    });
    // flex > pre 造成排版异常 https://towardsdatascience.com/negative-binomial-regression-f99031bb25b4
    utils.each(article.querySelectorAll('.flex'), function(node){
      const pre = node.querySelectorAll('pre');
      if(pre.length <= 0){
        return;
      }
      utils.each(pre, function(item){
        const parent = item.parentElement;
        if(!parent.classList.contains('zone-width')){
          parent.classList.add('zone-width');
        }
      });
    });
    // 处理 div/span > p https://ahrefs.com/blog/zh/nofollow-links/
    // todo
  }

  app.on('format', function(article, title){
    //删除不需要的元素
    utils.each(article.querySelectorAll(ELEMENTS_TO_REMOVE.join(',')), function(node){
      dom.remove(node);
    });
    // 删除可能是 modal 的元素
    utils.each(article.querySelectorAll(MAYBE_MODAL_SELECTOR.join(',')), function(node){
      const target = node.mirrorElement;
      if(!target){
        return;
      }
      !dom.visible(node) && dom.remove(node);
    });
    // 对 iframe 单独处理
    // utils.each(article.querySelectorAll('iframe'), function(node){
    //   !/video/.test(`${node.className} ${node.id}`) && dom.remove(node);
    // });
    // 删除可能存在的评论
    const comments = [];
    utils.each(article.querySelectorAll(MAYBE_COMMENT_SELECTOR.join(',')), function(node){
      if(!dom.tag(node, 'div')){
        return;
      }
      const target = node.mirrorElement;
      if(!target){
        return;
      }
      const rect = target.getBoundingClientRect();
      if(rect.width <= 0 || rect.height <= 200){
        return;
      }
      comments.push(node);
    });
    if(comments.length > 0){
      let current = comments[0];
      while (current.parentElement !== article){
        current = current.parentElement;
      }
      // todo 需要加入验证
      current !== article && dom.remove(current);
    }
    // todo 删除 li https://www.smashingmagazine.com/2016/05/a-guide-to-personal-side-projects/
    // 校验 li 包含 div 和 img ，同时链接密度很大(0.8)
    utils.each(article.querySelectorAll('li'), function(node){
      const divs = node.querySelectorAll('div');
      const imgs = node.querySelectorAll('img');
      if(divs.length > 0 && imgs.length > 0 && dom.linkDensity(node) > 0.8){
        dom.remove(node);
      }
    });
    // 删除 font 属性
    utils.each(article.querySelectorAll('font'), function(node){
      dom.removeAttr(node, attributeName => FONT_ATTRIBUTES_TO_REMOVE.includes(attributeName));
    });
    // 处理图片
    utils.each(article.querySelectorAll('img'), function(node){
      // 删除无用属性
      dom.removeAttr(node, attributeName => IMAGE_ATTRIBUTES_TO_REMOVE.includes(attributeName));
      // 删除加载失败的图片
      node.addEventListener('error', function(){
        dom.remove(node);
      });
      node.complete && adjust(node);
      node.addEventListener('load', function(){
        adjust(node);
      });
      if(!node || !node.mirrorElement){
        return;
      }
      const mirrorElement = node.mirrorElement;
      const url = dom.imgUrl(mirrorElement);
      if(url && dom.getAttr(node, 'src') !== url){
        dom.setAttr(node, 'src', url);
      } else {
        mirrorElement.addEventListener('load', function(){
          dom.setAttr(node, 'src', mirrorElement.src);
        });
      }
      // 删除仍然找不到地址的图片
      !dom.getAttr(node, 'src') && dom.remove(node);
    });
    format(article, title);
  });
});
