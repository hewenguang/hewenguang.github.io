import { saveAs } from 'file-saver';

App.register('lnk', function(){
  const app = this;
  app.on('lnk', function(){
    let favicon = `${location.origin}/favicon.ico`;
    const icons = document.head.querySelectorAll('link[rel~=\'icon\']');
    if(icons.length === 1){
      const href = icons[0].href;
      href && (favicon = href);
    }
    const hash = location.hash;
    const url = `${location.href}${hash ? '/' : '#'}circle=on`;
    const value = [
      '[{000214A0-0000-0000-C000-000000000046}]',
      'Prop3=19,11',
      '[InternetShortcut]',
      'IDList=',
      `URL=${url}`,
      `IconFile=${favicon}`,
      'IconIndex=1',
    ];
    saveAs(new Blob([value.join('\n')], {type:'text/plain;charset=utf-8'}), `${document.title || 'circle'}.url`);
    app.fire('send', 'analytics', {event:'lnk-export'});
  });
  app.fire('lnk');
});
