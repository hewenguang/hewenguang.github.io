import { Modal } from 'antd';
import React, { useState, useEffect } from 'react';
import Account from './account';

export default function(props){
  const { app } = props;
  const [ visible, setVisible ] = useState(false);
  const [ action, setAction ] = useState(undefined);

  useEffect(() => {
    const hook = app.on('upgrade', function(hidden){
      setAction(utils.isString(hidden) ? hidden : undefined);
      setVisible(utils.isBoolean(hidden) ? hidden : !visible);
    });
    return () => {
      app.remove(hook);
    };
  }, [ visible ]);

  return (
    <Modal
      width={450}
      footer={null}
      destroyOnClose
      visible={visible}
      bodyStyle={{padding:0}}
      onCancel={() => setVisible(false)}
    >
      <Account value={action} onChange={setAction} />
    </Modal>
  );
}
