import React, { useState, useEffect } from 'react';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import { Form, Input, Button } from 'antd';
import KeyOutlined from '@ant-design/icons/KeyOutlined';
import UserOutlined from '@ant-design/icons/UserOutlined';

export default function(){
  const app = useApp();
  const user = useUser();
  const islogin = user && user.id;
  const [ visible, setVisible ] = useState(true);
  const [ loading, setLoading ] = useState(false);

  useEffect(() => {
    const hook = app.on('user-change', setVisible);
    return () => {
      app.remove(hook);
    };
  }, []);

  if(!visible){
    return null;
  }

  return (
    <>
      <h1 className="title">{app.fire('i18n', 'upgrade')}</h1>
      {!islogin && (
        <div className="login_mask">
          <Button
            type="primary"
            onClick={() => {
              if(app.cache('env') === 'option'){
                app.fire('upgrade');
              } else {
                app.fire('srt-wrench');
              }
              app.fire('send', 'analytics', {event:'user-need-login'});
            }}
          >
            {app.fire('i18n', 'please_login')}
          </Button>
        </div>
      )}
      <Form
        name="upgrade"
        className="upgrade"
        scrollToFirstError
        onFinish={(values) => {
          setLoading(true);
          app.fire('send', 'regcode', {
            regcode: values.regcode,
          }, function({error}){
            setLoading(false);
            if(error){
              app.fire('message', {
                key: 'upgrade',
                type: 'error',
                message: error,
              });
            } else {
              app.fire('login');
              app.fire('upgrade');
              app.cache('env') !== 'option' && app.fire('srt-wrench');
            }
          });
        }}
      >
        <Form.Item>
          <Input
            disabled
            prefix={<UserOutlined />}
            value={user.name || app.fire('i18n', 'please_login')}
          />
        </Form.Item>
        <Form.Item
          name="regcode"
          rules={[{required:true,message: app.fire('i18n', 'required')}]}
          extra={
            <a target="_blank" href={app.to('checkout')}>
              {app.fire('i18n', 'exchange_tooltip')}
            </a>
          }
        >
          <Input
            disabled={!islogin}
            prefix={<KeyOutlined />}
            placeholder={app.fire('i18n', 'exchange_placeholder')}
          />
        </Form.Item>
        <Form.Item>
          <Button
            block
            type="primary"
            htmlType="submit"
            loading={loading}
            disabled={!islogin}
          >
            {app.fire('i18n', 'exchange')}
          </Button>
        </Form.Item>
      </Form>
    </>
  );
}
