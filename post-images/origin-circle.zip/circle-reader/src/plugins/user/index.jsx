import React from 'react';
import ReactDOM from 'react-dom';
import Drawer from 'app/components/drawer';
import Entry from './entry';
import './index.less';

App.register('user', ['shadow', 'dom'], function(shadow, dom){
  const app = this;
  const root = dom.create('div');
  shadow({
    style: [
      'plugins/antd/index.css',
      'plugins/user/index.css',
    ],
    onReady: function(shadowRoot){
      shadowRoot.appendChild(root);
    },
  });

  ReactDOM.render((
    <Drawer
      app={app}
      type="modal"
      plugin="user"
    >
      <Entry />
    </Drawer>
  ), root);
});
