import React from 'react';
import ReactDOM from 'react-dom';
import { ConfigProvider } from 'antd';
import { AppContext } from 'app/context';
import zhCN from 'antd/lib/locale/zh_CN';
import enGB from 'antd/lib/locale/en_GB';
import 'antd/dist/antd.css';
import Entry from './entry';
import './index.less';

App.register('user', ['shadow', 'dom'], function(shadow, dom){
  const app = this;
  const root = dom.create('div', {className:'root'});
  shadow({
    root: document.documentElement,
    style: [
      'plugins/antd/index.css',
      'plugins/user/index.css',
    ],
    onReady: function(shadowRoot){
      shadowRoot.appendChild(root);
    },
  });

  ReactDOM.render((
    <AppContext.Provider value={app}>
      <ConfigProvider
        getPopupContainer={() => root}
        locale={app.i18n.getUILanguage() === 'zh-CN' ? zhCN : enGB}
      >
        <Entry app={app} />
      </ConfigProvider>
    </AppContext.Provider>
  ), root);
});
