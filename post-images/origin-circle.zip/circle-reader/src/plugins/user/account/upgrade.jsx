import React, { useState } from 'react';
import useApp from 'app/context/useApp';
import { Form, Input, Button } from 'antd';
import { UserOutlined, KeyOutlined } from '@ant-design/icons';

export default function(props){
  const { user } = props;
  const app = useApp();
  const [ loading, setLoading ] = useState(false);

  return (
    <Form
      name="upgrade"
      scrollToFirstError
      initialValues={{
        username: user.name,
      }}
      onFinish={(values) => {
        setLoading(true);
        app.fire('send', 'regcode', {
          regcode: values.regcode,
        }, function({error}){
          setLoading(false);
          if(error){
            app.fire('message', {
              key: 'upgrade',
              type: 'error',
              message: error,
            });
          } else {
            app.fire('login');
            app.fire('upgrade');
          }
        });
      }}
    >
      <Form.Item
        name="username"
      >
        <Input
          disabled
          prefix={<UserOutlined />}
        />
      </Form.Item>
      <Form.Item
        name="regcode"
        rules={[{ required: true, message: app.fire('i18n', 'required') }]}
      >
        <Input
          placeholder={app.fire('i18n', 'exchange_placeholder')}
          prefix={
            <KeyOutlined />
          }
        />
      </Form.Item>
      <Form.Item>
        <div className="login-extra">
          <a target="_blank" href="https://ranhe.xyz/upgrade/">
            {app.fire('i18n', 'exchange_tooltip')}
          </a>
          <Button
            type="primary"
            htmlType="submit"
            loading={loading}
          >
            {app.fire('i18n', 'exchange')}
          </Button>
        </div>
      </Form.Item>
    </Form>
  );
}
