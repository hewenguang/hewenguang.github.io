import React, { useState } from 'react';
import useApp from 'app/context/useApp';
import { Form, Input, Button } from 'antd';
import { MailOutlined, UserOutlined, LockOutlined } from '@ant-design/icons';

export default function(props){
  const { onChange, onSuccess } = props;
  const app = useApp();
  const [ loading, setLoading ] = useState(false);

  return (
    <Form
      name="register"
      scrollToFirstError
      onFinish={values => {
        setLoading(true);
        app.fire('send', 'register', values, function({error, data}){
          setLoading(false);
          if(error){
            app.fire('message', {
              key: 'login',
              type: 'error',
              message: error,
            });
          } else {
            app.fire('login');
            onSuccess && onSuccess(data);
          }
        });
      }}
    >
      <Form.Item
        name="name"
        rules={[{ required: true, message: app.fire('i18n', 'required'), whitespace: true }]}
      >
        <Input
          placeholder={app.fire('i18n', 'name_placeholder')}
          prefix={<UserOutlined />}
        />
      </Form.Item>
      <Form.Item
        name="pass"
        hasFeedback
        rules={[
          {
            required: true,
            message: app.fire('i18n', 'required'),
          },
        ]}
      >
        <Input
          type="password"
          placeholder={app.fire('i18n', 'password_placeholder')}
          prefix={<LockOutlined />}
        />
      </Form.Item>
      <Form.Item
        hasFeedback
        name="confirm"
        dependencies={['pass']}
        rules={[
          {
            required: true,
            message: app.fire('i18n', 'confirm'),
          },
          ({ getFieldValue }) => ({
            validator(_, value) {
              if (!value || getFieldValue('pass') === value) {
                return Promise.resolve();
              }
              return Promise.reject(new Error(app.fire('i18n', 'confirm')));
            },
          }),
        ]}
      >
        <Input
          type="password"
          placeholder={app.fire('i18n', 'confirm_placeholder')}
          prefix={<LockOutlined />}
        />
      </Form.Item>
      <Form.Item
        name="mail"
        rules={[
          {
            type: 'email',
            message: app.fire('i18n', 'email_valid'),
          },
          {
            required: true,
            message: app.fire('i18n', 'required'),
          },
        ]}
      >
        <Input
          placeholder={app.fire('i18n', 'email_placeholder')}
          prefix={<MailOutlined />}
        />
      </Form.Item>
      <Form.Item>
        <div className="login-extra">
          <a onClick={() => onChange('login')}>
            {app.fire('i18n', 'login_account')}
          </a>
          <Button
            type="primary"
            htmlType="submit"
            loading={loading}
          >
            {app.fire('i18n', 'register')}
          </Button>
        </div>
      </Form.Item>
    </Form>
  );
}
