import React from 'react';
import { Tabs } from 'antd';
import Login from './login';
import Upgrade from './upgrade';
import Register from './register';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import './index.less';

const { TabPane } = Tabs;

export default function(props){
  const { value, onChange } = props;
  const app = useApp();
  const user = useUser();
  const data = user && user.id ? {
    upgrade: {
      title: app.fire('i18n', 'upgrade'),
      value: (
        <Upgrade user={user} />
      ),
    }
  } : {
    login: {
      title: app.fire('i18n', 'login'),
      value: (
        <Login
          onChange={onChange}
          onSuccess={account => {
            if(account && account.id && !account.member && value ==='upgrade'){
              onChange('upgrade');
            } else {
              app.fire('upgrade');
            }
          }}
        />
      ),
    },
    register: {
      title: app.fire('i18n', 'register'),
      value: (
        <Register
          onChange={onChange}
          onSuccess={account => {
            if(account && account.id && !account.member && value ==='upgrade'){
              onChange('upgrade');
            } else {
              app.fire('upgrade');
            }
          }}
        />
      ),
    },
  };
  const keys = Object.keys(data);
  const activeKey = keys.includes(value) ? value : keys[0];

  return (
    <Tabs
      centered
      size="large"
      className="account"
      onChange={onChange}
      activeKey={activeKey}
      destroyInactiveTabPane
    >
      {keys.map(key => {
        const item = data[key];
        return (
          <TabPane
            key={key}
            tab={item.title}
          >
            {item.value}
          </TabPane>
        );
      })}
    </Tabs>
  );
}
