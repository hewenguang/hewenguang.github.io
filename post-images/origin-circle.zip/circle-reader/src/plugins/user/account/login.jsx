import React, { useState } from 'react';
import useApp from 'app/context/useApp';
import { Form, Input, Button } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';

export default function(props){
  const { onChange, onSuccess } = props;
  const app = useApp();
  const [ loading, setLoading ] = useState(false);

  return (
    <Form
      name="login"
      scrollToFirstError
      onFinish={values => {
        setLoading(true);
        app.fire('send', 'login', values, function({error, data}){
          setLoading(false);
          if(error){
            app.fire('message', {
              key: 'login',
              type: 'error',
              message: error,
            });
          } else {
            app.fire('login');
            onSuccess && onSuccess(data);
          }
        });
      }}
    >
      <Form.Item
        name="username"
        rules={[{ required: true, message: app.fire('i18n', 'required') }]}
      >
        <Input
          placeholder={app.fire('i18n', 'name_placeholder')}
          prefix={<UserOutlined />}
        />
      </Form.Item>
      <Form.Item
        name="password"
        rules={[{ required: true, message: app.fire('i18n', 'required') }]}
      >
        <Input
          type="password"
          placeholder={app.fire('i18n', 'password_placeholder')}
          prefix={<LockOutlined />}
        />
      </Form.Item>
      <Form.Item>
        <div className="login-extra">
          <a onClick={() => onChange('register')}>
            {app.fire('i18n', 'register_account')}
          </a>
          <Button
            type="primary"
            htmlType="submit"
            loading={loading}
          >
            {app.fire('i18n', 'login')}
          </Button>
        </div>
      </Form.Item>
    </Form>
  );
}
