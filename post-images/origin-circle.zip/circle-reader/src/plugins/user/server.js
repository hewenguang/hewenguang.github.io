App.register('user', ['utils', 'fetch', 'database'], function(utils, fetch){
  const app = this;  
  const url = function(entity, action, random){
    const path = app.to(`api/${entity}/${action}.json`);
    return random ? `${path}?t=${+new Date}` : path;
  };
  const cache_user = function(user, expire){
    const cacheUser = {
      expire,
      id:user.uid,
      name:user.name,
    };
    // 会员判断
    let member = false;
    utils.each(user.roles, function(role){
      if(role === 'member'){
        member = true;
        return true;
      }
    });
    cacheUser.member = member;
    // 配置信息
    let config = '';
    if(user.field_config && user.field_config.und && utils.isArray(user.field_config.und) && user.field_config.und.length === 1){
      config = user.field_config.und[0].value;
    }
    config && (cacheUser.config = utils.isString(config) ? JSON.parse(config) : config);
    // 配置同步时间
    let changed = 0;
    if(user.field_changed && user.field_changed.und && utils.isArray(user.field_changed.und) && user.field_changed.und.length === 1){
      changed = user.field_changed.und[0].value;
    }
    changed && (cacheUser.changed = utils.isString(changed) ? parseInt(changed) : changed);
    return cacheUser;
  };
  // 401 token 失败
  app.on('fetch_401', function(){
    app.fire('user_clean', function(){
      app.fire('send', 'login');
    });
  });
  // 拒绝访问，注销
  app.on('fetch_403', function(){
    app.fire('user_clean', function(){
      app.fire('send', 'login');
    });
  });
  app.on('expire', function(callback){
    const expire = app.cache('expire');
    if(expire){
      callback && callback(null, expire);
    } else {
      fetch(url('current','expire', true)).then(function(result){
        if(utils.isArray(result) && result.length === 1){
          app.cache('expire', result[0].expire);
          callback && callback(null, result[0].expire);
        } else {
          callback && callback('expire api error');
        }
      }).catch(function(error){
        app.cache('expire', null);
        callback && callback(error.message);
      });
    }
  });
  app.on('token', function(callback){
    const token = app.cache('token');
    if(token){
      callback && callback(null, token);
    } else {
      fetch(url('user','token'), {method: 'POST'}).then(function(result){
        app.cache('token', result.token);
        callback && callback(null, result.token);
      }).catch(function(error){
        app.cache('token', null);
        callback && callback(error.message);
      });
    }
  });
  app.on('user_id', function(callback){
    app.fire('storage', {
      request:{
        execute: 'get',
        name: 'user_id',
      },
      callback: function(error, data){
        if(error){
          callback && callback(error);
        } else {
          if(data){
            callback && callback(null, data);
          } else {
            app.fire('token', function(error, token){
              if(error){
                callback && callback(error);
              } else {
                fetch(url('system','connect'), {
                  method: 'POST',
                  headers: {
                    'X-CSRF-Token': token,
                    'Content-Type': 'application/json',
                  },
                }).then(function(connect){
                  const user = connect.user;
                  if(!user || !user.uid){
                    app.cache('token', null);
                    callback && callback(app.fire('i18n', 'please_login'));
                  } else {
                    app.fire('storage', {
                      request:{
                        execute: 'add',
                        name: 'user_id',
                        value: user.uid,
                      },
                      callback: function(error){
                        if(error){
                          callback && callback(error);
                        } else {
                          callback && callback(null, user.uid);
                        }
                      },
                    });
                  }
                }).catch(function(error){
                  callback && callback(error.message);
                });
              }
            });
          }
        }
      },
    });
  });
  app.on('user', function({callback} = {}){
    callback && callback(null, app.cache('user'));
  });
  app.on('user_config', function(data, callback){
    const user = app.cache('user');
    if(!user || !user.id){
      callback && callback(app.fire('i18n', 'please_login'));
      return;
    }
    app.fire('token', function(error, token){
      if(error){
        callback && callback(error);
        return;
      }
      const config = data.config;
      const changed = data.changed;
      fetch(url('user', user.id), {
        method: 'PUT',
        headers: {
          'X-CSRF-Token': token,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          field_changed: {
            und:[{value:changed}],
          },
          field_config:{
            und:[{value:JSON.stringify(config)}],
          },
        }),
      }).then(function(){
        app.cache('user', {config,changed});
        callback && callback(null, config);
      }).catch(function(error){
        callback && callback(error.message);
      });
    });
  });
  app.on('retrieve', function({callback} = {}){
    const user = app.cache('user');
    if(user){
      callback && callback(null, user);
      return;
    }
    app.fire('user_id', function(error, uid){
      if(error){
        callback && callback(error);
        return;
      }
      fetch(url('user', uid, true)).then(function(user){
        app.fire('expire', function(error, expire){
          if(error){
            callback && callback(error);
            return;
          }
          const cacheUser = cache_user(user, expire);
          app.cache('user', cacheUser);
          callback && callback(null, cacheUser);
        });
      }).catch(function(error){
        callback && callback(error.message);
      });
    });
  });
  app.on('regcode', function({request, callback} = {}){
    const regcode_code = request.regcode;
    if(!regcode_code){
      callback && callback(app.fire('i18n', 'required'));
      return;
    }
    const user = app.cache('user');
    if(!user || !user.id){
      callback && callback(app.fire('i18n', 'please_login'));
      return;
    }
    app.fire('token', function(error, token){
      if(error){
        callback && callback(error);
      } else {
        fetch(url('user', user.id), {
          method: 'PUT',
          headers: {
            'X-CSRF-Token': token,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            regcode_code,
          }),
        }).then(function(){
          // 清空现有用户更新过期时间
          app.cache('user', null);
          app.fire('retrieve', {callback});
        }).catch(function(error){
          callback && callback(error.message);
        });
      }
    });
  });
  app.on('loginout', function({callback} = {}){
    app.fire('token', function(error, token){
      if(error){
        callback && callback(error);
      } else {
        fetch(url('user', 'logout'), {
          method: 'POST',
          headers: {
            'X-CSRF-Token': token,
            'Content-Type': 'application/json',
          },
        }).then(function(){
          app.fire('user_clean', callback);
        }).catch(function(error){
          callback && callback(error.message);
          app.fire('user_clean', function(){
            app.fire('send', 'login');
          });
        });
      }
    });
  });
  app.on('user_clean', function(callback){
    app.cache('token', null);
    app.cache('user', null);
    app.cache('expire', null);
    app.fire('storage', {
      callback,
      request:{
        name: 'user_id',
        execute: 'remove',
      },
    });
  });
  // 安装、更新、重启时拉取用户信息
  utils.wait(function(){
    app.fire('user_clean', function(){
      app.fire('retrieve');
    });
  });
});
