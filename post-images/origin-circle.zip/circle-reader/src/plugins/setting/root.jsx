import React, { useState, useEffect } from 'react';
import { ConfigProvider } from 'antd';
import { AppContext } from 'app/context';
import zhCN from 'antd/lib/locale/zh_CN';
import enGB from 'antd/lib/locale/en_GB';
import Drawer from 'app/components/drawer';
import Entry from './entry';

export default function(props){
  const { app } = props;
  const [ root, setRoot ] = useState(null);
  const [ visible, setVisible ] = useState(true);

  useEffect(() => {
    app.cache('module_wrench') && app.fire('wrench', false);
  }, []);

  useEffect(() => {
    const hook = app.on('setting', function(hidden){
      const nextVisible = !utils.isUndefined(hidden) ? hidden : !visible;
      nextVisible && app.cache('module_wrench') && app.fire('wrench', false);
      setVisible(nextVisible);
    });
    return () => {
      app.remove(hook);
    };
  }, [ visible ]);

  // 退出时需要恢复修改因跟随系统预览导致的主题错误
  useEffect(() => {
    !visible && app.fire('render-theme');
  }, [ visible ]);

  useEffect(() => {
    app.fire('insert-style', `
      .setting{
        padding-right: 300px;
      }
    `, true);
  }, []);

  useEffect(() => {
    const rootElement = app.fire('dom-root');
    if(!rootElement){
      return;
    }
    if(visible){
      rootElement.classList.add('setting');
    } else {
      rootElement.classList.remove('setting');
    }
  }, [ visible ]);

  return (
    <AppContext.Provider value={app}>
      <ConfigProvider
        componentSize="small"
        getPopupContainer={() => root}
        locale={app.i18n.getUILanguage() === 'zh-CN' ? zhCN : enGB}
      >
        <Drawer
          visible={visible}
          className="setting"
          onClose={() => setVisible(false)}
          getRoot={target => setRoot(target)}
        >
          <Entry />
        </Drawer>
      </ConfigProvider>
    </AppContext.Provider>
  );
}
