import React from 'react';
import Colorlist from '../colorlist';
import ColorInput from '../colorinput';

export default function(props){
  const { field, value, data, disabled, onChange } = props;
  const solidValue = utils.isString(value) && value.startsWith('#') ? value : '';

  return (
    <Colorlist
      data={data}
      borderBottom
      value={solidValue}
      disabled={disabled}
      extra={
        <ColorInput
          value={solidValue}
          disabled={disabled}
          onChange={color => {
            onChange && onChange(color, field);
          }}
        />
      }
      onChange={color => {
        onChange && onChange(color, field);
      }}
    />
  );
}
