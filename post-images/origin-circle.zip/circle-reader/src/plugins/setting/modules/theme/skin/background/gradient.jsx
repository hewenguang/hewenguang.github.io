import React from 'react';
import Custom from './custom';
import { parser, format } from './utils';
import Colorlist from '../colorlist';
import useOption from 'app/context/useOption';
import './gradient.less';

export default function(props){
  const { field, preset, value, data, disabled, onChange } = props;
  const [ option, optionChange ] = useOption({
    field: preset,
    defaultValue: data[0].name,
  });

  return (
    <>
      <Colorlist
        data={data}
        borderBottom
        disabled={disabled}
        value={utils.isString(value) && value.startsWith('linear-gradient') ? option : ''}
        onChange={(name, value) => {
          optionChange(name);
          value && onChange && onChange(value, field);
        }}
      />
      {option === 'custom' && (
        <Custom
          data={parser(value)}
          disabled={disabled}
          onChange={color => {
            onChange && onChange(format(color), field);
          }}
        />
      )}
    </>
  );
}

