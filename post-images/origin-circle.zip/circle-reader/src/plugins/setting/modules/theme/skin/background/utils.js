export function parser(color){
  if(!utils.isString(color)){
    return {
      angle: '0deg',
      start: '#ffffff',
      end: '#ffffff',
    };
  }

  const [
    angle = '0deg',
    start = '#ffffff',
    end = '#ffffff',
  ] = color.replace(/linear-gradient\((.*?)\)/, '$1')
      .split(',')
      .map(item => item.trim().split(' ').shift());

  return {
    angle,
    start,
    end,
  };
}

export function format(color){
  if(!utils.isPlainObject(color)){
    return color;
  }
  return `linear-gradient(${color.angle}, ${color.start} 0%, ${color.end} 100%)`;
}
