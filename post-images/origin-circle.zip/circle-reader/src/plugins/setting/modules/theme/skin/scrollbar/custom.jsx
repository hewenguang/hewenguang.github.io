import React from 'react';
import List from 'app/components/list';
import ColorInput from '../colorinput';
import Slider from 'app/components/slider';
import useTheme from 'plugin/setting/context/useTheme';

export default function(props){
  const { data, disabled, onChange } = props;
  const theme = useTheme();

  return (
    <>
      <List
        borderBottom
        data={theme.scrollbar.color}
        renderItem={item => (
          <ColorInput
            disabled={disabled}
            value={data[item.field]}
            onChange={value => {
              onChange(value, item.field);
            }}
          />
        )}
      />
      <List
        borderBottom
        className="slider-wrapper"
        data={[theme.scrollbar.radius]}
      >
        {item => (
          <Slider
            {...item}
            disabled={disabled}
            value={data[item.field]}
            onChange={value => {
              onChange(value, item.field);
            }}
          />
        )}
      </List>
    </>
  );
}
