import React from 'react';
import ColorInput from './colorinput';
import Scrollbar from './scrollbar';
import Backgroud from './background';
import List from 'app/components/list';
import useTheme from 'plugin/setting/context/useTheme';

export default function(props){
  const { data, disabled, onChange } = props;
  const theme = useTheme();

  return (
    <>
      <List
        borderBottom
        data={theme.color.data}
        itemLayout="horizontal"
        renderItem={item => (
          <ColorInput
            disabled={disabled}
            value={data[item.field]}
            onChange={value => {
              if(item.onChange){
                item.onChange(value) && onChange(value, item.field);
              } else {
                onChange(value, item.field);
              }
            }}
          />
        )}
      />
      <Backgroud
        disabled={disabled}
        onChange={onChange}
        value={data[theme.bg.field]}
      />
      <Scrollbar
        data={data}
        disabled={disabled}
        onChange={onChange}
      />
    </>
  );
}
