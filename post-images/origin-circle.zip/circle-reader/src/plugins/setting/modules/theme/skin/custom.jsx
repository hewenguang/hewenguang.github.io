import React from 'react';
import Scrollbar from './scrollbar';
import Backgroud from './background';
import ColorInput from './colorinput';
import List from 'app/components/list';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import { authorize } from 'app/components/authorize';
import useTheme from 'plugin/setting/context/useTheme';

export default function(props){
  const { data, disabled, onChange } = props;
  const app = useApp();
  const user = useUser();
  const theme = useTheme();

  return (
    <>
      <List
        borderBottom
        data={theme.color.data}
        itemLayout="horizontal"
        renderItem={item => (
          <ColorInput
            disabled={disabled}
            value={data[item.field]}
            onAuthorize={() => user.member || authorize(item.field)}
            onChange={value => {
              if(item.onChange){
                item.onChange(value) && onChange(value, item.field);
              } else {
                onChange(value, item.field);
              }
              app.fire('send', 'analytics', {event:`theme-custom-${item.field}`});
            }}
          />
        )}
      />
      <Backgroud
        disabled={disabled}
        value={data[theme.bg.field]}
        authorized={user.member || authorize(theme.bg.field)}
        onChange={(value, name) => {
          if(user.member || authorize(theme.bg.field)){
            onChange(value, name);
            app.fire('send', 'analytics', {event:theme.bg.field});
          } else {
            app.fire('upgrade');
            app.fire('send', 'analytics', {event:`upgrade-${theme.bg.field}`});
          }
        }}
      />
      <Scrollbar
        data={data}
        disabled={disabled}
        authorized={user.member || authorize(theme.scrollbar.field)}
        onChange={(value, name) => {
          if(user.member || authorize(theme.scrollbar.field)){
            onChange(value, name);
            app.fire('send', 'analytics', {event:theme.scrollbar.field});
          } else {
            app.fire('upgrade');
            app.fire('send', 'analytics', {event:`upgrade-${theme.scrollbar.field}`});
          }
        }}
      />
    </>
  );
}
