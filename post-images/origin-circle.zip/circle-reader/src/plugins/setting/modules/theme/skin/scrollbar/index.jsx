import React from 'react';
import Custom from './custom';
import Colorlist from '../colorlist';
import List from 'app/components/list';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import useOption from 'app/context/useOption';
import { authorize } from 'app/components/authorize';
import useTheme from 'plugin/setting/context/useTheme';

export default function(props){
  const { data, disabled, onChange } = props;
  const app = useApp();
  const user = useUser();
  const theme = useTheme();
  const datasource = theme.scrollbar.data;
  const [ option, optionChange ] = useOption({
    table: 'wrench',
    field: theme.scrollbar.field,
    defaultValue: datasource[0].name,
  });

  return (
    <>
      <List
        itemStyle={{paddingBottom:0}}
        data={[theme.scrollbar.title]}
      />
      <Colorlist
        borderBottom
        value={option}
        data={datasource}
        disabled={disabled}
        onChange={(name, value) => {
          if(user.member || authorize(theme.scrollbar.title.field)){
            optionChange(name);
            onChange(value);
          } else {
            app.fire('upgrade', 'upgrade');
          }
        }}
      />
      {option === 'custom' && (
        <Custom
          data={data}
          disabled={disabled}
          onChange={(value, name) => {
            if(user.member || authorize(theme.scrollbar.title.field)){
              onChange(value, name);
            } else {
              app.fire('upgrade', 'upgrade');
            }
          }}
        />
      )}
    </>
  );
}
