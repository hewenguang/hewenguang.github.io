import React from 'react';
import Custom from './custom';
import Colorlist from '../colorlist';
import Title from 'app/components/title';
import useApp from 'app/context/useApp';
import useOption from 'app/context/useOption';
import useTheme from 'plugin/setting/context/useTheme';

export default function(props){
  const { data, disabled, authorized, onChange } = props;
  const app = useApp();
  const theme = useTheme();
  const datasource = theme.scrollbar.data;
  const [ option, optionChange ] = useOption({
    table: 'wrench',
    field: theme.scrollbar.field,
    defaultValue: datasource[0].name,
  });

  return (
    <>
      <div className="header">          
        <Title
          vip={!authorized}
          label={theme.scrollbar.label}
        />
      </div>
      <Colorlist
        borderBottom
        value={option}
        data={datasource}
        disabled={disabled}
        onChange={(name, value) => {
          if(authorized){
            optionChange(name);
            onChange(value);
          } else {
            app.fire('upgrade');
          }
        }}
      />
      {option === 'custom' && (
        <Custom
          data={data}
          disabled={disabled}
          onChange={onChange}
        />
      )}
    </>
  );
}
