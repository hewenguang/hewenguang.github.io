import React from 'react';
import ColorInput from '../colorinput';
import List from 'app/components/list';
import Slider from 'app/components/slider';
import useTheme from 'plugin/setting/context/useTheme';

export default function(props){
  const { data, disabled, onChange } = props;
  const theme = useTheme();

  return (
    <>
      <List
        borderBottom
        data={theme.gradient.color}
        renderItem={item => (
          <ColorInput
            disabled={disabled}
            value={data[item.field]}
            onChange={value => {
              data[item.field] = value;
              onChange && onChange(data);
            }}
          />
        )}
      />
       <List
        borderBottom
        className="slider-wrapper"
        data={[theme.gradient.angle]}
      >
        {item => (
          <Slider
            {...item}
            disabled={disabled}
            value={data[item.field]}
            onChange={value => {
              data[item.field] = value;
              onChange && onChange(data);
            }}
          />
        )}
      </List>
    </>
  );
}
