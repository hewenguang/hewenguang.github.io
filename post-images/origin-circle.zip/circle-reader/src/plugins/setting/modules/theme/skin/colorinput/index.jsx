import cx from 'classnames';
import { Input, Popover } from 'antd';
import { ChromePicker } from 'react-color'
import React, { useState, useEffect } from 'react';
import './index.less';

export default function(props){
  const { value, disabled, onChange } = props;
  const [ color, setColor ] = useState(value);

  useEffect(() => {
    setColor(value);
  }, [ value ]);

  return (
    <Input
      value={color}
      disabled={disabled}
      className="color-input"
      onChange={event => onChange(event.target.value)}
      suffix={
        <Popover
          placement="topLeft"
          overlayClassName="color-input-popover"
          content={disabled ? null : (
            <ChromePicker
              disableAlpha={true}
              color={/(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(color) ? color : undefined}
              onChange={color => {
                setColor(color.hex);
              }}
              onChangeComplete={color => {
                onChange && onChange(color.hex);
              }}
            />
          )}
        >
          <div
            style={{backgroundColor:color}}
            className={cx('colorpicker-trigger', { disabled })}
          />
        </Popover>
      }
    />
  );
}
