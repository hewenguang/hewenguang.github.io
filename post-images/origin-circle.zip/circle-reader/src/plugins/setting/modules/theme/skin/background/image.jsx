import React from 'react';
import cx from 'classnames';
import List from '../../../../../../components/list';
// import Upload from '../../../components/upload';
import useOption from '../../../../context/useOption';
import './image.less';

export default function(props){
  const { data, field } = props;
  const [ value, onChange ] = useOption({
    field,
    defaultValue:'',
  });

  return (
    <List borderBottom>
      <List.Item className="image-list">
        {data.map(url => (
          <div
            onClick={() => onChange(`url("${url}")`)}
            style={{backgroundImage:`url("${url}")`}}
            className={cx('image-item', {
              active: value === `url("${url}")`,
            })}
          />
        ))}
        {/* <Upload text="自定义" /> */}
      </List.Item>
    </List>
  );
}
