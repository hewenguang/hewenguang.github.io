import { Upload } from 'antd';
import Icon from 'app/components/icon';
import React, { useState } from 'react';
import useApp from 'app/context/useApp';
import './image.less';

export default function(props){
  const { field, value, disabled, onChange } = props;
  const app = useApp();
  const [ loading, setLoading ] = useState(false);
  const image = utils.isString(value) && !value.startsWith('#') && !value.startsWith('linear') ? value : '';

  return (
    <div className="upload-container">
      <Upload
        name="avatar"
        maxCount={1}
        accept="image/*"
        multiple={false}
        disabled={disabled}
        showUploadList={false}
        beforeUpload={() => false}
        listType="picture-card"
        className="avatar-uploader"
        onChange={(info) => {
          const file = info.file;
          if(file.size > 2 * 1024 * 1024){
            app.fire('message', {
              type: 'error',
              key: 'image_limit',
              message: app.fire('i18n', 'image_limit'),
            });
            return;
          }
          const reader = new FileReader();
          setLoading(true);
          reader.addEventListener('load', function(){
            onChange && onChange(this.result, field);
            setLoading(false);
          });
          reader.readAsDataURL(file);
        }}
      >
        {image ? (
          <div
            className="upload-image"
            style={{background:`center/cover no-repeat url("${image}")`}}
          />
        ) : (
          <Icon
            name={loading ? 'loading' : 'upload'}
          />
        )}
      </Upload>
    </div>
  );
}
