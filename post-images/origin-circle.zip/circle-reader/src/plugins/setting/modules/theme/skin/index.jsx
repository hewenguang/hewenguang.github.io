import React from 'react';
import Custom from './custom';
import Colorlist from './colorlist';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import useOption from 'app/context/useOption';
import { authorize } from 'app/components/authorize';
import useTheme from 'plugin/setting/context/useTheme';
import useSetting from 'plugin/setting/context/useSetting';

export default function(props){
  const { field, disabled, defaultActiveFirst = true } = props;
  const app = useApp();
  const user = useUser();
  const theme = useTheme();
  const datasource = theme.data;
  const [ option, optionChange ] = useOption({
    field,
    defaultValue: defaultActiveFirst ? datasource[0].name : '',
  });
  const [ themeValue, themeValueChange ] = useSetting({
    field,
    defaultValue: datasource[0].value,
  });

  return (
    <>
      <Colorlist
        text="A"
        borderBottom
        value={option}
        data={datasource}
        disabled={disabled}
        onChange={(name, value) => {
          if(user.member || authorize(name)){
            optionChange(name);
            value && themeValueChange(value);
          } else {
            app.fire('upgrade', 'upgrade');
          }
        }}
      />
      {option === 'custom' && (
        <Custom
          data={themeValue}
          disabled={disabled}
          onChange={themeValueChange}
        />
      )}
    </>
  );
}
