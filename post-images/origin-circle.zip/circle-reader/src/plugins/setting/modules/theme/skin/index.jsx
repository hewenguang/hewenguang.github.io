import React from 'react';
import Custom from './custom';
import Colorlist from './colorlist';
import useApp from 'app/context/useApp';
import useOption from 'app/context/useOption';
import useTheme from 'plugin/setting/context/useTheme';
import useSetting from 'plugin/setting/context/useSetting';

export default function(props){
  const { field, disabled, defaultActiveFirst = true } = props;
  const app = useApp();
  const theme = useTheme();
  const datasource = theme.data;
  const [ option, optionChange ] = useOption({
    field,
    defaultValue: defaultActiveFirst ? datasource[0].name : '',
  });
  const [ themeValue, themeValueChange ] = useSetting({
    field,
    defaultValue: datasource[0].value,
  });

  return (
    <>
      <Colorlist
        text="A"
        borderBottom
        value={option}
        data={datasource}
        disabled={disabled}
        onChange={(name, value) => {
          optionChange(name);
          value && themeValueChange(value);
          app.fire('send', 'analytics', {event:`theme-${name}`});
        }}
      />
      {option === 'custom' && (
        <Custom
          data={themeValue}
          disabled={disabled}
          onChange={themeValueChange}
        />
      )}
    </>
  );
}
