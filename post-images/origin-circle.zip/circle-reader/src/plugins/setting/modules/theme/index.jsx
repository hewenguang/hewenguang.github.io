import React from 'react';
import Skin from './skin';
import Night from './night';
import useOption from 'app/context/useOption';
import useTheme from 'plugin/setting/context/useTheme';

export default function(){
  const theme = useTheme();
  const [ enable, setEnable ] = useOption(theme.night);

  return (
    <>
      <Skin
        disabled={enable}
        field={theme.field}
      />
      <Night
        enable={enable}
        setEnable={setEnable}
      />
    </>
  );
}
