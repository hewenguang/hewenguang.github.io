import React from 'react';
import Skin from './skin';
import { Switch } from 'antd';
import Title from 'app/components/title';
import Tabs from 'plugin/setting/components/tabs';
import useTheme from 'plugin/setting/context/useTheme';

export default function(props){
  const { enable, setEnable } = props;
  const theme = useTheme();

  return (
    <Tabs
      pure
      disabled={!enable}
      extra={
        <>
          <Title {...theme.night} />
          <Switch
            checked={enable}
            onChange={setEnable}
            style={{marginLeft:10}}
          />
        </>
      }
      data={[{
        key: theme.light.field,
        tab: theme.light.label,
        value: (
          <Skin
            disabled={!enable}
            field={theme.light.field}
            defaultActiveFirst={false}
          />
        ),
      },{
        key: theme.dark.field,
        tab: theme.dark.label,
        value: (
          <Skin
            disabled={!enable}
            field={theme.dark.field}
            defaultActiveFirst={false}
          />
        ),
      }]}
    />
  );
}
