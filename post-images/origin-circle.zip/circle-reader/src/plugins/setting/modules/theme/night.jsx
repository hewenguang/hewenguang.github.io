import Skin from './skin';
import { Switch } from 'antd';
import useApp from 'app/context/useApp';
import Title from 'app/components/title';
import Tabs from 'plugin/setting/components/tabs';
import React, { useState, useEffect } from 'react';
import useTheme from 'plugin/setting/context/useTheme';

export default function(props){
  const { enable, setEnable } = props;
  const app = useApp();
  const theme = useTheme();
  const [ activeKey, setActiveKey ] = useState(theme.light.field);

  useEffect(() => {
    enable && setActiveKey(app.fire('color-scheme'));
    app.fire('setting-theme');
  }, [ enable ]);

  useEffect(() => {
    enable && activeKey && app.fire('setting-theme', activeKey);
  }, [ activeKey, enable ]);

  return (
    <Tabs
      pure
      disabled={!enable}
      activeKey={activeKey}
      onChange={setActiveKey}
      extra={
        <>
          <Title {...theme.night} />
          <Switch
            checked={!!enable}
            style={{marginLeft:10}}
            onChange={checked => {
              setEnable(checked);
              app.fire('send', 'analytics', {event:`theme-night-${checked}`});
            }}
          />
        </>
      }
      data={[{
        key: theme.light.field,
        tab: theme.light.label,
        value: (
          <Skin
            disabled={!enable}
            field={theme.light.field}
            defaultActiveFirst={false}
          />
        ),
      },{
        key: theme.dark.field,
        tab: theme.dark.label,
        value: (
          <Skin
            disabled={!enable}
            field={theme.dark.field}
            defaultActiveFirst={false}
          />
        ),
      }]}
    />
  );
}
