import React from 'react';
import Solid from './solid';
// import Image from './image';
import Gradient from './gradient';
import Title from 'app/components/title';
import useOption from 'app/context/useOption';
import Tabs from 'plugin/setting/components/tabs';
import useTheme from 'plugin/setting/context/useTheme';
import './index.less';

export default function(props){
  const { value, disabled, onChange } = props;
  const theme = useTheme();
  const [ activeKey, setActiveKey ] = useOption({
    field: theme.bg.field,
    defaultValue:'solid',
  });

  return (
    <Tabs
      pure
      disabled={disabled}
      activeKey={activeKey}
      onChange={setActiveKey}
      className="background"
      extra={<Title label={theme.bg.label} />}
      data={[{
        key: theme.solid.field,
        tab: theme.solid.label,
        value: (
          <Solid
            value={value}
            onChange={onChange}
            disabled={disabled}
            data={theme.solid.data}
            field={theme.bg.field}
          />
        ),
      },{
        key: theme.gradient.field,
        tab: theme.gradient.label,
        value: (
          <Gradient
            value={value}
            onChange={onChange}
            disabled={disabled}
            field={theme.bg.field}
            data={theme.gradient.data}
            preset={theme.gradient.field}
          />
        ),
      },
      // {
      //   key: 'image',
      //   tab: '图片 💎',
      //   value: (
      //     <div
      //       field="img"
      //       data={[
      //         'https://static001.infoq.cn/resource/image/0d/a2/0d5c7803d2080ebb310a7abedb16dfa2.png',
      //         'https://tpc.googlesyndication.com/simgad/6677998836734813751?sqp=4sqPyQQ7QjkqNxABHQAAtEIgASgBMAk4A0DwkwlYAWBfcAKAAQGIAQGdAQAAgD-oAQGwAYCt4gS4AV_FAS2ynT4&rs=AOga4qlk_bEfcVHMle2SYhs2vOzBUouO7w',
      //       ]}
      //     />
      //   ),
      // }
    ]}
    />
  );
}
