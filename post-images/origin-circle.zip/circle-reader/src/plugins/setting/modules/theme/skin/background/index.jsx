import React from 'react';
import Solid from './solid';
import Image from './image';
import Gradient from './gradient';
import Title from 'app/components/title';
import useApp from 'app/context/useApp';
import useOption from 'app/context/useOption';
import Tabs from 'plugin/setting/components/tabs';
import useTheme from 'plugin/setting/context/useTheme';

export default function(props){
  const { value, disabled, authorized, onChange } = props;
  const app = useApp();
  const theme = useTheme();
  const [ activeKey, setActiveKey ] = useOption({
    field: theme.bg.field,
    defaultValue:'solid',
  });

  return (
    <Tabs
      pure
      disabled={disabled}
      activeKey={activeKey}
      onChange={val => {
        if(authorized){
          setActiveKey(val);
        } else {
          app.fire('upgrade');
        }
      }}
      extra={
        <Title
          vip={!authorized}
          label={theme.bg.label}
        />
      }
      data={[{
        key: theme.solid.field,
        tab: theme.solid.label,
        value: (
          <Solid
            value={value}
            onChange={onChange}
            disabled={disabled}
            data={theme.solid.data}
            field={theme.bg.field}
          />
        ),
      },{
        key: theme.gradient.field,
        tab: theme.gradient.label,
        value: (
          <Gradient
            value={value}
            onChange={onChange}
            disabled={disabled}
            field={theme.bg.field}
            data={theme.gradient.data}
            preset={theme.gradient.field}
          />
        ),
      },
      {
        key: theme.image.field,
        tab: theme.image.label,
        value: (
          <Image
            value={value}
            onChange={onChange}
            disabled={disabled}
            field={theme.bg.field}
          />
        ),
      }
    ]}
    />
  );
}
