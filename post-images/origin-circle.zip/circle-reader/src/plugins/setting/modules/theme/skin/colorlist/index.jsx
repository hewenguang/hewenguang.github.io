import React from 'react';
import cx from 'classnames';
import { Row, Col } from 'antd';
import Icon from 'app/components/icon';
import List from 'app/components/list';
import './index.less';

export default function(props){
  const { text, extra, data = [], disabled, value, onChange, className, ...resetProps } = props;

  return (
    <List
      {...resetProps}
      className={cx('color-list', className, {
        disabled,
      })}
      data={[{
        value: (
          <Row>
            {data.map((item, index) => (
              <Col
                span={3}
                key={index}
                tabIndex={0}
                style={item.style}
                className={cx({
                  active: item.name === value,
                  custom: item.name === 'custom',
                })}
                onKeyPress={event => {
                  if(event.key !== 'Enter'){
                    return;
                  }
                  !disabled && onChange(item.name, item.value);
                }}
                onClick={() => {
                  !disabled && onChange(item.name, item.value);
                }}
              >
                {item.name === 'custom' ? (
                  <Icon
                    name="custom"
                    className="custom-icon"
                  />
                ) : text}
              </Col>
            ))}
            {extra && (
              <div
                key="extra"
                className="extra"
              >
                {extra}
              </div>
            )}
          </Row>
        )
      }]}
    >
      {item => item.value}
    </List>
  );
}
