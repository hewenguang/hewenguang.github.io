import React from 'react';
import cx from 'classnames';
import { Row, Col } from 'antd';
import Icon, { CheckCircleFilled } from '@ant-design/icons';
import List from 'app/components/list';
import useUser from 'app/context/useUser';
import { authorize } from 'app/components/authorize';
import './index.less';

export default function(props){
  const {
    text, extra, data = [], disabled,
    value, onChange, className, ...resetProps
  } = props;
  const user = useUser();

  return (
    <List
      {...resetProps}
      data={[{
        value: (
          <Row>
            {data.map((item, index) => (
              <Col
                span={3}
                key={index}
                style={item.style}
                className={cx({custom: item.name === 'custom'})}
                onClick={() => {
                  if(disabled){
                    return;
                  }
                  onChange(item.name, item.value);
                }}
              >
                {item.name === value && <CheckCircleFilled />}
                {!user.member && !authorize(item.name) && (
                  <span className="vip-icon">💎</span>
                )}
                {item.name === 'custom' ? (
                  <Icon
                    className="custom-icon"
                    component={() => (
                      <svg viewBox="0 0 24 24" width="1em" height="1em" fill="currentColor">
                        <path d="M20.71 5.63l-2.34-2.34a.996.996 0 0 0-1.41 0l-3.12 3.12-1.93-1.91-1.41 1.41 1.42 1.42L3 16.25V21h4.75l8.92-8.92 1.42 1.42 1.41-1.41-1.92-1.92 3.12-3.12a1 1 0 0 0 .01-1.42zM6.92 19L5 17.08l8.06-8.06 1.92 1.92L6.92 19z" />
                      </svg>
                    )}
                  />
                ) : text}
              </Col>
            ))}
            {extra && (
              <div
                key="extra"
                className="extra"
              >
                {extra}
              </div>
            )}
          </Row>
        )
      }]}
      className={cx('color-list', className, {
        disabled,
      })}
    >
      {item => item.value}
    </List>
  );
}
