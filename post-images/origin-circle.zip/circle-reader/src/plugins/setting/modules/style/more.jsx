import React, { useState } from 'react';
import List from 'app/components/list';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import { authorize } from 'app/components/authorize';
import Slider from 'plugin/setting/components/slider';
import useStyle from 'plugin/setting/context/useStyle';

export default function(props){
  const { data, onChange } = props;
  const app = useApp();
  const user = useUser();
  const style = useStyle();
  const [ visible, setVisible ] = useState(false);
  const authorized = authorize('style-more');

  return visible ? (
    <List
      borderNone
      borderBottom
      className="style-slider"
      style={{marginTop: 12}}
      data={[
        style.data.title1, style.data.title2, style.data.title3,
        style.data.title4, style.data.title5, style.data.title6,
      ]}
    >
      {item => (
        <Slider
          {...item}
          value={data[item.field]}
          onChange={value => {
            onChange(value, item.field);
          }}
        />
      )}
    </List>
  ) : (
    <div
      className="style-more"
      onClick={() => {
        if(user.member || authorized){
          setVisible(true);
        } else {
          app.fire('upgrade', 'upgrade');
        }
      }}
    >
      {style.more}{!user.member && !authorized && ' 💎'}
    </div>
  );
}
