import React, { useState } from 'react';
import useApp from 'app/context/useApp';
import Icon from 'app/components/icon';
import Header from './header';

export default function(props){
  const app = useApp();
  const [ visible, setVisible ] = useState(false);

  return visible ? <Header {...props} /> : (
    <div
      className="style-more"
      onClick={() => {
        setVisible(true);
        app.fire('send', 'analytics', {event:'style-more'});
      }}
    >
      {app.fire('i18n', 'more')}<Icon name="down" />
    </div>
  );
}
