import React from 'react';
import List from 'app/components/list';
import useApp from 'app/context/useApp';
import Title from 'app/components/title';
import useUser from 'app/context/useUser';
import Slider from 'app/components/slider';
import { authorize } from 'app/components/authorize';
import useStyle from 'plugin/setting/context/useStyle';

export default function(props){
  const { data, onChange } = props;
  const app = useApp();
  const user = useUser();
  const style = useStyle();

  return (
    <List
      borderNone
      borderBottom
      className="style-slider"
      style={{padding:'10px 0'}}
      data={['title1', 'title2', 'title3', 'title4', 'title5', 'title6'].reduce((accumulator, item) => accumulator.concat([style.data[`${item}header`], style.data[item], style.data[`${item}weight`]]),[])}
    >
      {function(item){
        const authorized = user.member || authorize(item.field);

        return item.field ? (
          <Slider
            {...item}
            vip={!authorized}
            value={data[item.field]}
            onAuthorize={() => authorized}
            onChange={value => {
              if(authorized){
                onChange(value, item.field);
                app.fire('send', 'analytics', {event:`style-${item.field}`});
              } else {
                app.fire('upgrade');
                app.fire('send', 'analytics', {event:`style-upgrade-${item.field}`});
              }
            }}
          />
        ) : (
          <div className="style-title">
            <Title label={item.label} />
          </div>
        );
      }}
    </List>
  );
}
