import React from 'react';
import More from './more';
import { Switch } from 'antd';
import List from 'app/components/list';
import Align from 'plugin/setting/components/align';
import Select from 'plugin/setting/components/select';
import Slider from 'plugin/setting/components/slider';
import useStyle from 'plugin/setting/context/useStyle';
import useSetting from 'plugin/setting/context/useSetting';
import './index.less';

export default function(){
  const style = useStyle();
  const [ styleValue, styleValueChange ] = useSetting({
    defaultValue: {},
    field: style.field,
  });
  
  return (
    <>
      <List
        data={[style.data.font]}
        renderItem={item => (
          <Select
            {...item}
            width={160}
            value={styleValue[item.field]}
            onChange={value => {
              styleValueChange(value, item.field);
            }}
          />
        )}
      />
      <List
        borderNone
        className="style-slider"
        data={[
          style.data.size, style.data.width, style.data.space,
          style.data.lineheight, style.data.weight, style.data.blockspace, style.data.indent
        ]}
      >
        {item => (
          <Slider
            {...item}
            value={styleValue[item.field]}
            onChange={value => {
              styleValueChange(value, item.field);
            }}
          />
        )}
      </List>
      <List
        borderTop
        borderBottom
        className="style-align"
        data={[style.data.titlealign, style.data.align, style.data.imagealign]}
        renderItem={item => (
          <Align
            {...item}
            value={styleValue[item.field]}
            onChange={value => {
              styleValueChange(value, item.field);
            }}
          />
        )}
      />
      <List
        borderBottom
        data={[style.data.imagehide]}
        renderItem={item => (
          <Switch
            {...item}
            checked={styleValue[item.field] === item.checked}
            onChange={checked => {
              styleValueChange(checked ? item.checked : item.unchecked, item.field);
            }}
          />
        )}
      />
      <More
        data={styleValue}
        onChange={styleValueChange}
      />
    </>
  );
}
