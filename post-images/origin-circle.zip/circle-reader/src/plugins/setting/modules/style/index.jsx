import React from 'react';
import More from './more';
import { Switch } from 'antd';
import List from 'app/components/list';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import Slider from 'app/components/slider';
import Align from 'plugin/setting/components/align';
import { authorize } from 'app/components/authorize';
import Select from 'plugin/setting/components/select';
import useStyle from 'plugin/setting/context/useStyle';
import useSetting from 'plugin/setting/context/useSetting';
import './index.less';

export default function(){
  const app = useApp();
  const user = useUser();
  const style = useStyle();
  const [ styleValue, styleValueChange ] = useSetting({
    defaultValue: {},
    field: style.field,
  });

  return (
    <>
      <List
        data={[style.data.font]}
        renderItem={item => (
          <Select
            {...item}
            width={160}
            value={styleValue[item.field]}
            onChange={value => {
              if(user.member || authorize(item.field)){
                styleValueChange(value, item.field);
                app.fire('send', 'analytics', {event:`style-${item.field}`});
              } else {
                app.fire('upgrade');
                app.fire('send', 'analytics', {event:`style-upgrade-${item.field}`});
              }
            }}
          />
        )}
      />
      <List
        borderNone
        className="slider-wrapper style-slider"
        data={['size', 'width', 'space', 'lineheight', 'weight', 'blockspace', 'indent'].map(item => style.data[item])}
      >
        {item => (
          <Slider
            {...item}
            value={styleValue[item.field]}
            onChange={value => {
              if(user.member || authorize(item.field)){
                styleValueChange(value, item.field);
                app.fire('send', 'analytics', {event:`style-${item.field}`});
              } else {
                app.fire('upgrade');
                app.fire('send', 'analytics', {event:`style-upgrade-${item.field}`});
              }
            }}
          />
        )}
      </List>
      <List
        borderTop
        borderBottom
        className="style-align"
        data={['titlealign', 'align', 'imagealign'].map(item => style.data[item])}
        renderItem={item => (
          <Align
            {...item}
            value={styleValue[item.field]}
            justify={item.field !== 'imagealign'}
            onChange={value => {
              if(user.member || authorize(item.field)){
                styleValueChange(value, item.field);
                app.fire('send', 'analytics', {event:`style-${item.field}`});
              } else {
                app.fire('upgrade');
                app.fire('send', 'analytics', {event:`style-upgrade-${item.field}`});
              }
            }}
          />
        )}
      />
      <List
        borderBottom
        data={[style.data.imagehide]}
        renderItem={item => (
          <Switch
            checked={!!styleValue[item.field]}
            onChange={checked => {
              if(!checked || user.member || authorize(item.field)){
                styleValueChange(checked, item.field);
                app.fire('send', 'analytics', {event:`style-${item.field}`});
              } else {
                app.fire('upgrade');
                app.fire('send', 'analytics', {event:`style-upgrade-${item.field}`});
              }
            }}
          />
        )}
      />
      <More
        data={styleValue}
        onChange={styleValueChange}
      />
    </>
  );
}
