import React from 'react';
import { toolbar } from '../../config';
import List from 'app/components/list';
import Slider from 'plugin/setting/components/slider';
import useSetting from 'plugin/setting/context/useSetting';

export default function(){
  const [ toolbarValue, toolbarValueChange ] = useSetting({
    defaultValue: {},
    field: toolbar.field,
  });

  return (
    <List
      data={[toolbar.data.distance, toolbar.data.item]}
    >
      {item => (
        <Slider
          {...item}
          value={toolbarValue[item.field]}
          onChange={value => {
            toolbarValueChange(value, item.field);
          }}
        />
      )}
    </List>
  );
}
