import React from 'react';
import { Switch } from 'antd';
import List from 'app/components/list';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import useOption from 'app/context/useOption';
import { authorize } from 'app/components/authorize';
import useToolbar from 'plugin/setting/context/useToolbar';
import './index.less';

export default function(){
  const app = useApp();
  const user = useUser();
  const toolbar = useToolbar();
  const [ toolbars, toolbarsChange ] = useOption({
    defaultValue:[],
    field:toolbar.field,
  });

  return (
    <List
      borderBottom
      data={toolbar.data}
      className="toolbars"
      renderItem={item => (
        <Switch
          checked={toolbars.filter(toolbar => toolbar.field === item.field).length === 1}
          onChange={checked => {
            if(!checked || user.member || authorize(item.field)){
              if(checked){
                delete item.tooltip;
                delete item.learn_more;
                delete item.onChange;
                toolbars.push(item);
                app.fire('toolbar-item', item);
                toolbarsChange([].concat(toolbars));
              } else {
                app.fire('toolbar-item', item.field);
                toolbarsChange(toolbars.filter(toolbar => toolbar.field !== item.field));
              }
              app.fire('send', 'analytics', {event:`toolset-${item.field}`});
            } else {
              app.fire('upgrade');
              app.fire('send', 'analytics', {event:`toolset-upgrade-${item.field}`});
            }
          }}
        />
      )}
    />
  );
}
