import React from 'react';
// import { layout } from './config';
// import useSetting from 'plugin/setting/context/useSetting';
// import Align from 'plugin/setting/components/align';
// import Slider from 'plugin/setting/components/slider';

export default function(){
  // const [ layoutValue, layoutValueChange ] = useSetting({
  //   defaultValue: {},
  //   field: layout.field,
  // });

  return null;
}
