import React from 'react';
import Top from './top';
import Bottom from './bottom';

export default function(){

  return (
    <>
      <Bottom />
      <Top />
    </>
  );
}
