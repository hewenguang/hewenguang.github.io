import React from 'react';
import List from 'app/components/list';
import Switch from 'app/components/switch/option';
import useLayout from 'plugin/setting/context/useLayout';

export default function(){
  const layout = useLayout();

  return (
    <List
      borderBottom
      data={[layout.data.paper, layout.data.removefooter]}
      renderItem={item => (
        <Switch {...item} />
      )}
    />
  );
}
