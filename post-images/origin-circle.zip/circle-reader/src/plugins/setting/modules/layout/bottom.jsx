import React from 'react';
import { Switch } from 'antd';
import List from 'app/components/list';
import useApp from 'app/context/useApp';
import useUser from 'app/context/useUser';
import Slider from 'app/components/slider';
import { authorize } from 'app/components/authorize';
import useLayout from 'plugin/setting/context/useLayout';
import useSetting from 'plugin/setting/context/useSetting';

export default function(){
  const app = useApp();
  const user = useUser();
  const layout = useLayout();
  const [ layoutValue, layoutValueChange ] = useSetting({
    defaultValue: {},
    field: layout.field,
  });

  return (
    <>
      <List
        borderBottom
        data={[layout.data.column]}
        renderItem={item => (
          <Switch
            checked={!!layoutValue[item.field]}
            onChange={checked => {
              if(!checked || user.member || authorize(item.field)){
                layoutValueChange(checked, item.field);
                app.fire('send', 'analytics', {event:`layout-${item.field}`});
              } else {
                app.fire('upgrade');
                app.fire('send', 'analytics', {event:`layout-upgrade-${item.field}`});
              }
            }}
          />
        )}
      />
      <List
        borderBottom
        className="slider-wrapper"
        data={[layout.data.columncount, layout.data.columngap]}
      >
        {function(item){
          const authorized = user.member || authorize(item.field);
          return (
            <Slider
              {...item}
              vip={!authorized}
              onAuthorize={() => authorized}
              value={layoutValue[item.field]}
              disabled={!layoutValue[layout.data.column.field]}
              onChange={value => {
                if(authorized){
                  layoutValueChange(value, item.field);
                  app.fire('send', 'analytics', {event:`layout-${item.field}`});
                } else {
                  app.fire('upgrade');
                  app.fire('send', 'analytics', {event:`layout-upgrade-${item.field}`});
                }
              }}
            />
          );
        }}
      </List>
      <List
        borderBottom
        className="slider-wrapper"
        data={[layout.data.margin, layout.data.padding, layout.data.itemspace, layout.data.groupspace]}
      >
        {function(item){
          const authorized = user.member || authorize(item.field);
          return (
            <Slider
              {...item}
              vip={!authorized}
              value={layoutValue[item.field]}
              onAuthorize={() => authorized}
              onChange={value => {
                if(authorized){
                  layoutValueChange(value, item.field);
                  app.fire('send', 'analytics', {event:`layout-${item.field}`});
                } else {
                  app.fire('upgrade');
                  app.fire('send', 'analytics', {event:`layout-upgrade-${item.field}`});
                }
              }}
            />
          );
        }}
      </List>
      <List
        borderBottom
        data={[layout.data.autohide]}
        renderItem={item => (
          <Switch
            checked={!!layoutValue[item.field]}
            onChange={checked => {
              if(!checked || user.member || authorize(item.field)){
                layoutValueChange(checked, item.field);
                app.fire('send', 'analytics', {event:`layout-${item.field}`});
              } else {
                app.fire('upgrade');
                app.fire('send', 'analytics', {event:`layout-upgrade-${item.field}`});
              }
            }}
          />
        )}
      />
    </>
  );
}
