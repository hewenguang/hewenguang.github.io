import React, { useContext } from 'react';
import { Button, Tooltip } from 'antd';
import { AppContext } from 'app/context';
import useSetting from 'plugin/setting/context/useSetting';
import './index.less';

export default function(props){
  const { title, text, field, data } = props;
  const app = useContext(AppContext);
  const initialValues = {};
  utils.each(data, function(item, key){
    const unit = item.unit;
    const defaultValue = item.defaultValue;
    if(!utils.isUndefined(defaultValue)){
      initialValues[key] = unit ? `${defaultValue}${unit}` : defaultValue;
    }
  });
  const defaultValue = Object.assign({}, initialValues);
  const [ styleValue, styleValueChange ] = useSetting({
    field,
    defaultValue,
  });

  return (
    <>
      {title}
      {!utils.isEqualObject(styleValue, initialValues) && (
        <div className="reset">
          <Tooltip
            title={text}
            placement="bottom"
          >
            <Button
              onClick={event => {
                event.stopPropagation();
                styleValueChange(defaultValue);
              }}
            >
              {app.fire('i18n', 'reset')}
            </Button>
          </Tooltip>
        </div>
      )}
    </>
  );
}
