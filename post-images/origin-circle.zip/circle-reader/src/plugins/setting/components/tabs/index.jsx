import React from 'react';
import cx from 'classnames';
import { Tabs } from 'antd';
import useApp from 'app/context/useApp';
import Title from 'app/components/title';
import useUser from 'app/context/useUser';
import Authorize, { authorize } from 'app/components/authorize';
import './index.less';

const { TabPane } = Tabs;

export default function(props){
  const {
    extra, disabled, data, pure,
    className, onChange, ...resetProps
  } = props;
  const app = useApp();
  const user = useUser();

  return (
    <Tabs
      {...resetProps}
      className={cx('tabs', className, {pure})}
      tabBarExtraContent={extra && {left:extra}}
      onChange={key => {
        if(user.member || authorize(key)){
          onChange && onChange(key);
        } else {
          app.fire('upgrade');
        }
      }}
    >
      {data.map(item => (
        <TabPane
          key={item.key}
          disabled={disabled}
          tab={
            <Authorize
              field={item.key}
              access={user.member}
            >
              <Title label={item.tab} />
            </Authorize>
          }          
        >
          {item.value}
        </TabPane>
      ))}
    </Tabs>
  );
}
