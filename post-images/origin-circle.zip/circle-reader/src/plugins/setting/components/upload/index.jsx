import React from 'react';
import { Upload } from 'antd';
import { LoadingOutlined, UploadOutlined } from '@ant-design/icons';

export default function(props){
  const { text = 'Upload' } = props;

  const loading = false;
  const imageUrl = null;

  return (
    <Upload
      name="avatar"
      listType="picture-card"
      className="avatar-uploader"
      showUploadList={false}
    >
      {imageUrl ? <img src={imageUrl} alt="avatar" style={{ width: '100%' }} /> : (
        <div>
        {loading ? <LoadingOutlined /> : <UploadOutlined />}
        <div>{text}</div>
      </div>
      )}
    </Upload>
  );
}
