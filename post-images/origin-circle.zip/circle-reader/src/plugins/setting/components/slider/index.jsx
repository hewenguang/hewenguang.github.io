import { Row, Col, Slider } from 'antd';
import React, { useState, useEffect } from 'react';
import InputNumber from '../inputnumber';
import './index.less';

export default function(props){
  const { min = 0, max, step = 1, unit, label, value = 0, disabled, defaultValue, onChange } = props;
  const siliderDefaultValue = utils.isString(defaultValue) && defaultValue ? parseFloat(defaultValue) : defaultValue;
  const [ sliderValue, setSliderValue ] = useState(value || siliderDefaultValue);

  useEffect(() => {
    const changeValue = utils.isString(value) && value ? parseFloat(value) : value;
    setSliderValue(changeValue || siliderDefaultValue);
  }, [ value ]);

  return (
    <div className="slider">
      <Row>
        <Col
          span={24}
          style={{textAlign:'left'}}
        >
          {label}
        </Col>
      </Row>
      <Row align="bottom">
        <Col span={16}>
          <Slider
            min={min}
            max={max}
            step={step}
            disabled={disabled}
            value={sliderValue}
            tooltipVisible={false}
            onChange={setSliderValue}
            onAfterChange={val => {
              onChange(unit ? `${val}${unit}` : val)
            }}
          />
        </Col>
        <Col span={8}>
          <InputNumber
            min={0}
            max={max}
            unit={unit}
            step={step}
            value={sliderValue}
            disabled={disabled}
            onStep={val => {
              onChange(unit ? `${val}${unit}` : val)
            }}
            onInput={val => {
              onChange(unit ? `${val}${unit}` : val)
            }}
          />
        </Col>
      </Row>
    </div>
  );
}
