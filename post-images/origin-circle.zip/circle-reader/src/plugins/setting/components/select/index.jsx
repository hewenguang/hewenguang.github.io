import { Input, Select } from 'antd';
import React, { useState, useEffect } from 'react';

const { Option, OptGroup } = Select;

export default function(props){
  const { data, defaultValue, value, onChange, placeholder, width = '100%' } = props;
  const [ custom, setCustom ] = useState(false);
  const [ customValue, setCustomValue ] = useState('');

  useEffect(() => {
    if(!data || !value){
      return;
    }
    let initCustom = false;
    utils.each(data, function(group){
      const items = group.items;
      if(items){
        utils.each(items, function(item){
          if(item.value === value){
            initCustom = true;
            return true;
          }
        });
      } else {
        if(group.value === value){
          initCustom = true;
          return true;
        }
      }
    });
    !initCustom && setCustomValue(value);
  }, [ data, value ]);

  const selectValue = customValue || value || defaultValue;

  return custom ? (
    <Input
      autoFocus
      style={{width}}
      value={customValue}
      placeholder={placeholder}
      onBlur={(event) => {
        setCustom(false);
        onChange && onChange(event.target.value);
      }}
      onPressEnter={(event) => {
        setCustom(false);
        onChange && onChange(event.target.value);
      }}
      onChange={event => {
        setCustomValue(event.target.value);
      }}
    />
  ) : (
    <Select
      style={{width}}
      placeholder={placeholder}
      value={selectValue ? selectValue : undefined}
      onChange={val => {
        if(val === 'custom'){
          setCustom(true);
        } else {
          onChange && onChange(val);
          customValue && setCustomValue('');
        }
      }}
    >
      {data.map(group => {
        const items = group.items;
        if(items){
          return (
            <OptGroup
              key={group.label}
              label={group.label}
              style={group.style}
            >
              {items.map(item => (
                <Option
                  key={item.value}
                  value={item.value}
                  style={item.style}
                >
                  {item.label}
                </Option>
              ))}
            </OptGroup>
          );
        }
        return (
          <Option
            key={group.label}
            style={group.style}
            value={group.value}
          >
            {group.label}
          </Option>
        );
      })}
    </Select>
  );
}
