import React from 'react';
import { Radio } from 'antd';
import Icon from 'app/components/icon';
import './index.less';

export default function(props){
  const { value, onChange, justify = true, defaultValue = 'left' } = props;

  return (
    <Radio.Group
      value={value}
      className="align"
      buttonStyle="solid"
      defaultValue={defaultValue}
      onChange={(event) => onChange(event.target.value)}
    >
      {justify && <Radio.Button value="justify"><Icon name="alignjustify" /></Radio.Button>}
      <Radio.Button value="left"><Icon name="alignleft" /></Radio.Button>
      <Radio.Button value="center"><Icon name="aligncenter" /></Radio.Button>
      <Radio.Button value="right"><Icon name="alignright" /></Radio.Button>
    </Radio.Group>
  );
}
