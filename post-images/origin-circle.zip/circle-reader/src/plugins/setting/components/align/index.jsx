import React from 'react';
import { Radio } from 'antd';
import { AlignLeftOutlined, AlignCenterOutlined, AlignRightOutlined } from '@ant-design/icons';
import './index.less';

export default function(props){
  const { value, onChange, defaultValue = 'left' } = props;

  return (
    <Radio.Group
      value={value}
      className="align"
      buttonStyle="solid"
      defaultValue={defaultValue}
      onChange={(event) => onChange(event.target.value)}
    >
      <Radio.Button value="left"><AlignLeftOutlined /></Radio.Button>
      <Radio.Button value="center"><AlignCenterOutlined /></Radio.Button>
      <Radio.Button value="right"><AlignRightOutlined /></Radio.Button>
    </Radio.Group>
  );
}
