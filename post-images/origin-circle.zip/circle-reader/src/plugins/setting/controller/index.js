export default function(app, root){
  app.on('render-start-done', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('render-destory-done', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-before', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-after', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('setting-change', function(visible){
    if(visible){
      const target = root.querySelector('.style .ant-collapse-header');
      target && target.focus && target.focus();
    } else {
      app.fire('setting-theme'); // 退出时需要恢复修改因跟随系统预览导致的主题错误
    }
  });
  app.on('layout', function(value, key){
    if(key === 'column'){
      app.fire('message', {
        duration: 1,
        key: 'column',
        type: 'success',
        message: app.fire('i18n', 'refresh_to_active'),
      });
    }
  });
}
