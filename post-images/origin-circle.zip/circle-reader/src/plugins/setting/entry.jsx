import React from 'react';
import { Collapse } from 'antd';
import Style from 'plugin/setting/modules/style';
import Theme from 'plugin/setting/modules/theme';
import Reset from 'plugin/setting/components/reset';
import useStyle from 'plugin/setting/context/useStyle';
import useTheme from 'plugin/setting/context/useTheme';

const { Panel } = Collapse;

export default function(){
  const style = useStyle();
  const theme = useTheme();

  return (
    <Collapse
      accordion
      bordered={false}
      className="collapse"
      defaultActiveKey={style.field}
    >
      <Panel
        key={style.field}
        header={
          <Reset
            data={style.data}
            field={style.field}
            title={style.label}
            text={style.label_tooltip}
          />
        }
      >
        <Style />
      </Panel>
      <Panel
        key={theme.field}
        header={theme.label}
      >
        <Theme />
      </Panel>
      {/* <Panel
        key="toolbar"
        header={
          <Reset
            title="工具栏"
            text="初始化工具栏"
            data={toolbar.data}
            field={toolbar.field}
          />
        }
      >
        <Toolbar />
      </Panel> */}
      {/* <Panel
        key="layout"
        header={
          <Reset
            title="布局"
            text="初始化所有布局"
            data={layout.data}
            field={layout.field}
          />
        }
      >
        <Layout />
      </Panel> */}
    </Collapse>
  );
}
