import { Collapse } from 'antd';
import Style from './modules/style';
import Theme from './modules/theme';
import Layout from './modules/layout';
import Reset from './components/reset';
import useApp from 'app/context/useApp';
import Toolbar from './modules/toolbar';
import useStyle from './context/useStyle';
import useTheme from './context/useTheme';
import useLayout from './context/useLayout';
import useToolbar from './context/useToolbar';
import React, { useState, useEffect } from 'react';

const { Panel } = Collapse;

export default function({root}){
  const app = useApp();
  const style = useStyle();
  const theme = useTheme();
  const layout = useLayout();
  const toolbar = useToolbar();
  const [ activeKey, setActiveKey ] = useState(style.field);

  useEffect(() => {
    const hook = app.on('guide', function(key, selector){
      if(![style.field, theme.field, layout.field, toolbar.field].includes(key)){
        return;
      }
      setActiveKey(key);
      selector && setTimeout(function(){
        const target = root.querySelector(`.${selector}`);
        if(!target){
          return;
        }
        dom.scrollIntoView(target);
        target.classList.add('twinkle');
        const focusable = target.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        focusable && focusable.focus();
      }, 1000);
    });
    return () => {
      app.remove(hook);
    };
  }, []);

  return (
    <Collapse
      accordion
      bordered={false}
      className="collapse"
      activeKey={activeKey}
      onChange={val => {
        setActiveKey(val);
        app.fire('send', 'analytics', {event:`setting-${val}`});
      }}
    >
      <Panel
        key={style.field}
        className={style.field}
        header={
          <Reset
            data={style.data}
            field={style.field}
            title={style.label}
            text={style.label_tooltip}
          />
        }
      >
        <Style />
      </Panel>
      <Panel
        key={theme.field}
        className={theme.field}
        header={theme.label}
      >
        <Theme />
      </Panel>
      <Panel
        key={layout.field}
        className={layout.field}
        header={
          <Reset
            data={layout.data}
            field={layout.field}
            title={layout.label}
            text={layout.label_tooltip}
          />
        }
      >
        <Layout />
      </Panel>
      <Panel
        key={toolbar.field}
        className={toolbar.field}
        header={toolbar.label}
      >
        <Toolbar />
      </Panel>
    </Collapse>
  );
}
