import { useContext } from 'react';
import { AppContext } from 'app/context';

export default function useStyle(){
  const app = useContext(AppContext);

  return {
    field:'style',
    label: app.fire('i18n', 'style'),
    label_tooltip: app.fire('i18n', 'style_tooltip'),
    more: app.fire('i18n', 'more'),
    data: {
      font:{
        label: app.fire('i18n', 'font'),
        tooltip: app.fire('i18n', 'font_tooltip'),
        field: 'font',
        placement: 'topLeft',
        defaultValue: 'reset',
        placeholder: app.fire('i18n', 'default'),
        data: [{
          label: app.fire('i18n', 'default'),
          value: 'reset',
        },{
          label: app.fire('i18n', 'custom'),
          value: 'custom',
        },
        {
          label: app.fire('i18n', 'cn_font'),
          items: [{
            label: app.fire('i18n', 'simhei'),
            value: 'SimHei',
          },{
            label: app.fire('i18n', 'simsun'),
            value: 'SimSun',
          },{
            label: app.fire('i18n', 'nsimsun'),
            value: 'NSimSun',
          },{
            label: app.fire('i18n', 'fangsong'),
            value: 'FangSong',
          },{
            label: app.fire('i18n', 'kaiti'),
            value: 'KaiTi',
          },{
            label: app.fire('i18n', 'pingfang'),
            value: 'PingFang SC',
          },{
            label: app.fire('i18n', 'lantinghei'),
            value: 'Lantinghei SC',
          },{
            label: app.fire('i18n', 'yahei'),
            value: 'Microsoft YaHei',
          },{
            label: app.fire('i18n', 'hiragino'),
            value: 'Hiragino Sans GB',
          },{
            label: app.fire('i18n', 'lisu'),
            value: 'LiSu',
          },{
            label: app.fire('i18n', 'youyuan'),
            value: 'YouYuan',
          },{
            label: app.fire('i18n', 'stxihei'),
            value: 'STXihei',
          },{
            label: app.fire('i18n', 'stheiti'),
            value: 'STHeiti',
          },{
            label: app.fire('i18n', 'stkaiti'),
            value: 'STKaiti',
          },{
            label: app.fire('i18n', 'stsong'),
            value: 'STSong',
          },{
            label: app.fire('i18n', 'stzhongsong'),
            value: 'STZhongsong',
          },{
            label: app.fire('i18n', 'stfangsong'),
            value: 'STFangsong',
          },{
            label: app.fire('i18n', 'fzshuTi'),
            value: 'FZShuTi',
          },{
            label: app.fire('i18n', 'fzyaoti'),
            value: 'FZYaoti',
          },{
            label: app.fire('i18n', 'stcaiyun'),
            value: 'STCaiyun',
          },{
            label: app.fire('i18n', 'sthupo'),
            value: 'STHupo',
          },{
            label: app.fire('i18n', 'stliti'),
            value: 'STLiti',
          },{
            label: app.fire('i18n', 'stxingkai'),
            value: 'STXingkai',
          },{
            label: app.fire('i18n', 'stxinwei'),
            value: 'STXinwei',
          }],
        },{
          label: app.fire('i18n', 'en_font'),
          items: [{
            label:'Serif',
            value:'serif',
          },{
            label:'Garamond',
            value:'Garamond',
          },{
            label:'Georgia',
            value:'Georgia',
          },{
            label:'Times',
            value:'Times',
          },{
            label:'Times New Roman',
            value:'Times New Roman',
          },{
            label:'Bookman Old Style',
            value:'Bookman Old Style',
          },{
            label:'Palatino Linotype',
            value:'Palatino Linotype',
          },{
            label:'Book Antiqua',
            value:'Book Antiqua',
          },{
            label:'Palatino',
            value:'Palatino',
          },{
            label:'Sans-serif',
            value:'sans-serif',
          },{
            label:'Arial',
            value:'Arial',
          },{
            label:'Arial Black',
            value:'Arial Black',
          },{
            label:'Helvetica',
            value:'Helvetica',
          },{
            label:'Gadget',
            value:'Gadget',
          },{
            label:'Impact',
            value:'Impact',
          },{
            label:'Charcoal',
            value:'Charcoal',
          },{
            label:'Lucida Sans Unicode',
            value:'Lucida Sans Unicode',
          },{
            label:'Lucida Grande',
            value:'Lucida Grande',
          },{
            label:'MS Sans Serif',
            value:'MS Sans Serif',
          },{
            label:'Geneva',
            value:'Geneva',
          },{
            label:'MS Serif',
            value:'MS Serif',
          },{
            label:'New York',
            value:'New York',
          },{
            label:'Symbol',
            value:'Symbol',
          },{
            label:'Tahoma',
            value:'Tahoma',
          },{
            label:'Trebuchet MS',
            value:'Trebuchet MS',
          },{
            label:'Verdana',
            value:'Verdana',
          },{
            label:'Webdings',
            value:'Webdings',
          },{
            label:'Wingdings',
            value:'Wingdings',
          },{
            label:'Zapf Dingbats',
            value:'Zapf Dingbats',
          },{
            label:'Comic Sans MS',
            value:'Comic Sans MS',
          },{
            label:'cursive',
            value:'cursive',
          },{
            label:'Courier',
            value:'Courier',
          },{
            label:'Courier New',
            value:'Courier New',
          },{
            label:'monospace',
            value:'monospace',
          },{
            label:'Lucida Console',
            value:'Lucida Console',
          },{
            label:'Monaco',
            value:'Monaco',
          },{
            label:'Calibri',
            value:'Calibri',
          },{
            label:'Candara',
            value:'Candara',
          },{
            label:'Open Sans',
            value:'Open Sans',
          },{
            label:'Optima',
            value:'Optima',
          },{
            label:'Baskerville',
            value:'Baskerville',
          },{
            label:'Futura',
            value:'Futura',
          }]
        }],
      },
      size:{
        label: app.fire('i18n', 'size'),
        min:12,
        max:50,
        unit:'px',
        field:'size',
        defaultValue: 20,
      },
      width:{
        label: app.fire('i18n', 'width'),
        min:600,
        max:2500,
        unit:'px',
        field:'width',
        defaultValue: 800,
      },
      space:{
        label: app.fire('i18n', 'space'),
        max:10,
        unit:'px',
        field:'space',
        defaultValue: 0,
      },
      lineheight:{
        label: app.fire('i18n', 'lineheight'),
        min:1,
        max:3,
        step:0.1,
        field:'lineheight',
        defaultValue: 1.8,
      },
      weight:{
        label: app.fire('i18n', 'weight'),
        min:100,
        max:900,
        step:100,
        field:'weight',
        defaultValue: 400,
      },
      blockspace:{
        label: app.fire('i18n', 'blockspace'),
        max:50,
        step:2,
        unit:'px',
        field:'blockspace',
        defaultValue: 32,
      },
      indent:{
        label: app.fire('i18n', 'indent'),
        max:10,
        unit:'em',
        field:'indent',
        defaultValue: 0,
      },
      titlealign:{
        label: app.fire('i18n', 'titlealign'),
        field:'titlealign',
        defaultValue: 'left',
      },
      align:{
        label: app.fire('i18n', 'align'),
        field:'align',
        defaultValue: 'left',
      },
      imagealign:{
        label: app.fire('i18n', 'imagealign'),
        field:'imagealign',
        defaultValue: 'center',
      },
      imagehide: {
        label: app.fire('i18n', 'imagehide'),
        field: 'imagehide',
        checked: 'none',
        unchecked: 'block',
        defaultValue: 'block',
      },
      title1: {
        min:1,
        max:5,
        step:0.1,
        unit:'em',
        label: app.fire('i18n', 'title1'),
        field: 'title1',
        defaultValue: 2,
      },
      title2: {
        min:1,
        max:5,
        step:0.1,
        unit:'em',
        label: app.fire('i18n', 'title2'),
        field: 'title2',
        defaultValue: 1.6,
      },
      title3: {
        min:1,
        max:5,
        step:0.1,
        unit:'em',
        label: app.fire('i18n', 'title3'),
        field: 'title3',
        defaultValue: 1.2,
      },
      title4: {
        min:1,
        max:5,
        step:0.1,
        unit:'em',
        label: app.fire('i18n', 'title4'),
        field: 'title4',
        defaultValue: 1,
      },
      title5: {
        min:1,
        max:5,
        step:0.1,
        unit:'em',
        label: app.fire('i18n', 'title5'),
        field: 'title5',
        defaultValue: 1,
      },
      title6: {
        min:1,
        max:5,
        step:0.1,
        unit:'em',
        label: app.fire('i18n', 'title6'),
        field: 'title6',
        defaultValue: 1,
      },
    },
  };
}
