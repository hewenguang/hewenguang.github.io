import useApp from 'app/context/useApp';

export default function(){
  const app = useApp();

  return {
    field:'layout',
    label: app.fire('i18n', 'layout'),
    data: {
      paper: {
        field: 'paper',
        label: app.fire('i18n', 'paper'),
        tooltip: app.fire('i18n', 'paper_tooltip'),
        learn_more: app.to('node/34'),
      },
      removefooter: {
        field: 'removefooter',
        label: app.fire('i18n', 'removefooter'),
      },
      column: {
        field: 'column',
        defaultValue: false,
        label: app.fire('i18n', 'column'),
        tooltip: app.fire('i18n', 'column_tooltip'),
        learn_more: app.to('node/33'),
      },
      columncount: {
        min:2,
        max:5,
        step:1,
        defaultValue: 2,
        field:'columncount',
        label: app.fire('i18n', 'columncount'),
      },
      columngap: {
        min:10,
        max:100,
        step:1,
        unit: 'px',
        defaultValue: 60,
        field:'columngap',
        label: app.fire('i18n', 'columngap'),
      },
      margin:{
        min:0,
        max:100,
        step:1,
        unit:'px',
        field:'margin',
        defaultValue: 80,
        label: app.fire('i18n', 'margin'),
      },
      padding: {
        min:0,
        max:100,
        step:1,
        unit:'px',
        field:'padding',
        defaultValue: 80,
        label: app.fire('i18n', 'padding'),
      },
      itemspace: {
        min: 0,
        max: 50,
        unit:'px',
        field:'itemspace',
        defaultValue: 10,
        label:app.fire('i18n', 'itemspace'),
      },
      groupspace: {
        min: 0,
        max: 50,
        unit:'px',
        field:'groupspace',
        defaultValue: 10,
        label:app.fire('i18n', 'groupspace'),
      },
      autohide: {
        field:'autohide',
        defaultValue:false,
        label:app.fire('i18n', 'autohide'),
      }
    },
  };
}
