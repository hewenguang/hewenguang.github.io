import { AppContext } from 'app/context';
import { useState, useEffect, useContext } from 'react';

export default function useSetting(props){
  const app = useContext(AppContext);
  const { field, table = 'setting', defaultValue } = props;
  const [ option, setOption ] = useState(defaultValue);
  const query = function(callback){
    app.fire('send', 'db', {
      table,
      name:field,
      execute:'get',
    }, function({error, data}){
      if(error){
        app.fire('error', error);
      } else {
        if(callback){
          callback(data);
        } else {
          !utils.isUndefined(data) && setOption(data);
        }
      }
    });
  };
  const change = function(value, key){
    if(value === option){
      app.fire('send', 'db', {
        table,
        name: field,
        execute: 'remove',
      }, function({error}){
        if(error){
          app.fire('error', error);
        } else {
          setOption(value);
          app.fire('theme', value, key);
          app.fire(field, value, key);
        }
      });
    } else {
      query(function(theme = {}){
        const newTheme = Object.assign(theme, utils.isPlainObject(value) ? value : {[key]: value});
        app.fire('send', 'db', {
          table,
          name: field,
          execute: 'add',
          value: newTheme,
        }, function({error}){
          if(error){
            app.fire('error', error);
          } else {
            setOption(newTheme);
            app.fire('theme', value, key);
            app.fire(field, value, key);
          }
        });
      });
    }
  };

  useEffect(query, []);

  useEffect(() => {
    const hook = app.on(field, function(value, key){
      const newOption = Object.assign({}, option, utils.isPlainObject(value) ? value : {[key]: value});
      !utils.isEqualObject(newOption, option) && setOption(newOption);
    });
    return () => {
      app.remove(hook);
    };
  }, [ option ]);

  return [ option, change, setOption ];
}
