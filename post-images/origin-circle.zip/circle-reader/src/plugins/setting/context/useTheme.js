import { useContext } from 'react';
import { AppContext } from 'app/context';

export default function useTheme(){
  const app = useContext(AppContext);

  return {
    label: app.fire('i18n', 'skin'),
    field: 'skin',
    data: [{
      name: 'light',
      style: {
        color: '#1b1b1b',
        outlineColor: '#f0eded',
        border: '1px solid #f0eded',
        backgroundColor: '#ffffff',
      },
      value:{
        color: '#1b1b1b',
        link: '#416ed2',
        hover:'#305ab7',
        visited:'#305ab7',
        select:'#1b1b1b',
        selectbg:'#416ed2',
        bg: '#ffffff',
        track: '#e2e2e2',
        thumb: '#9e9e9e',
        radius: '4px',
      }
    },{
      name: 'green',
      style: {
        color: '#3a4b43',
        outlineColor: '#c5e7ce',
        backgroundColor: '#c5e7ce',
      },
      value:{
        color: '#3a4b43',
        link: '#507964',
        hover:'#3e6b54',
        visited:'#3e6b54',
        select:'#3a4b43',
        selectbg:'#507964',
        bg: '#c5e7ce',
        track: '#8faf98',
        thumb: '#5a8064',
        radius: '4px',
      }
    },{
      name: 'yellow',
      style: {
        color: '#4f321c',
        outlineColor: '#f8f1e3',
        backgroundColor: '#f8f1e3',
      },
      value:{
        color: '#4f321c',
        link: '#d19600',
        hover:'#ad7d03',
        visited:'#ad7d03',
        select:'#4f321c',
        selectbg:'#d19600',
        bg: '#f8f1e3',
        track: '#d6cfc1',
        thumb: '#b3ac9c',
        radius: '4px',
      }
    },{
      name: 'gray',
      style: {
        color: '#b0b0b0',
        outlineColor: '#4a4a4d',
        backgroundColor: '#4a4a4d',
      },
      value:{
        color: '#b0b0b0',
        link: '#5ac8fa',
        hover:'#3ea4d2',
        visited:'#3ea4d2',
        select:'#fffefe',
        selectbg:'#43b0e2',
        bg: '#4a4a4d',
        track: '#4e4e50',
        thumb: '#83838c',
        radius: '4px',
      }
    },{
      name: 'dark',
      style: {
        color: '#b0b0b0',
        outlineColor: '#121212',
        backgroundColor: '#121212',
      },
      value: {
        color: '#b0b0b0',
        link: '#5ac8fa',
        hover:'#3ea4d2',
        visited:'#3ea4d2',
        select:'#fffefe',
        selectbg:'#43b0e2',
        bg: '#121212',
        track: '#3c3a3a',
        thumb: '#848484',
        radius: '4px',
      }
    },{
      name: 'custom',
    }],
    color: {
      data:[{
        label: app.fire('i18n', 'color'),
        field: 'color',
      },{
        label: app.fire('i18n', 'link'),
        field: 'link',
      },{
        label: app.fire('i18n', 'hover'),
        field: 'hover',
        tooltip: app.fire('i18n', 'hover_tooltip'),
      },{
        label: app.fire('i18n', 'visited'),
        field: 'visited',
        tooltip: app.fire('i18n', 'visited_tooltip'),
      },{
        label: app.fire('i18n', 'select'),
        field: 'select',
        tooltip: app.fire('i18n', 'select_tooltip'),
      },{
        label: app.fire('i18n', 'selectbg'),
        field: 'selectbg',
        tooltip: app.fire('i18n', 'selectbg_tooltip'),
      }],
    },
    scrollbar: {
      field: 'scrollbar',
      title:{
        field: 'scrollbar',
        label: app.fire('i18n', 'scrollbar'),
      },
      data: [{
        name: 'light',
        style: {
          borderRadius: 4,
          outlineColor: '#e2e2e2',
          border: '1px solid #f0eded',
          backgroundColor: '#e2e2e2',
          boxShadow: '20px 0px #9e9e9e inset',
        },
        value:{
          track: '#e2e2e2',
          thumb: '#9e9e9e',
          radius: '4px',
        }
      },{
        name: 'green',
        style: {
          borderRadius: 4,
          outlineColor: '#8faf98',
          backgroundColor: '#8faf98',
          boxShadow: '20px 0px #5a8064 inset',
        },
        value:{
          track: '#8faf98',
          thumb: '#5a8064',
          radius: '4px',
        }
      },{
        name: 'yellow',
        style: {
          borderRadius: 4,
          outlineColor: '#d6cfc1',
          backgroundColor: '#d6cfc1',
          boxShadow: '20px 0px #b3ac9c inset',
        },
        value:{
          track: '#d6cfc1',
          thumb: '#b3ac9c',
          radius: '4px',
        }
      },{
        name: 'gray',
        style: {
          borderRadius: 4,
          outlineColor: '#4e4e50',
          backgroundColor: '#4e4e50',
          boxShadow: '20px 0px #83838c inset',
        },
        value:{
          track: '#4e4e50',
          thumb: '#83838c',
          radius: '4px',
        }
      },{
        name: 'dark',
        style: {
          borderRadius: 4,
          outlineColor: '#3c3a3a',
          backgroundColor: '#3c3a3a',
          boxShadow: '20px 0px #848484 inset',
        },
        value: {
          track: '#3c3a3a',
          thumb: '#848484',
          radius: '4px',
        }
      },{
        name: 'custom',
      }],
      color: [{
        label: app.fire('i18n', 'track'),
        field:'track',
      },{
        label: app.fire('i18n', 'thumb'),
        field:'thumb',
      }],
      radius: {
        max: 10,
        unit:'px',
        label: app.fire('i18n', 'radius'),
        field:'radius',
        defaultValue: 4,
      }
    },
    bg:{
      field: 'bg',
      label: app.fire('i18n', 'bg'),
    },
    solid:{
      field: 'solid',
      label: app.fire('i18n', 'solid'),
      data: [{
        name: '#ce9ffc',
        style: {
          outlineColor: '#ce9ffc',
          backgroundColor: '#ce9ffc',
        },
      },{
        name: '#90f7ec',
        style: {
          outlineColor: '#90f7ec',
          backgroundColor: '#90f7ec',
        },
      },{
        name: '#fff6b7',
        style: {
          outlineColor: '#fff6b7',
          backgroundColor: '#fff6b7',
        },
      },{
        name: '#81fbb8',
        style: {
          outlineColor: '#81fbb8',
          backgroundColor: '#81fbb8',
        },
      },{
        name: '#e2b0ff',
        style: {
          outlineColor: '#e2b0ff',
          backgroundColor: '#e2b0ff',
        },
      },{
        name: '#f97794',
        style: {
          outlineColor: '#f97794',
          backgroundColor: '#f97794',
        },
      },{
        name: '#fccf31',
        style: {
          outlineColor: '#fccf31',
          backgroundColor: '#fccf31',
        },
      },{
        name: '#f761a1',
        style: {
          outlineColor: '#f761a1',
          backgroundColor: '#f761a1',
        },
      },{
        name: '#43cbff',
        style: {
          outlineColor: '#43cbff',
          backgroundColor: '#43cbff',
        },
      },{
        name: '#5efce8',
        style: {
          outlineColor: '#5efce8',
          backgroundColor: '#5efce8',
        },
      },{
        name: '#fad7a1',
        style: {
          outlineColor: '#fad7a1',
          backgroundColor: '#fad7a1',
        },
      },{
        name: '#ffd26f',
        style: {
          outlineColor: '#ffd26f',
          backgroundColor: '#ffd26f',
        },
      },{
        name: '#a0fe65',
        style: {
          outlineColor: '#a0fe65',
          backgroundColor: '#a0fe65',
        },
      },{
        name: '#ffdb01',
        style: {
          outlineColor: '#ffdb01',
          backgroundColor: '#ffdb01',
        },
      },{
        name: '#fec163',
        style: {
          outlineColor: '#fec163',
          backgroundColor: '#fec163',
        },
      },{
        name: '#92ffc0',
        style: {
          outlineColor: '#92ffc0',
          backgroundColor: '#92ffc0',
        },
      },{
        name: '#eead92',
        style: {
          outlineColor: '#eead92',
          backgroundColor: '#eead92',
        },
      },{
        name: '#f6ceec',
        style: {
          outlineColor: '#f6ceec',
          backgroundColor: '#f6ceec',
        },
      },{
        name: '#52e5e7',
        style: {
          outlineColor: '#52e5e7',
          backgroundColor: '#52e5e7',
        },
      },{
        name: '#f1ca74',
        style: {
          outlineColor: '#f1ca74',
          backgroundColor: '#f1ca74',
        },
      },{
        name: '#e8d07a',
        style: {
          outlineColor: '#e8d07a',
          backgroundColor: '#e8d07a',
        },
      },{
        name: '#eece13',
        style: {
          outlineColor: '#eece13',
          backgroundColor: '#eece13',
        },
      },{
        name: '#79f1a4',
        style: {
          outlineColor: '#79f1a4',
          backgroundColor: '#79f1a4',
        },
      },{
        name: '#fdd819',
        style: {
          outlineColor: '#fdd819',
          backgroundColor: '#fdd819',
        },
      },{
        name: '#fff3b0',
        style: {
          outlineColor: '#fff3b0',
          backgroundColor: '#fff3b0',
        },
      },{
        name: '#fff5c3',
        style: {
          outlineColor: '#fff5c3',
          backgroundColor: '#fff5c3',
        },
      },{
        name: '#f05f57',
        style: {
          outlineColor: '#f05f57',
          backgroundColor: '#f05f57',
        },
      },{
        name: '#2afadf',
        style: {
          outlineColor: '#2afadf',
          backgroundColor: '#2afadf',
        },
      },{
        name: '#fff886',
        style: {
          outlineColor: '#fff886',
          backgroundColor: '#fff886',
        },
      },{
        name: '#97abff',
        style: {
          outlineColor: '#97abff',
          backgroundColor: '#97abff',
        },
      },{
        name: '#f5cbff',
        style: {
          outlineColor: '#f5cbff',
          backgroundColor: '#f5cbff',
        },
      },{
        name: '#ff6fd8',
        style: {
          outlineColor: '#ff6fd8',
          backgroundColor: '#ff6fd8',
        },
      },{
        name: '#ee9ae5',
        style: {
          outlineColor: '#ee9ae5',
          backgroundColor: '#ee9ae5',
        },
      },{
        name: '#ffd3a5',
        style: {
          outlineColor: '#ffd3a5',
          backgroundColor: '#ffd3a5',
        },
      },{
        name: '#c2ffd8',
        style: {
          outlineColor: '#c2ffd8',
          backgroundColor: '#c2ffd8',
        },
      },{
        name: '#fd6585',
        style: {
          outlineColor: '#fd6585',
          backgroundColor: '#fd6585',
        },
      },{
        name: '#fd6e6a',
        style: {
          outlineColor: '#fd6e6a',
          backgroundColor: '#fd6e6a',
        },
      },{
        name: '#65fdf0',
        style: {
          outlineColor: '#65fdf0',
          backgroundColor: '#65fdf0',
        },
      },{
        name: '#6b73ff',
        style: {
          outlineColor: '#6b73ff',
          backgroundColor: '#6b73ff',
        },
      },{
        name: '#ff7af5',
        style: {
          outlineColor: '#ff7af5',
          backgroundColor: '#ff7af5',
        },
      },{
        name: '#ffe985',
        style: {
          outlineColor: '#ffe985',
          backgroundColor: '#ffe985',
        },
      },{
        name: '#ffa6b7',
        style: {
          outlineColor: '#ffa6b7',
          backgroundColor: '#ffa6b7',
        },
      },{
        name: '#ffaa85',
        style: {
          outlineColor: '#ffaa85',
          backgroundColor: '#ffaa85',
        },
      },{
        name: '#72edf2',
        style: {
          outlineColor: '#72edf2',
          backgroundColor: '#72edf2',
        },
      },{
        name: '#ff9d6c',
        style: {
          outlineColor: '#ff9d6c',
          backgroundColor: '#ff9d6c',
        },
      },{
        name: '#f6d242',
        style: {
          outlineColor: '#f6d242',
          backgroundColor: '#f6d242',
        },
      },{
        name: '#69ff97',
        style: {
          outlineColor: '#69ff97',
          backgroundColor: '#69ff97',
        },
      },{
        name: '#3b2667',
        style: {
          outlineColor: '#3b2667',
          backgroundColor: '#3b2667',
        },
      },{
        name: '#70f570',
        style: {
          outlineColor: '#70f570',
          backgroundColor: '#70f570',
        },
      },{
        name: '#3c8ce7',
        style: {
          outlineColor: '#3c8ce7',
          backgroundColor: '#3c8ce7',
        },
      },{
        name: '#fab2ff',
        style: {
          outlineColor: '#fab2ff',
          backgroundColor: '#fab2ff',
        },
      }],
    },
    gradient: {
      field: 'gradient',
      label: app.fire('i18n', 'gradient'),
      data: [{
        name:'gradient',
        value:'linear-gradient(135deg, #abdcff 10%, #0396ff 100%)',
        style: {
          outlineColor: '#abdcff',
          background: 'linear-gradient(135deg, #abdcff 10%, #0396ff 100%)',
        }
      },{
        name:'gradient1',
        value:'linear-gradient(135deg, #feb692 10%, #ea5455 100%)',
        style: {
          outlineColor: '#feb692',
          background: 'linear-gradient(135deg, #feb692 10%, #ea5455 100%)',
        }
      },{
        name: 'gradient2',
        value: 'linear-gradient(135deg, #ce9ffc 10%, #7367f0 100%)',
        style: {
          outlineColor: '#ce9ffc',
          background: 'linear-gradient(135deg, #ce9ffc 10%, #7367f0 100%)',
        },
      },
      {
        name: 'gradient3',
        value: 'linear-gradient(135deg, #90f7ec 10%, #32ccbc 100%)',
        style: {
          outlineColor: '#90f7ec',
          background: 'linear-gradient(135deg, #90f7ec 10%, #32ccbc 100%)',
        },
      },{
        name: 'gradient4',
        value: 'linear-gradient(135deg, #fff6b7 10%, #f6416c 100%)',
        style: {
          outlineColor: '#fff6b7',
          background: 'linear-gradient(135deg, #fff6b7 10%, #f6416c 100%)',
        },
      },{
        name: 'gradient5',
        value: 'linear-gradient(135deg, #81fbb8 10%, #28c76f 100%)',
        style: {
          outlineColor: '#81fbb8',
          background: 'linear-gradient(135deg, #81fbb8 10%, #28c76f 100%)',
        },
      },{
        name: 'gradient6',
        value: 'linear-gradient(135deg, #e2b0ff 10%, #9f44d3 100%)',
        style: {
          outlineColor: '#e2b0ff',
          background: 'linear-gradient(135deg, #e2b0ff 10%, #9f44d3 100%)',
        },
      },{
        name: 'gradient7',
        value: 'linear-gradient(135deg, #f97794 10%, #623aa2 100%)',
        style: {
          outlineColor: '#f97794',
          background: 'linear-gradient(135deg, #f97794 10%, #623aa2 100%)',
        },
      },{
        name: 'gradient8',
        value: 'linear-gradient(135deg, #fccf31 10%, #f55555 100%)',
        style: {
          outlineColor: '#fccf31',
          background: 'linear-gradient(135deg, #fccf31 10%, #f55555 100%)',
        },
      },{
        name: 'gradient9',
        value: 'linear-gradient(135deg, #f761a1 10%, #8c1bab 100%)',
        style: {
          outlineColor: '#f761a1',
          background: 'linear-gradient(135deg, #f761a1 10%, #8c1bab 100%)',
        },
      },{
        name: 'gradient10',
        value: 'linear-gradient(135deg, #43cbff 10%, #9708cc 100%)',
        style: {
          outlineColor: '#43cbff',
          background: 'linear-gradient(135deg, #43cbff 10%, #9708cc 100%)',
        },
      },{
        name: 'gradient11',
        value: 'linear-gradient(135deg, #5efce8 10%, #736efe 100%)',
        style: {
          outlineColor: '#5efce8',
          background: 'linear-gradient(135deg, #5efce8 10%, #736efe 100%)',
        },
      },{
        name: 'gradient12',
        value: 'linear-gradient(135deg, #fad7a1 10%, #e96d71 100%)',
        style: {
          outlineColor: '#fad7a1',
          background: 'linear-gradient(135deg, #fad7a1 10%, #e96d71 100%)',
        },
      },{
        name: 'gradient13',
        value: 'linear-gradient(135deg, #ffd26f 10%, #3677ff 100%)',
        style: {
          outlineColor: '#ffd26f',
          background: 'linear-gradient(135deg, #ffd26f 10%, #3677ff 100%)',
        },
      },{
        name: 'gradient14',
        value: 'linear-gradient(135deg, #a0fe65 10%, #fa016d 100%)',
        style: {
          outlineColor: '#a0fe65',
          background: 'linear-gradient(135deg, #a0fe65 10%, #fa016d 100%)',
        },
      },{
        name: 'gradient15',
        value: 'linear-gradient(135deg, #ffdb01 10%, #0e197d 100%)',
        style: {
          outlineColor: '#ffdb01',
          background: 'linear-gradient(135deg, #ffdb01 10%, #0e197d 100%)',
        },
      },{
        name: 'gradient16',
        value: 'linear-gradient(135deg, #fec163 10%, #de4313 100%)',
        style: {
          outlineColor: '#fec163',
          background: 'linear-gradient(135deg, #fec163 10%, #de4313 100%)',
        },
      },{
        name: 'gradient17',
        value: 'linear-gradient(135deg, #92ffc0 10%, #002661 100%)',
        style: {
          outlineColor: '#92ffc0',
          background: 'linear-gradient(135deg, #92ffc0 10%, #002661 100%)',
        },
      },{
        name: 'gradient18',
        value: 'linear-gradient(135deg, #eead92 10%, #6018dc 100%)',
        style: {
          outlineColor: '#eead92',
          background: 'linear-gradient(135deg, #eead92 10%, #6018dc 100%)',
        },
      },{
        name: 'gradient19',
        value: 'linear-gradient(135deg, #f6ceec 10%, #d939cd 100%)',
        style: {
          outlineColor: '#f6ceec',
          background: 'linear-gradient(135deg, #f6ceec 10%, #d939cd 100%)',
        },
      },{
        name: 'gradient20',
        value: 'linear-gradient(135deg, #52e5e7 10%, #130cb7 100%)',
        style: {
          outlineColor: '#52e5e7',
          background: 'linear-gradient(135deg, #52e5e7 10%, #130cb7 100%)',
        },
      },{
        name: 'gradient21',
        value: 'linear-gradient(135deg, #f1ca74 10%, #a64db6 100%)',
        style: {
          outlineColor: '#f1ca74',
          background: 'linear-gradient(135deg, #f1ca74 10%, #a64db6 100%)',
        },
      },{
        name: 'gradient22',
        value: 'linear-gradient(135deg, #e8d07a 10%, #5312d6 100%)',
        style: {
          outlineColor: '#e8d07a',
          background: 'linear-gradient(135deg, #e8d07a 10%, #5312d6 100%)',
        },
      },{
        name: 'gradient23',
        value: 'linear-gradient(135deg, #eece13 10%, #b210ff 100%)',
        style: {
          outlineColor: '#eece13',
          background: 'linear-gradient(135deg, #eece13 10%, #b210ff 100%)',
        },
      },{
        name: 'gradient24',
        value: 'linear-gradient(135deg, #79f1a4 10%, #0e5cad 100%)',
        style: {
          outlineColor: '#79f1a4',
          background: 'linear-gradient(135deg, #79f1a4 10%, #0e5cad 100%)',
        },
      },{
        name: 'gradient25',
        value: 'linear-gradient(135deg, #fdd819 10%, #e80505 100%)',
        style: {
          outlineColor: '#fdd819',
          background: 'linear-gradient(135deg, #fdd819 10%, #e80505 100%)',
        },
      },{
        name: 'gradient26',
        value: 'linear-gradient(135deg, #fff3b0 10%, #ca26ff 100%)',
        style: {
          outlineColor: '#fff3b0',
          background: 'linear-gradient(135deg, #fff3b0 10%, #ca26ff 100%)',
        },
      },{
        name: 'gradient27',
        value: 'linear-gradient(135deg, #fff5c3 10%, #9452a5 100%)',
        style: {
          outlineColor: '#fff5c3',
          background: 'linear-gradient(135deg, #fff5c3 10%, #9452a5 100%)',
        },
      },{
        name: 'gradient28',
        value: 'linear-gradient(135deg, #f05f57 10%, #360940 100%)',
        style: {
          outlineColor: '#f05f57',
          background: 'linear-gradient(135deg, #f05f57 10%, #360940 100%)',
        },
      },{
        name: 'gradient29',
        value: 'linear-gradient(135deg, #2afadf 10%, #4c83ff 100%)',
        style: {
          outlineColor: '#2afadf',
          background: 'linear-gradient(135deg, #2afadf 10%, #4c83ff 100%)',
        },
      },{
        name: 'gradient30',
        value: 'linear-gradient(135deg, #fff886 10%, #f072b6 100%)',
        style: {
          outlineColor: '#fff886',
          background: 'linear-gradient(135deg, #fff886 10%, #f072b6 100%)',
        },
      },{
        name: 'gradient31',
        value: 'linear-gradient(135deg, #97abff 10%, #123597 100%)',
        style: {
          outlineColor: '#97abff',
          background: 'linear-gradient(135deg, #97abff 10%, #123597 100%)',
        },
      },{
        name: 'gradient32',
        value: 'linear-gradient(135deg, #f5cbff 10%, #c346c2 100%)',
        style: {
          outlineColor: '#f5cbff',
          background: 'linear-gradient(135deg, #f5cbff 10%, #c346c2 100%)',
        },
      },{
        name: 'gradient33',
        value: 'linear-gradient(135deg, #fff720 10%, #3cd500 100%)',
        style: {
          outlineColor: '#fff720',
          background: 'linear-gradient(135deg, #fff720 10%, #3cd500 100%)',
        },
      },{
        name: 'gradient34',
        value: 'linear-gradient(135deg, #ff6fd8 10%, #3813c2 100%)',
        style: {
          outlineColor: '#ff6fd8',
          background: 'linear-gradient(135deg, #ff6fd8 10%, #3813c2 100%)',
        },
      },{
        name: 'gradient35',
        value: 'linear-gradient(135deg, #ee9ae5 10%, #5961f9 100%)',
        style: {
          outlineColor: '#ee9ae5',
          background: 'linear-gradient(135deg, #ee9ae5 10%, #5961f9 100%)',
        },
      },{
        name: 'gradient36',
        value: 'linear-gradient(135deg, #ffd3a5 10%, #fd6585 100%)',
        style: {
          outlineColor: '#ffd3a5',
          background: 'linear-gradient(135deg, #ffd3a5 10%, #fd6585 100%)',
        },
      },{
        name: 'gradient37',
        value: 'linear-gradient(135deg, #c2ffd8 10%, #465efb 100%)',
        style: {
          outlineColor: '#c2ffd8',
          background: 'linear-gradient(135deg, #c2ffd8 10%, #465efb 100%)',
        },
      },
      {
        name: 'gradient38',
        value: 'linear-gradient(135deg, #fd6585 10%, #0d25b9 100%)',
        style: {
          outlineColor: '#fd6585',
          background: 'linear-gradient(135deg, #fd6585 10%, #0d25b9 100%)',
        },
      },{
        name: 'gradient39',
        value: 'linear-gradient(135deg, #fd6e6a 10%, #ffc600 100%)',
        style: {
          outlineColor: '#fd6e6a',
          background: 'linear-gradient(135deg, #fd6e6a 10%, #ffc600 100%)',
        },
      },{
        name: 'gradient40',
        value: 'linear-gradient(135deg, #65fdf0 10%, #1d6fa3 100%)',
        style: {
          outlineColor: '#65fdf0',
          background: 'linear-gradient(135deg, #65fdf0 10%, #1d6fa3 100%)',
        },
      },{
        name: 'gradient41',
        value: 'linear-gradient(135deg, #ff7af5 10%, #513162 100%)',
        style: {
          outlineColor: '#ff7af5',
          background: 'linear-gradient(135deg, #ff7af5 10%, #513162 100%)',
        },
      },{
        name: 'gradient42',
        value: 'linear-gradient(135deg, #f0ff00 10%, #58cffb 100%)',
        style: {
          outlineColor: '#f0ff00',
          background: 'linear-gradient(135deg, #f0ff00 10%, #58cffb 100%)',
        },
      },{
        name: 'gradient43',
        value: 'linear-gradient(135deg, #ffe985 10%, #fa742b 100%)',
        style: {
          outlineColor: '#ffe985',
          background: 'linear-gradient(135deg, #ffe985 10%, #fa742b 100%)',
        },
      },{
        name: 'gradient44',
        value: 'linear-gradient(135deg, #ffa6b7 10%, #1e2ad2 100%)',
        style: {
          outlineColor: '#ffa6b7',
          background: 'linear-gradient(135deg, #ffa6b7 10%, #1e2ad2 100%)',
        },
      },{
        name: 'gradient45',
        value: 'linear-gradient(135deg, #ffaa85 10%, #b3315f 100%)',
        style: {
          outlineColor: '#ffaa85',
          background: 'linear-gradient(135deg, #ffaa85 10%, #b3315f 100%)',
        },
      },{
        name: 'gradient46',
        value: 'linear-gradient(135deg, #72edf2 10%, #5151e5 100%)',
        style: {
          outlineColor: '#72edf2',
          background: 'linear-gradient(135deg, #72edf2 10%, #5151e5 100%)',
        },
      },{
        name: 'gradient47',
        value: 'linear-gradient(135deg, #ff9d6c 10%, #bb4e75 100%)',
        style: {
          outlineColor: '#ff9d6c',
          background: 'linear-gradient(135deg, #ff9d6c 10%, #bb4e75 100%)',
        },
      },{
        name: 'gradient48',
        value: 'linear-gradient(135deg, #f6d242 10%, #ff52e5 100%)',
        style: {
          outlineColor: '#f6d242',
          background: 'linear-gradient(135deg, #f6d242 10%, #ff52e5 100%)',
        },
      },{
        name: 'gradient49',
        value: 'linear-gradient(135deg, #69ff97 10%, #00e4ff 100%)',
        style: {
          outlineColor: '#69ff97',
          background: 'linear-gradient(135deg, #69ff97 10%, #00e4ff 100%)',
        },
      },{
        name: 'gradient50',
        value: 'linear-gradient(135deg, #3b2667 10%, #bc78ec 100%)',
        style: {
          outlineColor: '#3b2667',
          background: 'linear-gradient(135deg, #3b2667 10%, #bc78ec 100%)',
        },
      },{
        name: 'gradient51',
        value: 'linear-gradient(135deg, #3c8ce7 10%, #00eaff 100%)',
        style: {
          outlineColor: '#3c8ce7',
          background: 'linear-gradient(135deg, #3c8ce7 10%, #00eaff 100%)',
        },
      },{
        name: 'gradient52',
        value: 'linear-gradient(135deg, #fab2ff 10%, #1904e5 100%)',
        style: {
          outlineColor: '#fab2ff',
          background: 'linear-gradient(135deg, #fab2ff 10%, #1904e5 100%)',
        },
      },{
        name: 'custom',
      }],
      color: [{
        label: app.fire('i18n', 'start'),
        field: 'start',
      },{
        label: app.fire('i18n', 'end'),
        field: 'end',
      }],
      angle: {
        max: 360,
        unit: 'deg',
        field: 'angle',
        label: app.fire('i18n', 'angle'),
        defaultValue: 0,
      }
    },
    light: {
      label: app.fire('i18n', 'light'),
      field: 'light',
    },
    dark: {
      label: app.fire('i18n', 'dark'),
      field: 'dark',
    },
    night: {
      label: app.fire('i18n', 'night'),
      field: 'night',
      tooltip: app.fire('i18n', 'night_tooltip'),
      defaultValue: false,
    }
  };
}
