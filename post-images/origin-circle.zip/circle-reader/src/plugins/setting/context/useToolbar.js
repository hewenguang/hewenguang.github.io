// import { useContext } from 'react';
// import { AppContext } from 'app/context';

export default function useToolbar(){
  // const app = useContext(AppContext);

  return {
    field:'toolbar',
    data: {
      distance: {
        max: 100,
        min: 0,
        unit:'px',
        label:'间距',
        field:'distance',
        defaultValue: 40,
      },
      item: {
        max: 20,
        min: 6,
        unit:'px',
        label:'项间距',
        field:'item',
        defaultValue: 10,
      },
      // group: {
      //   max:40,
      //   unit:'px',
      //   label:'组间距',
      //   field:'group',
      //   defaultValue: 12,
      // }
    },
  };
}

