import React from 'react';
import ReactDOM from 'react-dom';
import Drawer from 'app/components/drawer';
import controller from './controller';
import Entry from './entry';
import './index.less';

App.register('setting', ['shadow', 'dom', 'utils'], function(shadow, dom){
  const app = this;
  const root = dom.create('div');
  shadow({
    mode: 'open', // closed 会导致 antd select 打不开
    style: [
      'plugins/antd/index.css',
      'plugins/setting/index.css',
    ],
    onReady: function(shadowRoot){
      shadowRoot.appendChild(root);
    },
  });

  controller(app, root);

  ReactDOM.render((
    <Drawer
      app={app}
      size="small"
      plugin="setting"
    >
      <Entry root={root} />
    </Drawer>
  ), root);
});
