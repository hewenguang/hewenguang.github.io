App.register('utils', function(){
  const app = this;
  const timer = {};

  window.utils = {
    location(url){
      return new URL(url.startsWith('http') ? url : `http://${url}`);
    },
    isUndefined(value){
      return app.type(value, 'Undefined');
    },
    isString(value){
      return app.type(value, 'String');
    },
    isNumber(value){
      return app.type(value, 'Number');
    },
    isBoolean(value){
      return app.type(value, 'Boolean');
    },
    isArray(value){
      return app.type(value, 'Array');
    },
    isFunction(value){
      return app.type(value, 'Function');
    },
    isElement(value){
      return value && value.nodeType === 1 && !this.isPlainObject(value);
    },
    isTextNode(value){
      return app.type(value, 'Text');
    },
    isObject(value) {
      return app.type(value, 'Object');
    },
    isPlainObject(value) {
      if (!this.isObject(value)){
        return false;
      }
      const proto = Object.getPrototypeOf(value);
      if (proto === null) {
        return true;
      }
      const Ctor = hasOwnProperty.call(proto, 'constructor') && proto.constructor;
      return typeof Ctor == 'function' && Ctor instanceof Ctor && Function.prototype.toString.call(Ctor) === Function.prototype.toString.call(Object);
    },
    isEqualObject(current, next){
      if(!this.isPlainObject(current)){
        return current === next;
      }
      const nextKeys = Object.keys(next);
      const currentKeys = Object.keys(current);
      if (currentKeys.length != nextKeys.length) {
        return false;
      }
      let equal = true;
      this.each(current, (item, key) => {
        if(this.isPlainObject(item)){
          if(JSON.stringify(item) !== JSON.stringify(next[key])){
            equal = false;
            return true;
          }
        } else {
          if(item !== next[key]){
            equal = false;
            return true;
          }
        }
      });
      return equal;
    },
    length(text){
      if(!this.isString(text) || text.trim().length <= 0){
        return 0;
      }
      return /[\u4e00-\u9fa5]/.test(text) ? text.length : text.split(' ').length;
    },
    toLower(value){
      return this.isString(value) ? value.toLowerCase() : '';
    },
    each(value, callback){
      if(this.isUndefined(value) || !this.isFunction(callback)){
        return;
      }
      let index = 0;
      if(value.forEach){
        const length = value.length;
        if(length <= 0){
          return;
        }
        while(index < length && !callback(value[index], index)){
          index ++;
        }
      } else {
        const keys = Object.keys(value);
        const length = keys.length;
        if(length <= 0){
          return;
        }
        while(index < length && !callback(value[keys[index]], keys[index])){
          index ++;
        }
      }
    },
    filter(value, callback){
      if(!this.isFunction(callback)){
        return;
      }
      if(this.isArray(value)){
        return value.filter(callback);
      }
      const object = {};
      this.each(value, (item, key) => {
        if(callback(item, key)){
          object[key] = item;
        }
      });
      return object;
    },
    // rgb2hex(color){
    //   return '#' + [color[0], color[1], color[2]].map(x => x.toString(16).padStart(2, '0')).join('');
    // },
    hex2rgb(hex){
      if(this.isString(hex) && hex.length === 7 && hex.startsWith('#')){
        const color = hex.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i,function(m, r, g, b){
          return '#' + r + r + g + g + b + b;
        }).substring(1).match(/.{2}/g).map(x => parseInt(x, 16));
        return {
          r:color[0],
          g:color[1],
          b:color[2],
        };
      }
      return {
        r:255,
        g:255,
        b:255,
      };
    },
    utoa(value){
      return window.btoa(unescape(encodeURIComponent(value)));
    },
    // atou(value){
    //   return decodeURIComponent(escape(window.atob(value)));
    // },
    lazy(callback){
      callback && setTimeout(callback, 0);
    },
    wait(callback, time = 500){
      const name = this.utoa(`_${callback.toString()}`);
      timer[name] && clearTimeout(timer[name]);
      timer[name] = setTimeout(function(){
        callback();
        delete timer[name];
      }, time);
    }
  };
  return window.utils;
});
