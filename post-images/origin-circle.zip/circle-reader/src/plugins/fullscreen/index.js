App.register('fullscreen', function(){
  const app = this;
  document.documentElement.addEventListener('fullscreenchange', function(){
    app.fire('fullscreenchange', !!document.fullscreenElement);
  });
  app.on('fullscreen', function(){
    document.documentElement.requestFullscreen();
  });
  app.on('fullscreen-exit', function(){
    document.exitFullscreen();
  });
  app.fire('fullscreen');
});
