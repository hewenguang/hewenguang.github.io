App.register('copy', 'dom', function(dom){
  const app = this;
  app.on('copy', function(node){
    const type = dom.copy(node) ? 'success' : 'fail';
    app.fire('message', {
      type,
      duration: 1,
      key: `copy_${type}`,
      message: app.fire('i18n', `copy_${type}`),
    });
    app.fire('send', 'analytics', {event:'copy'});
  });
  app.fire('copy', app.fire('dom-container'));
});
