import { Space } from 'antd';
import Icon from 'app/components/icon';
import useApp from 'app/context/useApp';
import Speed from './components/speed';
import React, { useState, useEffect } from 'react';

export default function(){
  const app = useApp();
  const [ scrolling, setScrolling ] = useState(true);

  useEffect(() => {
    const hook = app.on('scrollpage-scrolling', function(doing){
      setScrolling(doing);
    });
    return () => {
      app.remove(hook);
    };
  }, []);

  useEffect(() => {
    const hook = app.on('srt-togglescrollpage', function(){
      app.fire(scrolling ? 'scrollpage-pause' : 'scrollpage-play');
      setScrolling(!scrolling);
      app.fire('scrollpage-focus');
    });
    return () => {
      app.remove(hook);
    };
  }, [ scrolling ]);

  return (
    <Space style={{paddingTop:3}}>
      <Icon
        size="large"
        tabIndex={0}
        style={{display:'block'}}
        className="togglescrollpage"
        name={scrolling ? 'pause' : 'play'}
        onClick={event => {
          event.stopPropagation();
          event.preventDefault();
          app.fire('srt-togglescrollpage');
          app.fire('send', 'analytics', {event:'scroll-toggle'});
        }}
      />
      <Speed
        onChange={speed => {
          app.cache('scrollpage-speed', speed);
          scrolling && app.fire('scrollpage-play');
          app.fire('send', 'analytics', {event:`scroll-speed-${speed}`});
        }}
      />
    </Space>
  );
}
