import React from 'react';
import { Radio } from 'antd';
import useApp from 'app/context/useApp';
import useOption from 'app/context/useOption';

export default function(props){
  const { onChange } = props;
  const app = useApp();
  const [ option, change ] = useOption({
    field: 'scrollpage-speed',
    defaultValue: 7,
  });

  return (
    <Radio.Group
      size="small"
      value={option}
      buttonStyle="solid"
      optionType="button"
      onChange={event => {
        const speed = event.target.value;
        change(speed);
        onChange && onChange(speed);
      }}
      options={[{
        label: app.fire('i18n', 'slower'),
        value: 3,
      },{
        label: app.fire('i18n', 'slow'),
        value: 5,
      },{
        label: app.fire('i18n', 'routine'),
        value: 7,
      },{
        label: app.fire('i18n', 'fast'),
        value: 10,
      },{
        label: app.fire('i18n', 'faster'),
        value: 15,
      }]}
    />
  );
}
