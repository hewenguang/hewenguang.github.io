import React from 'react';
import ReactDOM from 'react-dom';
import controller from './controller';
import Drawer from 'app/components/drawer';
import Entry from './entry';

App.register('scrollpage', ['shadow', 'dom', 'utils'], function(shadow, dom){
  const app = this;
  const root = dom.create('div');
  shadow({
    style: [
      'plugins/antd/index.css',
      'plugins/scrollpage/index.css',
    ],
    onReady: function(shadowRoot){
      shadowRoot.appendChild(root);
    },
  });

  controller(app, root);

  ReactDOM.render((
    <Drawer
      app={app}
      type="toolbar"
      plugin="scrollpage"
    >
      <Entry />
    </Drawer>
  ), root);
});
