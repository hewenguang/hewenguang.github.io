export default function(app, root){
  app.on('render-start-done', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('render-destory-done', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-before', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-after', function(){
    dom.setStyle(root, 'display', 'block');
  });

  let timer;
  let wheeltimer;
  document.addEventListener('mousewheel', function(){
    if(!app.cache('running')){
      return;
    }
    const scrolling = !!timer;
    app.fire('scrollpage-pause');
    if(!scrolling){
      return;
    }
    wheeltimer && clearTimeout(wheeltimer);
    wheeltimer = setTimeout(function(){
      app.fire('scrollpage-play');
   }, 250);
  });
  app.on('scrollpage-play', function(){
    app.fire('scrollpage-scrolling', true);
    const speed = app.cache('scrollpage-speed') || 7;
    let top = dom.scrollTop();
    const left = document.documentElement.scrollLeft;
    const height = document.documentElement.scrollHeight - window.innerHeight;
    timer && clearInterval(timer);
    timer = setInterval(() => {
      if(top >= height){
        app.fire('scrollpage-pause');
      } else {
        top++;
        window.scrollTo(left, top);
      }
    }, Math.ceil(300 / speed));
  });
  app.on('scrollpage-pause', function(){
    app.fire('scrollpage-scrolling', false);
    if(!timer){
      return;
    }
    clearInterval(timer);
    timer = null;
  });
  app.on('render-destory-done', function(){
    app.fire('scrollpage-pause');
  });
  app.on('scrollpage-focus', function(){
    const target = root.querySelector('.togglescrollpage');
    target && target.focus && target.focus();
  });
  app.on('scrollpage-change', function(visible){
    if(visible){
      app.fire('toolbar-key', 'srt-scrollpage');
      app.fire('scrollpage-focus');
      app.fire('send', 'db', {
        execute: 'get',
        table: 'wrench',
        name: 'scrollpage-speed',
      }, ({error, data}) => {
        if(error){
          app.fire('error', error);
        } else {
          app.cache('scrollpage-speed', data);
          app.fire('scrollpage-play');
        }
      });
    } else {
      app.fire('scrollpage-pause');
      app.fire('toolbar-key', '');
    }
  });
  app.fire('scrollpage-change');
}
