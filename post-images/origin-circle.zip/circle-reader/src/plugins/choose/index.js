App.register('choose', ['utils', 'dom'], function(utils, dom){
  const app = this;
  app.on('choose', function(root, cbClick, cbMouseover){
    if(!root){
      return;
    }
    const className = 'circle-choose';
    const stylesheet = dom.create('style', {
      textContent:`
        .${className}{
          background:#ddd !important;
          cursor:pointer !important;
          outline:3px dashed #777 !important;
        }
      `,
    });
    function handleMouseover(event){
      const target = event.target;
      const fromTarget = event.fromElement || event.relatedTarget;
      utils.isElement(fromTarget) && fromTarget.classList.remove(className);
      if(cbMouseover){
        !cbMouseover(target) && target.classList.add(className);
      } else {
        target.classList.add(className);
      }
    }
    function handleClick(event){
      event.stopPropagation();
      event.preventDefault();
      if(!cbClick){
        return;
      }
      const target = event.target;
      if(cbMouseover){
        !cbMouseover(target) && cbClick(target);
      } else {
        cbClick(target);
      }
    }

    root.appendChild(stylesheet);
    root.addEventListener('click', handleClick);
    root.addEventListener('mouseover', handleMouseover);

    return function(){
      dom.remove(stylesheet);
      root.removeEventListener('click', handleClick);
      root.removeEventListener('mouseover', handleMouseover);
      utils.each(root.querySelectorAll(`.${className}`), function(node){
        node.classList.remove(className);
      });
    };
  });
});

