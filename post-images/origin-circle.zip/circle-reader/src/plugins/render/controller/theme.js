export default function(app, root){
  const html = document.documentElement;
  app.on('theme', function(value, key){
    if(utils.isUndefined(value)){
      return;
    }
    utils.each(utils.isPlainObject(value) ? value : {
      [key]: value,
    }, (style, styleKey) => {
      if(style === 'reset'){
        root.style.removeProperty(`--${styleKey}`);
      } else {
        if(['autohide', 'itemspace', 'groupspace', 'column'].includes(styleKey)){
          return;
        }
        switch(styleKey){
          case 'imagealign':
            if(style === 'left'){
              root.style.setProperty('--imageleft', 0);
              root.style.setProperty('--imageright', 0);
            } else if(style === 'center'){
              root.style.setProperty('--imageleft', 'auto');
              root.style.setProperty('--imageright', 'auto');
            } else if(style === 'right'){
              root.style.setProperty('--imageleft', 'auto');
              root.style.setProperty('--imageright', 0);
            }
            break;
          case 'imagehide':
            root.style.setProperty('--imagehide', style ? 'none': 'block');
            break;
          case 'bg':
            if(utils.isString(style) && style.startsWith('#')){
              const canvasValue = [];
              utils.each(utils.hex2rgb(style), function(item, key){
                const value = item - 18;
                const itemValue = value < 0 ? 0 : value;
                canvasValue.push(itemValue);
                root.style.setProperty(`--${styleKey}-${key}`, itemValue);
              });
              root.style.setProperty('--canvas', style);
              root.style.setProperty(`--${styleKey}`, `rgb(${canvasValue.join(', ')})`);
            } else if(utils.isString(style) && style.startsWith('linear')){
              const linear = style.replace(/linear-gradient\((.*?)\)/, '$1').split(',').map(item => item.trim().split(' ').shift());
              if(linear && linear.length === 3){
                utils.each(utils.hex2rgb(linear[1]), function(item, key){
                  const value = item - 18;
                  const itemValue = value < 0 ? 0 : value;
                  root.style.setProperty(`--${styleKey}-${key}`, itemValue);
                });
                root.style.setProperty('--canvas', 'transparent');
                root.style.setProperty(`--${styleKey}`, `${style} fixed`);
              }
            } else {
              root.style.setProperty(`--${styleKey}-r`, 237);
              root.style.setProperty(`--${styleKey}-g`, 237);
              root.style.setProperty(`--${styleKey}-b`, 237);
              root.style.setProperty('--canvas', 'transparent');
              root.style.setProperty(`--${styleKey}`, `center/cover no-repeat fixed url("${style}")`);
            }
            break;
          case 'track':
          case 'radius':
          case 'thumb':
            html.style.setProperty(`--circle-${styleKey}`, style);
            break;
          default:
            root.style.setProperty(`--${styleKey}`, style);
        }
      }
    });
  });
  app.on('setting-theme', function(name){
    app.fire('send', 'db', {
      name: 'night',
      execute: 'get',
      table: 'wrench',
    }, function({error, data}){
      if(error){
        app.fire('error', error);
      } else {
        // 设置所见即所得主题
        let theme = 'skin';
        if(utils.isString(name)){
          theme = name;
        } else {
          theme = utils.isBoolean(data) && data ? app.fire('color-scheme') : 'skin';
        }
        app.fire('send', 'db', {
          name: theme,
          execute: 'get',
          table: 'setting',
        }, function({error, data}){
          if(error){
            app.fire('error', error);
          } else {
            data && app.fire('theme', data);
          }
        });
      }
    });
  });
  // 高亮展示内容
  const container = app.fire('dom-container');
  app.on('hightlight', function(node, className = 'hightlight'){
    const add = utils.isElement(node);
    utils.each(container.querySelectorAll(`.${className}`), function(item){
      if(add){
        item !== node && item.classList.remove(className);
      } else {
        item.classList.remove(className);
      }
    });
    add && !node.classList.contains(className) && node.classList.add(className);
  });
}
