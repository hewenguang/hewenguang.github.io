export default function(app){
  // 退出快捷键(工具栏共用)
  app.on('srt-exit', function(){
    app.fire('render-destory');
  });
  // 退出并关闭网页
  app.on('srt-exitclose', function(){
    app.fire('send', 'tab', {action: 'query'}, function({error, data}){
      if(error){
        app.fire('error', error);
        return;
      }
      utils.isArray(data) && data.length === 1 && app.fire('send', 'tab', {action: 'create', value: {active: true}});
      app.fire('send', 'tab', {action: 'remove'});
    });
  });
  // 全屏快捷键
  app.on('srt-fullscreen', function(){
    app.fire('windows_state', function(state){
      app.fire('fullscreentoggle', state !== 'fullscreen');
    });
  });
  // 跳转到顶部
  app.on('srt-top', function(){
    window.scrollTo({
      top:0,
      left:0,
      behavior: 'smooth',
    });
  });
  // 跳转到底部
  app.on('srt-bottom', function(){
    window.scrollTo({
      left:0,
      behavior: 'smooth',
      top:document.documentElement.scrollHeight,
    });
  });
  // 纸张效果快捷键(全部切换)
  app.on('srt-paper', function(){
    app.fire('send', 'db', {
      name: 'paper',
      execute: 'get',
      table: 'wrench',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
        return;
      }
      app.fire('send', 'db', {
        name:'paper',
        execute: 'add',
        table:'wrench',
        value: !data,
      }, ({error}) => {
        if(error){
          app.fire('error', error);
        } else {
          app.fire('paper', !data);
        }
      });
    });
  });
  // 无图模式
  app.on('srt-imagehide', function(){
    app.fire('send', 'db', {
      name: 'style',
      execute: 'get',
      table: 'setting',
    }, ({error, data = {}}) => {
      if(error){
        app.fire('error', error);
        return;
      }
      const hidden = !data.imagehide;
      data.imagehide = hidden;
      app.fire('send', 'db', {
        name:'style',
        execute:'add',
        table:'setting',
        value: data,
      }, ({error}) => {
        if(error){
          app.fire('error', error);
        } else {
          app.fire('theme', hidden, 'imagehide');
        }
      });
    });
  });
  // 加载模块
  [
    'srt-help',
    'srt-scrollpage',
    'srt-speak',
    'srt-word',
    'srt-image',
    'srt-text',
    'srt-marked',
    'srt-mail',
    'srt-lnk',
    'srt-search',
    'srt-edit',
    'srt-remove',
    'srt-copy',
    'srt-feedback',
    'srt-setting',
    'srt-wrench',
  ].forEach(function(hook){
    app.on(hook, function(){
      const name = hook.split('-').pop();
      app.fire(name);
      app.load(name);
    });
  });
  // 调整页面
  [
    'srt-style',
    'srt-skin',
    'srt-layout',
    'srt-toolbar',
  ].forEach(function(hook){
    app.on(hook, function(){
      app.fire('setting');
      app.load('setting', function(){
        const name = hook.split('-').pop();
        app.fire('guide', name, name);
      });
    });
  });
  // 偏好设置
  [
    'srt-basic',
    'srt-manage-whitelist',
    'srt-manage-blacklist',
    'srt-shortcut',
    'srt-contextmenu',
    'srt-config',
    'srt-stylesheet',
    'srt-links',
  ].forEach(function(hook){
    app.on(hook, function(){
      app.fire('wrench');
      app.load('wrench', function(){
        const name = hook.split('-').pop();
        app.fire('guide', name, name);
      });
    });
  });
}
