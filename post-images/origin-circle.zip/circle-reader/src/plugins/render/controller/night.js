export default function(app){
  const mediaQueryListDark = window.matchMedia('(prefers-color-scheme: dark)');
  // 跟随系统切换主题
  mediaQueryListDark.addEventListener('change', function(mediaQueryListEvent){
    if(!app.cache('running')){
      return;
    }
    app.fire('send', 'db', {
      name: 'night',
      execute: 'get',
      table: 'wrench',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        if(utils.isBoolean(data) & data){
          app.fire('send', 'db', {
            table: 'setting',
            execute: 'get',
            name: mediaQueryListEvent.matches ? 'dark' : 'light',
          }, ({error, data}) => {
            if(error){
              app.fire('error', error);
            } else {
              app.fire('theme', data);      
            }
          });
        }
      }
    });
  });
  app.on('color-scheme', mediaQueryListDark.matches ? 'dark' : 'light');
}
