import theme from './theme';
import night from './night';
import render from './render';
import print from './print';
import shortcut from './shortcut';
import fullscreen from './fullscreen';

export default function(app, root){
  // 夜览支持
  night(app);
  // 主题支持
  theme(app, root);
  // 全屏幕
  fullscreen(app);
  // 渲染辅助
  render(app, root);
  // 打印支持
  print(app);
  // 快捷键
  shortcut(app);
}
