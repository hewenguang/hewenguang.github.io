export default function(app){
  app.on('windows_state', function(callback){
    app.fire('send', 'windows', {
      action: 'get',
    }, function({error, data}){
      if(error){
        app.fire('error', error);
        return;
      }
      callback && callback(data.state);
    });
  });
  app.on('fullscreentoggle', function(fullscreen){
    app.fire('send', 'windows', {
      action: 'update',
      state: fullscreen ? 'fullscreen' : 'normal',
    }, function({error}){
      if(error){
        app.fire('error', error);
        return;
      }
      app.fire('fullscreenchange', fullscreen);
    });
  });
  app.on('fullscreen', function(){
    app.fire('windows_state', function(state){
      state !== 'fullscreen' && app.fire('fullscreentoggle', true);
    });
  });
  app.on('fullscreen_exit', function(){
    app.fire('windows_state', function(state){
      state === 'fullscreen' && app.fire('fullscreentoggle', false);
    });
  });
  // onBoundsChanged 火狐不兼容
  app.on('resize', function(){
    app.fire('windows_state', function(state){
      if(!['fullscreen', 'normal'].includes(state)){
        return;
      }
      if(state === app.cache('fullscreen')){
        return;
      }
      app.cache('fullscreen', state);
      app.fire('fullscreenchange', state === 'fullscreen');
    });
  });
  // 初始就是全屏幕
  app.fire('windows_state', function(state){
    state === 'fullscreen' && app.fire('fullscreenchange', true);
  });
}
