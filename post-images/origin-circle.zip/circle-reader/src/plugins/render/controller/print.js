export default function(app){
  if (navigator.userAgent.indexOf('Firefox') >= 0){
    // Firefox
    window.addEventListener('beforeprint', function(){
      if(!app.cache('running')){
        return;
      }
      app.fire('pure-before');
    });
    window.addEventListener('afterprint', function(){
      if(!app.cache('running')){
        return;
      }
      app.fire('pure-after');
    });
  } else {
    const mediaQueryList = window.matchMedia('print');
    mediaQueryList.addEventListener('change', function(mql){
      if(!app.cache('running')){
        return;
      }
      if(mql.matches){
        app.fire('pure-before');
      } else {
        app.fire('pure-after');
      }
    });
  }
  // 打印
  app.on('srt-print', function(){
    app.fire('send', 'analytics', {event:'print'});
    window.print();
  });
}
