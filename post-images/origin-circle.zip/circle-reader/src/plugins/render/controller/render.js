export default function(app, root){
  const html = document.documentElement;
  app.on('pure-before', function(){
    if(!app.cache('running')){
      return;
    }
    root.classList.add('pure');
    html.classList.add('circle-pure');
  });
  app.on('pure-after', function(){
    if(!app.cache('running')){
      return;
    }
    root.classList.remove('pure');
    html.classList.remove('circle-pure');
  });
  app.on('render-start-done', function(){
    // 自动进入全屏
    app.fire('send', 'db', {
      table: 'wrench',
      execute: 'get',
      name: 'autofullscreen',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        data && app.fire('fullscreen');
      }
    });

    // 自动滚动
    app.fire('send', 'db', {
      table: 'wrench',
      execute: 'get',
      name: 'autoscroll',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        data && app.load('scrollpage');
      }
    });
  });
  app.on('render-destory-done', function(){
    // 多页解析退出后跳转到对应最后一页
    const lastnodeurl = app.cache('lastnodeurl');
    if(!lastnodeurl || lastnodeurl === location.href){
      return;
    }
    const hash = location.hash;
    location.href = `${lastnodeurl}${hash ? '/' : '#'}circle=off`;
  });
  function paper(){
    // 纸张效果
    app.fire('send', 'db', {
      name: 'paper',
      execute: 'get',
      table: 'wrench',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        app.fire('paper', !!data);
      }
    });
  }
  app.on('render-page-done', function(){

    // 纸张效果
    paper();

    // 主题设置
    app.fire('setting-theme');

    // 自定义样式
    app.fire('send', 'db', {
      execute: 'get',
      table: 'wrench',
      name: 'stylesheet',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        utils.isString(data) && data.length > 0 && app.fire('insert-style', data, true);
      }
    });

    // 滚动条样式
    app.fire('insert-style', `
      ::-webkit-scrollbar {
        width: var(--circle-track-width);
      }
      ::-webkit-scrollbar-track {
        background: var(--circle-track);
      }
      ::-webkit-scrollbar-thumb {
        border-radius: var(--circle-radius);
        background: var(--circle-thumb); 
      }
    `, true, true);

    // 工具栏
    app.load('toolbar');

    // 大纲
    app.fire('send', 'db', {
      name: 'outline',
      execute: 'get',
      table: 'wrench',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        data && app.load('anchor');
      }
    });
  
    // 返回顶部
    app.fire('send', 'db', {
      name: 'backtop',
      execute: 'get',
      table: 'wrench',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        data && app.load('backtop');
      }
    });
  
    // 多页解析
    app.fire('send', 'db', {
      name: 'nextpage',
      execute: 'get',
      table: 'wrench',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        data && app.load('nextpage');
      }
    });

    // 移除页脚
    app.fire('removefooter');

    utils.wait(function(){
     // 再次加载主题同步给其他插件
     app.fire('setting-theme');
     // 再次同步纸张效果给其他插件
     paper();
    });
  }, true);
  app.on('render-page-done', function(articles){
  
    const context = app.fire('dom-container');
    // 图片预览
    context.querySelectorAll('img').length > 0 && app.load('zoom');
    // 代码高亮
    context.querySelectorAll('pre, code').length > 0 && app.load('highlight');

    utils.wait(function(){
      // 通知插件更新数据
      app.fire('render-ready', articles);
      // 看门狗
      app.fire('send', 'watchdog');
    });
  });
}
