export function traverse(article){
  let current = article;
  let mirror = article.cloneNode(true);
  while(current){
    mirror.mirrorElement = current;
    const firstElementChild = current.firstElementChild;
    if (firstElementChild) {
      current = firstElementChild;
      mirror = mirror.firstElementChild;
    }else{
      let nextSibling;
      while (current !== article && !(nextSibling = current.nextElementSibling)){
        current = current.parentElement;
        mirror = mirror.parentElement;
      }
      if(current === article){
        break;
      }
      current = nextSibling;
      mirror = mirror.nextElementSibling;
    }
  }
  return mirror;
}

export function detchTitle(page){
  const context = page.ownerDocument;
  if(!context){
    return;
  }
  const target = context.querySelector('head > title');
  if(!target){
    return;
  }
  const detch = new MutationObserver(function(mutations){
    if(!mutations || mutations.length < 1){
      return;
    }
    const addNodes = mutations[0].addedNodes;
    if(!addNodes || addNodes.length < 1){
      return;
    }
    const addNode = addNodes[0];
    if(!addNode || !utils.isTextNode(addNode)){
      return;
    }
    const title = dom.nodeText(addNode);
    if(title && title.length > 0){
      const firstElement = page.firstElementChild;
      if(firstElement){
        detch.disconnect();
        page.insertBefore(dom.create('h1', {
          className: 'title',
          innerText: title,
        }), firstElement);
      }
    }
  });
  detch.observe(target, {childList: true});
  utils.wait(function(){
    detch.disconnect();
  }, 3000);
}

export function generatePage(title = document.title, articleElement, cover){
  const pageElement = dom.create('div', {
    className: 'page',
  });
  if(utils.isElement(cover)){
    const url = dom.imgUrl(cover);
    if(utils.isString(url) && !url.startsWith('data:')){
      const coverElement = dom.create('img', {
        src: dom.imgUrl(cover),
      });
      const coverNode = dom.create('div', {
        className: 'cover',
      });
      dom.imgFilter(coverElement, coverNode);
      coverNode.appendChild(coverElement);
      pageElement.appendChild(coverNode);
    }
  }
  if(utils.isString(title) && title.length > 0){
    const titleElement = dom.create('h1', {
      className: 'title',
      innerText: title,
    });
    pageElement.appendChild(titleElement);
  } else {
    // 监听丢失的标题
    detchTitle(pageElement);
  }
  pageElement.appendChild(articleElement);
  return pageElement;
}

export function generateFooter(app){
  const footerElement = dom.create('div', {
    className: 'footer',
  });
  footerElement.appendChild(dom.create('div', {
    className: 'copyright',
    innerText: app.fire('i18n', 'copyright', location.hostname),
  }));
  // footerElement.appendChild(dom.create('ul', {
  //   className: 'links',
  //   innerHTML: `
  //     <li><a target="_blank" href="/">捐赠</a></li>
  //     <li><a target="_blank" href="/">投票</a></li>
  //     <li><a target="_blank" href="/">反馈</a></li>
  //     <li><a target="_blank" href="/">官网</a></li>
  //   `,
  // }));
  return footerElement;
}

export function generateContainer(){
  return dom.create('div', {
    className: 'container',
  });
}

export function generateRoot(){
  return dom.create('div', {
    className: 'root paper',
  });
}
