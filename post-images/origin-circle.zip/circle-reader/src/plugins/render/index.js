import {
  traverse,
  generateRoot,
  generatePage,
  generateFooter,
  generateContainer,
} from './utils';

import './index.less';

App.register('render', ['shadow', 'utils', 'dom', 'format', 'pjax'], function(shadow, utils, dom){
  const app = this;
  const body = document.body;
  const documentElement = document.documentElement;
  const rootElement = generateRoot();
  app.on('dom-root', rootElement);
  const containerElement = generateContainer();
  app.on('dom-container', containerElement);
  rootElement.appendChild(containerElement);
  const footerElement = generateFooter(app);
  rootElement.appendChild(footerElement);
  const externalStyle = dom.create('style');
  shadow({
    mode: 'open',
    root: documentElement,
    style: 'plugins/render/index.css',
    onReady: function(shadowRoot, host){
      host.appendChild(dom.create('style', {
        textContent:`
          .circle-html{
            --circle-track:#e2e2e2;
            --circle-thumb: #9e9e9e;
            --circle-radius: 4px;

            margin: 0px !important;
            padding: 0px !important;
            overflow: auto !important;
          }
          .circle-hidden{
            width:100% !important;
            height:100% !important;
            opacity:0 !important;
            pointer-events:none !important;
            position:fixed !important;
            top:0px !important;
            left:0px !important;
          }
        `,
      }));
      host.appendChild(externalStyle);
      shadowRoot.appendChild(rootElement);
    }
  });
  app.on('insert-style', function(value, style, external){
    if(external && style){
      dom.setAttr(externalStyle, 'textContent', value);
      return;
    }
    const stylesheet = style ? dom.create('style', {
      textContent: value,
    }) : dom.create('link', {
      rel:'stylesheet',
      href:app.runtime.getURL(value),
    });
    rootElement.appendChild(stylesheet);
  });
  app.on('format-done', function(article, title, page){
    // 加载图片预览插件
    const imgs = article.querySelectorAll('img');
    imgs.length && app.load('zoom', function(){
      app.fire('zoom', imgs);
    });
    // 加载代码高亮插件
    article.querySelectorAll('pre, code').length && app.load('highlight', function(){
      app.fire('highlight', article);
    });
    // 大纲
    const headings = page.querySelectorAll('h1,h2,h3,h4,h5,h6');
    headings.length > 1 && app.fire('anchor', headings);
    app.fire('render-ready');
  });
  app.on('empty-page', function(callback){
    containerElement.innerHTML = '';
    callback && callback();
  });
  app.on('render-page', function(){
    const { title, article, cover } = app.cache('node');
    if(!article){
      return;
    }
    const articleElement = traverse(article);
    // textContent 可以删除换行 https://xueqiu.com/8659762526/188767730 
    const titleElement = utils.isElement(title) ? title.textContent.trim() : title;
    const pageElement = generatePage(titleElement, articleElement, cover);
    containerElement.appendChild(pageElement);
    app.fire('format-start', articleElement, titleElement, pageElement);
    return pageElement;
  });
  app.on('theme', function(value, key){
    if(utils.isUndefined(value) && utils.isUndefined(key)){
      return;
    }
    utils.each(utils.isPlainObject(value) ? value : {
      [key]: value,
    }, (style, styleKey) => {
      if(style === 'reset'){
        rootElement.style.removeProperty(`--${styleKey}`);
      } else {
        switch(styleKey){
          case 'imagealign':
            if(style === 'left'){
              rootElement.style.setProperty('--imageleft', 0);
              rootElement.style.setProperty('--imageright', 0);
            } else if(style === 'center'){
              rootElement.style.setProperty('--imageleft', 'auto');
              rootElement.style.setProperty('--imageright', 'auto');
            } else if(style === 'right'){
              rootElement.style.setProperty('--imageleft', 'auto');
              rootElement.style.setProperty('--imageright', 0);
            }
            break;
          case 'bg':
            if(utils.isString(style) && style.startsWith('#')){
              const canvasValue = [];
              utils.each(utils.hex2rgb(style), function(item, key){
                const value = item - 18;
                const itemValue = value < 0 ? 0 : value;
                canvasValue.push(itemValue);
                rootElement.style.setProperty(`--${styleKey}-${key}`, itemValue);
              });
              rootElement.style.setProperty('--canvas', style);
              rootElement.style.setProperty(`--${styleKey}`, `rgb(${canvasValue.join(', ')})`);
            } else if(utils.isString(style) && style.startsWith('linear-gradient')){
              const linear = style.replace(/linear-gradient\((.*?)\)/, '$1').split(',').map(item => item.trim().split(' ').shift());
              if(linear && linear.length === 3){
                utils.each(utils.hex2rgb(linear[1]), function(item, key){
                  const value = item - 18;
                  const itemValue = value < 0 ? 0 : value;
                  rootElement.style.setProperty(`--${styleKey}-${key}`, itemValue);
                });
                rootElement.style.setProperty('--canvas', 'transparent');
                rootElement.style.setProperty(`--${styleKey}`, style);
              }
            } else {
              rootElement.style.setProperty(`--${styleKey}-r`, 237);
              rootElement.style.setProperty(`--${styleKey}-g`, 237);
              rootElement.style.setProperty(`--${styleKey}-b`, 237);
              rootElement.style.setProperty('--canvas', 'transparent');
              rootElement.style.setProperty(`--${styleKey}`, style);
            }
            break;
          case 'track':
          case 'radius':
          case 'thumb':
            documentElement.style.setProperty(`--circle-${styleKey}`, style);
            break;
          default:
            rootElement.style.setProperty(`--${styleKey}`, style);
        }
      }
    });
  });
  const mediaQueryListDark = window.matchMedia('(prefers-color-scheme: dark)');
  // 跟随系统切换主题
  mediaQueryListDark.addEventListener('change', function(mediaQueryListEvent) {
    app.fire('send', 'db', {
      table: 'wrench',
      name: 'night',
      execute: 'get',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        if(utils.isBoolean(data) & data){
          app.fire('send', 'db', {
            table: 'setting',
            execute: 'get',
            name: mediaQueryListEvent.matches ? 'dark' : 'light',
          }, ({error, data}) => {
            if(error){
              app.fire('error', error);
            } else {
              app.fire('theme', data);      
            }
          });
        }
      }
    });
  });
  app.on('render-theme', function(){
    app.fire('send', 'db', {
      name: 'night',
      execute: 'get',
      table: 'wrench',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        app.fire('send', 'db', {
          table: 'setting',
          execute: 'get',
          name: utils.isBoolean(data) & data ? (mediaQueryListDark.matches ? 'dark' : 'light') : 'skin',
        }, (result) => {
          if(result.error){
            app.fire('error', result.error);
          } else {
            app.fire('theme', result.data);      
          }
        });
      }
    });
  });
  app.on('render-start-done', function(){
    // 样式设置
    app.fire('send', 'db', {
      table: 'setting',
      name: 'style',
      execute: 'get',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        app.fire('theme', data);
      }
    });
    // 自定义样式
    app.fire('send', 'db', {
      execute: 'get',
      table: 'wrench',
      name: 'stylesheet',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        utils.isString(data) && data.length > 0 && app.fire('insert-style', data, true);
      }
    });
    // 主题设置
    app.fire('render-theme');
    // 滚动条样式
    app.fire('insert-style', `
      ::-webkit-scrollbar {
        width: 8px;
      }
      ::-webkit-scrollbar-track {
        background: var(--circle-track);
      }
      ::-webkit-scrollbar-thumb {
        border-radius: var(--circle-radius);
        background: var(--circle-thumb); 
      }
    `, true, true);
    // 纸张效果
    app.on('paper', function(checked){
      if(checked){
        rootElement.classList.add('paper');
      } else {
        rootElement.classList.remove('paper');
      }
    });
    app.fire('send', 'db', {
      table: 'wrench',
      name: 'paper',
      execute: 'get',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        !data && rootElement.classList.remove('paper');
      }
    });
    // 工具栏
    app.load('toolbar');
    // 大纲
    app.fire('send', 'db', {
      table: 'wrench',
      name: 'outline',
      execute: 'get',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        data && app.load('anchor');
      }
    });
    // 返回顶部
    app.fire('send', 'db', {
      table: 'wrench',
      name: 'backtop',
      execute: 'get',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        data && app.load('backtop');
      }
    });
    // 多页解析
    app.fire('send', 'db', {
      table: 'wrench',
      name: 'nextpage',
      execute: 'get',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        data && app.load('nextpage');
      }
    });
    utils.wait(function(){
      // 再次加载主题同步给其他插件
      app.fire('render-theme');
      // 看门狗例行检查
      app.fire('send', 'watchdog');
    });
  }, true);
  app.on('render-start', function(){
    if(app.cache('running')){
      return;
    }
    app.cache('running', true);
    body.classList.add('circle-hidden');
    externalStyle.disabled = false;
    documentElement.classList.add('circle-html');
    dom.setStyle(rootElement, 'display', 'block');
    app.fire('send', 'status', {action: 'done'});
    app.fire('render-start-done');
  });
  app.on('render-destory-done', function(){
    // 退出关闭
    app.fire('send', 'db', {
      table: 'wrench',
      name: 'exitclose',
      execute: 'get',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        if(data){
          app.fire('send', 'tab', {action: 'remove'});
        } else {
          // 多页解析退出后跳转到对应最后一页
          const lastnodeurl = app.cache('lastnodeurl');
          if(!lastnodeurl || lastnodeurl === location.href){
            return;
          }
          const hash = location.hash;
          location.href = `${lastnodeurl}${hash ? '/' : '#'}circle=off`;
        }
      }
    });
  });
  app.on('render-destory', function(){
    if(!app.cache('running')){
      return;
    }
    app.cache('running', false);
    body.classList.remove('circle-hidden');
    externalStyle.disabled = true;
    documentElement.classList.remove('circle-html');
    dom.setStyle(rootElement, 'display', 'none');
    app.fire('send', 'status', {action: 'wait'});
    app.fire('render-destory-done');
  });
  app.on('render', function(){
    app.fire(app.cache('running') ? 'render-destory' : 'render-start');
  });
  rootElement.addEventListener('click', function(event){
    if(!app.cache('running')){
      return;
    }
    app.fire('click', event.target, event);
  });
  // 退出
  app.on('srt-exit', function(){
    if(!app.cache('running')){
      return;
    }
    app.fire('render-destory');
  });

  app.fire('render-start');
  app.fire('render-page');  
});
