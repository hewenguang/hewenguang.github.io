import controller from './controller';
import generateRoot from './element/root';
import generatePage from './element/page';
import generateVote from './element/vote';
import generateFooter from './element/footer';
import generateLoading from './element/loading';
import generateContainer from './element/container';

import './index.less';

App.register('render', ['shadow', 'dom', 'utils', 'format'], function(shadow, dom){
  const app = this;
  const root = generateRoot(app);
  const container = generateContainer(app);
  root.appendChild(container);
  const loading = generateLoading(app);
  root.appendChild(loading);
  const vote = generateVote(app);
  vote && root.appendChild(vote);
  const footer = generateFooter(app);
  root.appendChild(footer);
  const body = document.body;
  const html = document.documentElement;
  const externalStyle = dom.create('style');

  shadow({
    mode: 'open', //翻译支持
    style: 'plugins/render/index.css',
    onReady: function(shadowRoot, host){
      host.appendChild(dom.create('style', {
        textContent:`
          html.circle-html{
            --circle-track-width:8px;
            --circle-track:#e2e2e2;
            --circle-thumb: #9e9e9e;
            --circle-radius: 4px;

            margin: 0px !important;
            padding: 0px !important;
            overflow: auto !important;
            background: #fff !important;
          }
          html.circle-disable{
            width: 100% !important;
            height: 100% !important;
            overflow: hidden !important;
          }
          html.circle-html>body.circle-hidden{
            width:100% !important;
            height:100% !important;
            opacity:0 !important;
            pointer-events:none !important;
            position:fixed !important;
            top:0px !important;
            left:0px !important;
          }
          html.circle-pure{
            --circle-track-width:0;
          }
        `,
      }));
      host.appendChild(externalStyle);
      shadowRoot.appendChild(root);
    }
  });

  // 加载控制器
  controller(app, root);

  app.on('insert-style', function(value, style, external){
    if(external && style){
      dom.setAttr(externalStyle, 'textContent', value);
      return;
    }
    const stylesheet = style ? dom.create('style', {
      textContent: value,
    }) : dom.create('link', {
      rel:'stylesheet',
      href:app.runtime.getURL(value),
    });
    root.appendChild(stylesheet);
  });
  app.on('empty-page', function(callback){
    container.innerHTML = '';
    callback && callback();
  });
  app.on('enable-scroll', function(){
    html.classList.remove('circle-disable');
  });
  app.on('disable-scroll', function(){
    html.classList.add('circle-disable');
  });

  app.on('render-article', function(article, callback){
    app.fire('send', 'db', {
      name: 'layout',
      execute: 'get',
      table: 'setting',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
        return;
      }
      // 布局更新
      data && app.fire('theme', data);
      const articles = [];
      if(data && data.column){
        const innerHeight = window.innerHeight - 160;
        let maxHeight = innerHeight;
        let block = dom.create('div', {className: 'page page-block'});
        container.appendChild(block);
        articles.push(block);
        dom.nextSibling(article, function(node){
          block.appendChild(node);
          if(utils.isElement(node)){
            const nodeHeight = node.clientHeight;
            nodeHeight > innerHeight && (maxHeight = nodeHeight);
          }
          if(block.clientHeight > maxHeight){
            block = dom.create('div', {className: 'page page-block'});
            container.appendChild(block);
            articles.push(block);
            maxHeight !== innerHeight && (maxHeight = innerHeight);
          }
        });
      } else {
        article.classList.add('page');
        container.appendChild(article);
        articles.push(article);
      }
      app.fire('loading', false);
      callback && callback(articles);
    });
  });
  app.on('render-page', function(){
    const node = app.cache('node');
    if(!node.article){
      return;
    }
    app.fire('loading', true);
    const title = dom.nodeText(node.title);
    // todo table hilightjs https://gist.github.com/my8bit/7143332
    const article = generatePage(Object.assign({}, node, {
      title,
      article:dom.traverse(node.article),
    }), node.article.mirrorParent);
    // 格式化数据
    app.fire('format', article, title);
    app.fire('render-article', article, function(articles){
      app.fire('render-page-done', articles);
    });
  });
  app.on('render-destory', function(){
    if(!app.cache('running')){
      return;
    }
    app.cache('running', false);
    body.classList.remove('circle-hidden');
    externalStyle.disabled = true;
    html.classList.remove('circle-html');
    dom.setStyle(root, 'display', 'none');
    app.fire('send', 'status', {action: 'wait'});
    app.fire('render-destory-done');
    // 恢复之前的位置
    const scrollTop = app.cache('scrollTop');
    window.scrollTo({
      left:0,
      top:scrollTop || 0,
      behavior: 'instant',
    });
    app.cache('scrollTop', 0);
  });
  app.on('render-start', function(){
    if(app.cache('running')){
      return;
    }
    // 记录当前位置，退出恢复
    app.cache('scrollTop', dom.scrollTop());
    app.cache('running', true);
    body.classList.add('circle-hidden');
    externalStyle.disabled = false;
    html.classList.add('circle-html');
    dom.setStyle(root, 'display', 'block');
    app.fire('send', 'status', {action: 'done'});
    app.fire('render-start-done');
  });
  app.on('render', function(){
    app.fire(app.cache('running') ? 'render-destory' : 'render-start');
  });

  app.fire('render-start');

  // 样式设置
  app.fire('send', 'db', {
    name: 'style',
    execute: 'get',
    table: 'setting',
  }, ({error, data}) => {
    if(error){
      app.fire('error', error);
    } else {
      data && app.fire('theme', data);
      utils.lazy(function(){
        app.fire('render-page');
      });
    }
  });
});
