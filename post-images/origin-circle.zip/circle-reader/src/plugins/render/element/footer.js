
export default function(app){
  const element = dom.create('div', {
    // 禁用翻译
    className: 'footer notranslate',
  });
  // 移除页脚
  app.on('removefooter', function(){
    app.fire('send', 'db', {
      table: 'wrench',
      execute: 'get',
      name: 'removefooter',
    }, ({error, data}) => {
      if(error){
        app.fire('error', error);
      } else {
        if(data){
          element.classList.add('noise');
        } else {
          element.classList.remove('noise');
        }
      }
    });
  });
  element.appendChild(dom.create('ul', {
    className: 'link',
    innerHTML: `
      <li><a target="_blank" href="${app.to()}">${app.fire('i18n', 'website')}</a></li>
      <li><a target="_blank" href="${app.to('download')}">${app.fire('i18n', 'download')}</a></li>
      <li><a target="_blank" href="${app.to('feedback')}">${app.fire('i18n', 'feedback')}</a></li>
      <li><a target="_blank" href="${app.to('donate')}">${app.fire('i18n', 'donate')}❤️</a></li>
    `,
  }));
  element.appendChild(dom.create('div', {
    className: 'copyright',
    innerText: app.fire('i18n', 'copyright', location.hostname),
  }));
  return element;
}
