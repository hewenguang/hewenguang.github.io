function detchTitle(articleElement, success, fail){
  const context = articleElement.ownerDocument;
  if(!context){
    return;
  }
  const target = context.querySelector('head > title');
  if(!target){
    return;
  }
  const detch = new MutationObserver(function(mutations){
    if(!mutations || mutations.length < 1){
      return;
    }
    const addNodes = mutations[0].addedNodes;
    if(!addNodes || addNodes.length < 1){
      return;
    }
    const addNode = addNodes[0];
    if(!addNode || !utils.isTextNode(addNode)){
      return;
    }
    const title = dom.nodeText(addNode);
    if(title && title.length > 0){
      detch.disconnect();
      success && success(title);
    }
  });
  detch.observe(target, {childList: true});
  utils.wait(function(){
    detch.disconnect();
    fail && fail();
  }, 3000);
}

export default function({ url, cover, title = document.title, article }, mirrorParent){
  // 删除空的元素后再排版
  utils.each(article.querySelectorAll('div,p'), function(node){
    node.childNodes.length <= 0 && dom.remove(node);
  });
  let articleElement = article;
  if(dom.onlyOneNode(articleElement)){
    const firstElementChild = articleElement.firstElementChild;
    utils.isElement(firstElementChild) && (articleElement = firstElementChild);
  }
  if(dom.tag(articleElement, 'div')){
    dom.removeAttr(articleElement);
  } else{
    const newArticleElement = dom.create('div');
    newArticleElement.mirrorElement = articleElement.mirrorElement;
    dom.nextSibling(articleElement, function(node){newArticleElement.appendChild(node)});
    articleElement = newArticleElement;
  }
  dom.removeAttr(articleElement, () => true);
  // 加入分隔符
  mirrorParent && utils.each(articleElement.children, function(node){
    dom.setAttr(node, 'role', 'separator');
  });
  const firstChild = articleElement.firstChild;
  if(utils.isElement(cover)){
    const url = dom.imgUrl(cover);
    if(utils.isString(url) && !url.startsWith('data:')){
      const coverNode = dom.create('div', {
        className: 'cover',
      });
      const coverImage = dom.create('img', {
        src: dom.imgUrl(cover),
      });
      coverImage.addEventListener('load', function(){
        const width = this.naturalWidth;
        const height = this.naturalHeight;
        // 删除严重失衡宽高比图片（如 banner 广告）
        if(width / height > 4){
          dom.remove(coverNode);
        }
      });
      coverImage.addEventListener('error', function(){
        dom.remove(coverNode);
      });
      coverNode.appendChild(coverImage);
      articleElement.insertBefore(coverNode, firstChild);
    }
  }
  const titleElement = dom.create('h1', {className: 'title'});
  const linkElement = dom.create('a', {href:url,target: '_blank'});
  titleElement.appendChild(linkElement);
  articleElement.insertBefore(titleElement, firstChild);
  if(utils.isString(title) && title.length > 0){
    linkElement.innerText = title;
  } else {
    // 监听丢失的标题
    detchTitle(articleElement, function(value){
      linkElement.innerText = value;
    }, function(){
      dom.nodeText(linkElement) <= 0 && dom.remove(titleElement);
    });
  }
  return articleElement;
}
