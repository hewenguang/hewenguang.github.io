export default function(app){
  const element = dom.create('div', {
    className: 'container',
  });
  app.on('dom-container', element);
  element.addEventListener('mouseover', function(event){
    if(!app.cache('running')){
      return;
    }
    app.fire('mouseover', event.target, event);
  });
  element.addEventListener('mouseout', function(event){
    if(!app.cache('running')){
      return;
    }
    app.fire('mouseout', event.target, event);
  });
  const resize = new ResizeObserver(function(){
    app.cache('running') && app.fire('resize-conatiner', element);
  });
  resize.observe(element);
  return element;
}
