export default function(app){
  const element = dom.create('div', {
    className: 'root paper',
  });
  app.on('dom-root', element);
  element.addEventListener('click', function(event){
    if(!app.cache('running')){
      return;
    }
    app.fire('click', event.target, event);
  });
  // 纸张效果
  app.on('paper', function(paper){
    if(paper){
      element.classList.add('paper');
      element.classList.remove('solid');
    } else {
      element.classList.remove('paper');
      // 延迟处理获取值
      setTimeout(function(){
        const solid = element.style.getPropertyValue('--bg');
        solid.startsWith('rgb') && element.classList.add('solid');
      }, 100);
    }
  });
  const resize = new ResizeObserver(function(){
    app.cache('running') && app.fire('resize-root', element);
  });
  resize.observe(element);
  return element;
}
