import Database from './class.database';

App.register('database', 'utils', function(){
  const app = this;
  const storage = window.localStorage;

  app.on('storage', function({request, callback}){
    let storageValue;
    const name = request.name;
    const value = request.value;
    const action = request.execute;

    switch(action){
      case 'get':
        storageValue = storage.getItem(name);
        callback && callback(null, storageValue);
        break;
      case 'remove':
        storageValue = storage.removeItem(name);
        callback && callback(null, storageValue);
        break;
      case 'add':
        storageValue = storage.setItem(name, value);
        callback && callback(null, storageValue);
        break;
      default:
        callback && callback('not find action');
    }
  });

  const tables = app.cache('db_tables');
  const db = new Database('cc', tables);

  app.on('db', function({request, callback}){
    const skip = request.skip;
    const name = request.name;
    const value = request.value;
    const action = request.execute;
    const table = request.table || tables[0];
    // 缓存数据，加快访问
    const cache = app.cache(`${table}_${name}`);

    switch(action){
      case 'get':
        if(utils.isBoolean(cache) || cache === 0 || cache){
          callback && callback(null, cache);
        } else {
          db.get(table, name, function(error, data){
            (utils.isBoolean(data) || data === 0 || data) && app.cache(`${table}_${name}`, data);
            callback && callback(error, data);
          });
        }
        break;
      case 'remove':
        db.delete(table, name, function(error, data){
          app.cache(`${table}_${name}`, null);
          callback && callback(error, data);
          app.fire('db_remove', table, name, skip);
        });
        break;
      case 'add':
        db.set(table, name, value, function(error, data){
          (utils.isBoolean(value) || value === 0 || value) && app.cache(`${table}_${name}`, value);
          callback && callback(error, data);
          app.fire('db_add', table, name, value, skip);
        });
        break;
      case 'each':
        db.each(table, function(key, item){
          if(utils.isPlainObject(item) && utils.isEqualObject(value, item[name])){
            return true;
          }
          if(utils.isEqualObject(name, key) && utils.isEqualObject(item, value)){
            return true;
          }
        }, callback);
        break;
      case 'all':
        db.getAll(table, callback);
        break;
      case 'list':
        db.getAll(table, function(error, results){
          if(error){
            callback && callback(error);
            return;
          }
          const { start = 1, limit = 10, filter = '' } = request.query;
          const lists = [];
          Object.keys(results).forEach(function(key){
            const item = results[key];
            item.forEach(function(blacklist){
              if(filter){
                (blacklist.title.indexOf(filter) > -1 || blacklist.url.indexOf(filter) > -1) && lists.push(blacklist);
              } else {
                lists.push(blacklist);
              }
            });
          });
          callback && callback(null, {
            total: lists.length,
            data: lists.sort(function(prev, next){
              return next.create - prev.create;
            }).filter(function(item, index){
              return index >= (start - 1) * limit && index < start * limit;
            }),
          });
        });
        break;
      default:
        callback && callback('not find action');
    }
  });
  app.on('install', function(){
    // 写入初始配置
    app.fire('import', {
      request: {
        data: {
          wrench:{
            paper:true,
            outline:true,
            backtop:true,
            'shortcut-enabled':true,
            'contextmenu-enabled':true,
          },
          shortcut:{
            'srt-enter-or-exit':{
              value:'c',
              checked:true,
            },
            'srt-exit':{
              value:'escape',
              checked:true,
            },
            'srt-whitelist':{
              value:'w',
              checked:true,
            },
            'srt-blacklist':{
              value:'b',
              checked:true,
            },
            'srt-focus':{
              value:'f',
              checked:true
            },
            'srt-option':{
              value:'o',
              checked:true,
            },
          },
          contextmenu:{
            'ctx-whitelist':{
              checked:true,
              create:1624953996602,
              label:app.fire('i18n', 'whitelist'),
            },
            'ctx-blacklist':{
              checked:true,
              create:1624954331545,
              label:app.fire('i18n', 'blacklist'),
            },
            'ctx-focus':{
              checked:true,
              create:1624958779794,
              label:app.fire('i18n', 'focus'),
            },
            'ctx-option':{
              checked:true,
              create:1624958780934,
              label:app.fire('i18n', 'setting'),
            },
          }
        },
      }
    });
    app.fire('sync');
  });
  app.on('update', function(){
    app.fire('storage', {
      request:{
        execute: 'add',
        name: 'update',
        value: 'https://ranhe.xyz/circle-changelog/',
      },
    });
    app.fire('sync');
  });
});
