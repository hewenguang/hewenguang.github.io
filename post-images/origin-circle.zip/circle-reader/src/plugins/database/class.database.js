export default class Database{
  constructor(name, tables = []){
    this._indexedDB = window.indexedDB || window.webkitindexedDB;
    this._version = 2;
    this._name = name;
    this._tables = tables;
    this._db = null;
  }

  _check(callback){
    if(this._db){
      callback && callback(null, this._db);
      return;
    }
    const request = this._indexedDB.open(this._name, this._version);
    request.onsuccess = event => {
      this._db = event.target.result;
      callback && callback(null, this._db);
    };
    request.onupgradeneeded = event => {
      const database = event.target.result;
      utils.each(this._tables, table => {
        if (!database.objectStoreNames.contains(table)) {
          database.createObjectStore(table, { autoIncrement: true });
        }
      });
      // 删除插件表
      // database.objectStoreNames.contains('plugin') && database.deleteObjectStore('plugin');
      const transaction = event.target.transaction;
      // 清空插件表
      transaction.objectStore('plugin').clear();
      // 更新 option 数据表
      if(!database.objectStoreNames.contains('option')){
        return;
      }
      const store = transaction.objectStore('option');
      const cursor = store.openCursor();
      const setting = {
        skin:{},
        style:{},
      };
      const wrench = {};
      const shortcut = {};
      const blacklist = {};
      const whitelist = {};
      cursor.onsuccess = function(event){
        const result = event.target.result;
        if(result){
          switch(result.key){
            case 'toc':
              wrench.outline = result.value;
              break;
            case 'back2top':
              wrench.backtop = result.value;
              break;
            case 'nextpage':
              wrench.nextpage = result.value;
              break;
            case 'paper':
              wrench.paper = result.value;
              break;
            case 'parser':
              wrench.autorun = result.value;
              break;
            case 'ignore':
              utils.each(result.value.split('\n'), function(itemValue){
                if(!itemValue){
                  return;
                }
                const url = itemValue.split('#').shift();
                const location = utils.location(url);
                !blacklist[location.hostname] && (blacklist[location.hostname] = []);
                blacklist[location.hostname].push({url, title:'--', create: +(new Date)})
              });
              break;
            case 'whitelist':
              utils.each(result.value.split('\n'), function(itemValue){
                if(!itemValue){
                  return;
                }
                const url = itemValue.split('#').shift();
                const location = utils.location(url);
                !whitelist[location.hostname] && (whitelist[location.hostname] = []);
                whitelist[location.hostname].push({url, title:'--', create: +(new Date)})
              });
              break;
            case 'shortcut':
              utils.each(result.value, function(itemValue, itemKey){
                if(!itemValue){
                  return;
                }
                switch(itemValue){
                  case 'circle':
                    shortcut['srt-enter-or-exit'] = {
                      value: itemKey,
                      checked: true,
                    };
                    break;
                  case 'esc':
                    shortcut['srt-exit'] = {
                      value: itemKey,
                      checked: true,
                    };
                    break;
                  case 'focus':
                    shortcut['srt-focus'] = {
                      value: itemKey,
                      checked: true,
                    };
                    break;
                  case 'options':
                    shortcut['srt-option'] = {
                      value: itemKey,
                      checked: true,
                    };
                    break;
                  case 'whitelist':
                    shortcut['srt-whitelist'] = {
                      value: itemKey,
                      checked: true,
                    };
                    break;
                }
              });
              if(result.value.disable === 'true' || Object.keys(shortcut).length > 0){
                wrench['shortcut-enabled'] = true;
              }
              break;
            case 'theme':
              utils.each(result.value, function(itemValue, itemKey){
                if(!itemValue || itemKey === 'preset'){
                  return;
                }
                if(itemKey === 'custom'){
                  setting.skin.bg = `#${[itemValue['bgcolor-red'], itemValue['bgcolor-green'], itemValue['bgcolor-blue']].map(x => x.toString(16).padStart(2, '0')).join('')}`;
                  setting.skin.color = `#${[itemValue['color-red'], itemValue['color-green'], itemValue['color-blue']].map(x => x.toString(16).padStart(2, '0')).join('')}`;
                  setting.skin.link = `#${[itemValue['linkcolor-red'], itemValue['linkcolor-green'], itemValue['linkcolor-blue']].map(x => x.toString(16).padStart(2, '0')).join('')}`;
                } else {
                  switch(itemKey){
                    case 'picture':
                      setting.style.imagehide = itemValue;
                      break;
                    case 'centerpicture':
                      setting.style.imagealign = itemValue === 'auto' ? 'center' : 'left';
                      break;
                    case 'align':
                      setting.style.titlealign = itemValue;
                      break;
                    default:
                      setting.style[itemKey] = itemValue;
                  }
                }
              });
          }
          result.continue();
        } else {
          const actions = [];
          utils.each([{
            table: 'setting',
            data: setting,
          },{
            table: 'wrench',
            data: wrench,
          },{
            table: 'shortcut',
            data: shortcut,
          },{
            table: 'blacklist',
            data: blacklist,
          },{
            table: 'whitelist',
            data: whitelist,
          }], function(item){
            const promises = [];
            utils.each(item.data, function(value, name){
              promises.push(new Promise((resolve, reject) => {
                const request = transaction.objectStore(item.table).put(value, name);
                request.onsuccess = () => {
                  resolve();
                };
                request.onerror = function(error){
                  reject(error);
                }
              }));
            });
            promises.length > 0 && actions.push(Promise.all(promises));
          });
          actions.length > 0 && Promise.all(actions).finally(function(){
            database.deleteObjectStore('option');
          });
        }
      }
    };
    request.onerror = event => {
      callback && callback(event);
    }
  }

  action(table, action, mode, callback, name, value) {
    this._check(function(error, db){
      if(error){
        // console.error(error);
        return;
      }
      const store = db.transaction([table], mode).objectStore(table);
      const request = utils.isUndefined(value) ? store[action](name) : store[action](value, name);
      request.onsuccess = () => {
        callback && callback(null, request.result);
      };
      request.onerror = function(error){
        callback && callback(error);
      }
    });
  }

  set(table, name, value, callback) {
    this.action(table, 'put', 'readwrite', callback, name, value);
  }

  get(table, name, callback) {
    this.action(table, 'get', 'readonly', callback, name);
  }

  each(table, iterator, callback){
    this._check(function(error, db){
      if(error){
        // console.error(error);
        return;
      }
      const store = db.transaction([table], 'readonly').objectStore(table);
      const cursor = store.openCursor();
      cursor.onsuccess = function(event){
        const result = event.target.result;
        if(result && !iterator(result.key, result.value)){
          result.continue();
        } else {
          callback && callback(null, result && result.value ? result.value : result);
        }
      }
      cursor.onerror = function(error){
        callback && callback(error);
      }
    });
  }

  getAll(table, callback) {
    const results = {};
    this.each(table, function(key, value){
      results[key] = value;
    }, function(error){
      callback(error, results);
    });
  }

  key(table, name, callback) {
    this.action(table, 'getKey', 'readonly', callback, name);
  }

  keys(table, callback) {
    this.action(table, 'getAllKeys', 'readonly', callback);
  }

  count(table, callback, name){
    this.action(table, 'count', 'readonly', callback, name);
  }

  delete(table, name, callback) {
    this.action(table, 'delete', 'readwrite', callback, name);
  }

  clear(table, callback) {
    this.action(table, 'clear', 'readwrite', callback);
  }

  destory(){
    this._db && this._db.close();
    this._indexedDB && this._indexedDB.deleteDatabase(this._name);
  }
}
