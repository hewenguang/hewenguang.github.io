import cx from 'classnames';
import { Tooltip } from 'antd';
import React, { useRef, useState, useEffect } from 'react';

export default function({ app, data }){
  const size = data.length;
  const container = useRef(null);
  const [ anchor, setAnchor ] = useState(null);

  useEffect(() => {
    if(!container || !container.current){
      return;
    }
    const target = container.current;
    dom.setStyle(target, 'maxHeight', dom.clientHeight() - 20);
    const hook = app.on('resize', function(height){
      dom.setStyle(target, 'maxHeight', height - 20);
    });
    return () => {
      app.remove(hook);
    };
  }, []);

  useEffect(() => {
    function anchorscroll() {
      if(data.length <= 0){
        return;
      }
      const anchors = [];
      const height = dom.clientHeight() / 2;
      utils.each(data, function(heading){
        if(utils.isElement(heading) && heading.getBoundingClientRect().bottom > height){
          return true;
        }
        anchors.push(heading);
      });
      setAnchor(anchors.pop() || data[0]);
    }
    const hook = app.on('scroll', anchorscroll);
    // 手动触发一次
    anchorscroll();
    return () => {
      app.remove(hook);
    }
  }, [ data ]);

  useEffect(() => {
    if(!anchor || !container || !container.current){
      return;
    }
    const target = container.current;
    const current = target.querySelector('.anchor-active');
    if(!current){
      return;
    }
    const offsetTop = current.offsetTop - 16;
    target.scrollTo({
      left: 0,
      behavior: 'smooth',
      top: offsetTop > 0 ? offsetTop : 0,
    });
  }, [ anchor ]);

  let level = 6;
  data.forEach(function(heading){
    if(utils.isElement(heading)){
      const headingLevel = parseInt(heading.nodeName.charAt(1));
      if(headingLevel < level){
        level = headingLevel;
      }
    }
  });

  return (
    <ul
      ref={container}
      className="anchor-list"
    >
      {data.map(function(heading, index){
        if(index >= size - 1){
          return null;
        }
        if(!utils.isElement(heading)){
          return (
            <li
              key={heading}
              className="spliter"
            />
          );
        }
        const title = heading.innerText.trim();
        const idValue = heading.getAttribute('id');
        const nodeName = heading.nodeName.toLowerCase();
        const headingLevel = parseInt(nodeName.charAt(1));
        return (
          <li
            key={idValue}
            data-selector={`#${idValue}`}
            onClick={() => dom.scrollIntoView(heading)}
            className={cx(`anchor-level-${headingLevel - level}`, {
              'anchor-active': anchor === heading,
            })}
          >
            <Tooltip
              title={title}
              placement="topLeft"
              mouseEnterDelay={1}
            >
              {title}
            </Tooltip>
          </li>
        );
      })}
    </ul>
  );
}
