import cx from 'classnames';
import { Tooltip } from 'antd';
import { PushpinOutlined } from '@ant-design/icons';
import React, { useState, useEffect } from 'react';
import Anchors from './anchors';
import './index.less';

export default function(props){
  const { app } = props;
  const [ closed, setClosed ] = useState(true);
  const [ pinned, setPinned ] = useState(false);

  useEffect(() => {
    app.fire('send', 'db', {
      execute:'get',
      table: 'wrench',
      name: 'anchor-pinned',
    }, function({error, data}){
      if(error){
        app.fire('error', error);
      } else {
        setPinned(!!data);
      }
    });
  }, []);

  return (
    <div
      className={cx('anchor-root', {
        'anchor-pinned': pinned,
        'anchor-closed': !pinned && closed,
      })}
      onMouseEnter={() => {
        if(pinned){
          return;
        }
        setClosed(false);
      }}
      onMouseLeave={() => {
        if(pinned){
          return;
        }
        setClosed(true);
      }}
    >
      <Tooltip
        placement="right"
        title={app.fire('i18n', pinned ? 'hidden_outline': 'pinned_outline')}
      >
        <PushpinOutlined
          onClick={() => {
            app.fire('send', 'db', {
              execute:'add',
              table: 'wrench',
              value: !pinned,
              name: 'anchor-pinned',
            }, function({error}){
              if(error){
                app.fire('error', error);
              } else {
                setPinned(!pinned);
              }
            });
          }}
        />
      </Tooltip>
      <Anchors {...props} />
    </div>
  );
}
