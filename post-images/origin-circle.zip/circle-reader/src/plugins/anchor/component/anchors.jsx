import cx from 'classnames';
import React, { useRef, useState, useEffect } from 'react';

export default function(props){
  const { app, data } = props;
  const size = data.length;
  const container = useRef(null);
  const [ anchor, setAnchor ] = useState(null);

  useEffect(() => {
    if(!container || !container.current){
      return;
    }
    const target = container.current;
    dom.setStyle(target, 'maxHeight', dom.clientHeight() - 20);
    app.on('resize', function(height){
      dom.setStyle(target, 'maxHeight', height - 20);
    });
  }, []);

  useEffect(() => {
    const hook = app.on('scroll', function() {
      if(data.length <= 0){
        return;
      }
      const anchors = [];
      const height = dom.clientHeight() / 2;
      utils.each(data, function(heading){
        if(utils.isElement(heading) && heading.getBoundingClientRect().bottom > height){
          return true;
        }
        anchors.push(heading);
      });
      setAnchor(anchors.pop() || data[0]);
    });
    // 手动触发一次
    app.fire('scroll');
    return () => {
      app.remove(hook);
    }
  }, [ data ]);

  useEffect(() => {
    if(!anchor || !container || !container.current){
      return;
    }
    const target = container.current;
    const current = target.querySelector('.active');
    if(!current){
      return;
    }
    const offsetTop = current.offsetTop - 16;
    target.scrollTo({
      left: 0,
      behavior: 'smooth',
      top: offsetTop > 0 ? offsetTop : 0,
    });
  }, [ anchor ]);

  let level = 6;
  data.forEach(function(heading){
    if(utils.isElement(heading)){
      const headingLevel = parseInt(heading.nodeName.charAt(1));
      if(headingLevel < level){
        level = headingLevel;
      }
    }
  });

  return (
    <ul
      ref={container}
      className="anchor-list"
    >
      {data.map(function(heading, index){
        if(index >= size - 1){
          return null;
        }
        if(!utils.isElement(heading)){
          return (
            <li
              key={heading}
              className="spliter"
            />
          );
        }
        const title = heading.innerText.trim();
        const idValue = heading.getAttribute('id');
        const nodeName = heading.nodeName.toLowerCase();
        const headingLevel = parseInt(nodeName.charAt(1));
        return (
          <li
            key={idValue}
            title={title}
            data-selector={`#${idValue}`}
            className={cx(`anchor-level-${headingLevel - level} anchor-${nodeName}`, {
              'active': anchor === heading,
            })}
            onClick={() => {
              const rect = heading.getBoundingClientRect();
              window.scrollTo({
                left: 0,
                behavior: 'smooth',
                top: rect.top + window.scrollY,
              });
            }}
          >
            {title}
          </li>
        );
      })}
    </ul>
  );
}
