import useApp from 'app/context/useApp';
import React, { useState, useEffect } from 'react';
import Anchor from './anchor';

export default function(){
  const app = useApp();
  const [ anchors, setAnchors ] = useState([]);

  useEffect(() => {
    const hook = app.on('empty-anchor', function(){
      setAnchors([]);
    });
    return () => {
      app.remove(hook);
    }
  }, []);

  useEffect(() => {
    const hook = app.on('anchor', function(items){
      setAnchors([].concat(anchors, items));
    });
    return () => {
      app.remove(hook);
    }
  }, [ anchors ]);

  if(anchors.length <= 0 || anchors.filter(item => utils.isElement(item)).length <= 1){
    return null;
  }

  return (
    <Anchor app={app} data={anchors} />
  );
}
