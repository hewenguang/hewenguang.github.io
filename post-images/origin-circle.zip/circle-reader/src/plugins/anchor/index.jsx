import React from 'react';
import ReactDOM from 'react-dom';
import { ConfigProvider } from 'antd';
import { AppContext } from 'app/context';
import controller from './controller';
import Entry from './entry';
import 'antd/dist/antd.css';
import './index.less';

App.register('anchor', ['shadow', 'dom', 'utils'], function(shadow, dom){
  const app = this;
  const root = dom.create('div', {className:'root'});
  shadow({
    mode: 'open',
    style: [
      'plugins/antd/index.css',
      'plugins/anchor/index.css',
    ],
    onReady: function(shadowRoot){
      shadowRoot.appendChild(root);
    }
  });

  controller(app, root);

  ReactDOM.render((
    <AppContext.Provider value={app}>    
      <ConfigProvider
        componentSize="small"
        getPopupContainer={() => root}
      >
        <Entry />
      </ConfigProvider>
    </AppContext.Provider>
  ), root);
});
