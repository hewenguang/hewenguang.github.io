import React from 'react';
import ReactDOM from 'react-dom';
import { ConfigProvider } from 'antd';
import zhCN from 'antd/lib/locale/zh_CN';
import Entry from './entry';
import 'antd/dist/antd.css';
import './index.less';

App.register('anchor', ['shadow', 'dom', 'utils'], function(shadow, dom){
  const app = this;
  const rootElement = dom.create('div', {className:'root'});
  shadow({
    root: document.documentElement,
    style: [
      'plugins/antd/index.css',
      'plugins/anchor/index.css',
    ],
    onReady: function(shadowRoot){
      shadowRoot.appendChild(rootElement);
    }
  });
  app.on('theme', function(value, key){
    if(utils.isUndefined(value) && utils.isUndefined(key)){
      return;
    }
    utils.each(utils.isPlainObject(value) ? value : {
      [key]: value,
    }, (style, styleKey) => {
      if(!['color', 'link', 'bg'].includes(styleKey)){
        return;
      }
      if(style === 'reset'){
        rootElement.style.removeProperty(`--${styleKey}`);
      } else {
        if(styleKey === 'bg'){
          if(utils.isString(style) && style.startsWith('#')){
            const canvasValue = [];
            utils.each(utils.hex2rgb(style), function(item){
              const value = item - 18;
              const itemValue = value < 0 ? 0 : value;
              canvasValue.push(itemValue);
            });
            rootElement.style.setProperty(`--${styleKey}`, `rgb(${canvasValue.join(', ')})`);
          } else {
            rootElement.style.setProperty(`--${styleKey}`, style);
          }
        } else {
          rootElement.style.setProperty(`--${styleKey}`, style);
        }
      }
    });
  });
  app.on('render-start-done', function(){
    dom.setStyle(rootElement, 'display', 'block');
  });
  app.on('render-destory-done', function(){
    dom.setStyle(rootElement, 'display', 'none');
  });

  ReactDOM.render((
    <ConfigProvider
      locale={zhCN}
      componentSize="small"
      getPopupContainer={() => rootElement}
    >
      <Entry app={app} />
    </ConfigProvider>
  ), rootElement);
});
