export default function(app, root){
  app.on('render-start-done', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('render-destory-done', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-before', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-after', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('theme', function(value, key){
    if(utils.isUndefined(value)){
      return;
    }
    utils.each(utils.isPlainObject(value) ? value : {
      [key]: value,
    }, (style, styleKey) => {
      if(!['color', 'link', 'bg', 'track-width', 'track', 'thumb', 'radius'].includes(styleKey)){
        return;
      }
      if(style === 'reset'){
        root.style.removeProperty(`--${styleKey}`);
      } else {
        switch(styleKey){
          case 'bg':
            if(utils.isString(style) && style.startsWith('#')){
              const canvasValue = [];
              utils.each(utils.hex2rgb(style), function(item){
                const value = item - 18;
                const itemValue = value < 0 ? 0 : value;
                canvasValue.push(itemValue);
              });
              root.style.setProperty(`--${styleKey}`, `rgb(${canvasValue.join(', ')})`);
            } else if(utils.isString(style) && style.startsWith('linear')){
              root.style.setProperty(`--${styleKey}`, style);
            } else {
              root.style.setProperty(`--${styleKey}`, `center/cover no-repeat url("${style}")`);
            }
            break;
          default:
            root.style.setProperty(`--${styleKey}`, style);
        }
      }
    });
  });

  let index = 0;
  app.on('render-ready', function(blocks){
    utils.each(blocks, function(block){
      const items = [];
      utils.each(block.querySelectorAll('h1,h2,h3,h4,h5,h6'), function(item){
        const title = item.textContent.trim();
        if(!utils.isString(title) || title.length <= 0){
          return;
        }
        let id = dom.getAttr(item, 'id');
        if(!id){
          id = `anchor-${index}`;
          dom.setAttr(item, 'id', id);
          index++;
        }
        items.push(item);
      });
      if(items.length <= 0){
        return;
      }
      items.push(index);
      app.fire('anchor', items);
    });
  });
}
