import cx from 'classnames';
import Icon from 'app/components/icon';
import useApp from 'app/context/useApp';
import React, { useState, useEffect } from 'react';
import Anchors from './anchors';

export default function(){
  const app = useApp();
  const [ closed, setClosed ] = useState(true);
  const [ pinned, setPinned ] = useState(false);

  useEffect(() => {
    app.fire('send', 'db', {
      execute:'get',
      table: 'wrench',
      name: 'anchor-pinned',
    }, function({error, data}){
      if(error){
        app.fire('error', error);
      } else {
        setPinned(!!data);
      }
    });
  }, []);

  return (
    <div
      className={cx('anchor-root', {
        'anchor-pinned': pinned,
        'anchor-closed': !pinned && closed,
      })}
      onMouseEnter={() => {
        if(pinned){
          return;
        }
        setClosed(false);
      }}
      onMouseLeave={() => {
        if(pinned){
          return;
        }
        setClosed(true);
      }}
    >
      <Icon
        name="pin"
        placement="right"
        className="icon-pin"
        tooltip={app.fire('i18n', pinned ? 'hidden_outline': 'pinned_outline')}
        onClick={() => {
          app.fire('send', 'db', {
            execute:'add',
            table: 'wrench',
            value: !pinned,
            name: 'anchor-pinned',
          }, function({error}){
            if(error){
              app.fire('error', error);
            } else {
              setPinned(!pinned);
              app.fire('send', 'analytics', {event:`anchor-${!pinned}`});
            }
          });
        }}
      />
      <Anchors />
    </div>
  );
}
