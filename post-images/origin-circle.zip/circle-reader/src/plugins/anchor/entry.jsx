import React, { useState, useEffect } from 'react';
import Anchor from './component';

let anchorIndex = 0;

export default function({app}){
  const [ anchors, setAnchors ] = useState([]);

  useEffect(() => {
    const hook = app.on('empty-anchor', function(){
      setAnchors([]);
    });
    return () => {
      app.remove(hook);
    }
  }, []);

  useEffect(() => {
    const hook = app.on('anchor', function(headings){
      const items = [];
      utils.each(headings, function(heading){
        const title = heading.innerText.trim();
        if(!utils.isString(title) || title.length <= 0){
          return;
        }
        let headingId = dom.getAttr(heading, 'id');
        if(!headingId){
          headingId = `anchor-heading-${anchorIndex}`;
          dom.setAttr(heading, 'id', headingId);
          anchorIndex++;
        }
        items.push(heading);
      });
      // 只有一个可能是主标题
      if(items.length <= 1){
        return;
      }
      items.push(anchorIndex);
      setAnchors([].concat(anchors, items));
    });
    return () => {
      app.remove(hook);
    }
  }, [ anchors ]);

  if(anchors.length <= 0){
    return null;
  }

  return (
    <Anchor
      app={app}
      data={anchors}
    />
  );
}
