import React from 'react';
import Version from 'app/components/version';

export default function({app}){

  return (
    <div className="footer">
      <div>
        <a target="_blank" href={app.to()}>{app.fire('i18n', 'website')}</a>
        <a target="_blank" href={app.to('download')}>{app.fire('i18n', 'download')}</a>
      </div>
      <Version />
    </div>
  );
}
