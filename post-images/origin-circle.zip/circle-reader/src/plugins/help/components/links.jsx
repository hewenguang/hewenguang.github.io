import React from 'react';
import List from 'app/components/list';
import useApp from 'app/context/useApp';

export default function({data}){
  const app = useApp();

  return (
    <List
      data={data}
      borderBottom
      renderItem={item => (
        <a
          tabIndex={0}
          onKeyPress={event => {
            event.key === 'Enter' && app.fire(item.field);
          }}
          onClick={() => {
            app.fire(item.field);
          }}
        >
          {item.title}
        </a>
      )}
    />
  );
}
