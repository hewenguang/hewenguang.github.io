import React from 'react';
import { Space, Typography } from 'antd';
import Icon from 'app/components/icon';
import List from 'app/components/list';
import useApp from 'app/context/useApp';

const { Text } = Typography;

export default function({data}){
  const app = useApp();

  return (
    <List
      data={data}
      borderBottom
      renderItem={item => (
        <>
          {item.title}
          <Space>
            {item.checked && (
              <Text
                keyboard
              >
                {item.key}
              </Text>
            )}
            <a
              tabIndex={0}
              className="link"
              onKeyPress={event => {
                if(event.key === 'Enter'){
                  app.fire('wrench');
                  app.load('wrench', function(){
                    app.fire('guide', 'shortcut', item.field);
                  });
                }
              }}
              onClick={() => {
                app.fire('wrench');
                app.load('wrench', function(){
                  app.fire('guide', 'shortcut', item.field);
                });
              }}
            >
              <Icon name="edit" />
            </a>
          </Space>
        </>
      )}
    />
  );
}
