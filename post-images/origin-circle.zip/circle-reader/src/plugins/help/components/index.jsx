import React from 'react';
import { Tabs } from 'antd';
import Links from './links';
import Shortcut from './shortcut';

const { TabPane } = Tabs;

export default function(props){
  const { app, data } = props;
  const keys = [];
  const links = [];
  utils.each(data, function(item){
    item.link && links.push(item);
    keys.push(item);
  });

  return (
    <Tabs centered>
      <TabPane
        key="shortcut"
        tab={`${app.fire('i18n', 'shortcut')}(${keys.length})`}
      >
        <Shortcut data={keys} />
      </TabPane>
      <TabPane
        key="links"
        tab={`${app.fire('i18n', 'links')}(${links.length})`}
      >
        <Links data={links} />
      </TabPane>
    </Tabs>
  );
}
