import { Input } from 'antd';
import Icon from 'app/components/icon';
import useApp from 'app/context/useApp';
import React, { useRef, useEffect } from 'react';

export default function(props){
  const { placeholder, onChange } = props;
  const app = useApp();
  const container = useRef(null);

  useEffect(() => {
    const hook = app.on('help-change', function(visible){
      if(!container || !container.current){
        return;
      }
      if(visible){
        setTimeout(function(){
          container.current.focus({cursor: 'end'});
        }, 1000);
      } else {
        container.current.blur();
      }
    });
    return () => {
      app.remove(hook);
    };
  }, []);

  return (
    <Input
      allowClear
      size="large"
      ref={container}
      onChange={onChange}
      placeholder={placeholder}
      prefix={<Icon name="search" />}
    />
  );
}
