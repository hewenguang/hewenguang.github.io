import useApp from 'app/context/useApp';
import { useState, useEffect } from 'react';
import useShortcut from 'app/context/useShortcut';

export default function(){
  const app = useApp();
  const shortcut = useShortcut();
  const links = {};
  const modules = [
    'srt-setting',
    'srt-style',
    'srt-skin',
    'srt-layout',
    'srt-toolbar',
    'srt-wrench',
    'srt-basic',
    'srt-manage-whitelist',
    'srt-manage-blacklist',
    'srt-shortcut',
    'srt-contextmenu',
    'srt-config',
    'srt-stylesheet',
    'srt-links',
  ];
  utils.each(shortcut, function(item){
    const field = item.field;
    if(!field){
      return;
    }
    links[item.field] = {
      title: item.label,
      field: item.field,
      link: modules.includes(field),
    };
  });
  const [ option, setOption ] = useState(links);
  const refetch = function(){
    app.fire('send', 'db', {
      execute:'all',
      table: 'shortcut',
    }, function({error, data}){
      if(error || !data){
        error && app.fire('error', error);
      } else {
        const nextoption = Object.assign({}, links);
        utils.each(data, function(item, key){
          if(!nextoption[key]){
            return;
          }
          nextoption[key].key = item.value;
          nextoption[key].checked = item.checked;
        });
        setOption(nextoption);
      }
    });
  };

  useEffect(() => {
    const hook = app.on('help-change', function(visible){
      visible && refetch();
    });
    refetch();
    return () => {
      app.remove(hook);
    };
  }, []);

  return option;
}
