import React, { useState } from 'react';
import useApp from 'app/context/useApp';
import useData from './context/useData';
import Home from './components/index';
import Search from './components/search';
import Footer from './components/footer';

export default function(){
  const app = useApp();
  const data = useData();
  const [ items, setItems ] = useState(data);

  return (
    <>
      <h1 className="title">{app.fire('i18n', 'helpcenter')}</h1>
      <div className="search">
        <Search
          placeholder={app.fire('i18n', 'help_search')}
          onChange={event => {
            utils.wait(function(){
              const val = event.target.value;
              if(!val){
                setItems(data);
                return;
              }
              const next = {};
              utils.each(data, function(item, key){
                item.key && item.key.indexOf(val) >= 0 && !next[key] && (next[key] = item);
                item.title && item.title.indexOf(val) >= 0 && !next[key] && (next[key] = item);
              });
              setItems(next);
              app.fire('send', 'analytics', {event:`help-${val}`});
            });
          }}
        />
      </div>
      <Home
        app={app}
        data={items}
      />
      <Footer app={app} />
    </>
  );
}
