export default function(app, root){
  app.on('render-start-done', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('render-destory-done', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-before', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-after', function(){
    dom.setStyle(root, 'display', 'block');
  });
}
