import { saveAs } from 'file-saver'
import TurndownService from 'turndown';

App.register('marked', function(){
  const app = this;
  const root = app.fire('dom-container');
  if(!root){
    return;
  }
  app.on('marked', function(){
    const turndownService = new TurndownService;
    const marked = turndownService.turndown(root.innerHTML);
    saveAs(new Blob([marked], {type:'text/plain;charset=utf-8'}), `${document.title || 'circle'}.md`);
    app.fire('send', 'analytics', {event:'marked-export'});
  });
  app.fire('marked');
});
