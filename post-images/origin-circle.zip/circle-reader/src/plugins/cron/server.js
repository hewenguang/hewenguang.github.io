App.register('cron', ['utils', 'database'], function(){
  const app = this;

  // 默认一小时更新一次
  app.on('cron', function(callback, duration = 1){
    const now = +(new Date);
    const name = `corn_${duration}`;
    const timer = duration * 60 * 60 * 1000;
    app.fire('storage', {
      request: {
        name,
        execute: 'get',
      },
      callback: function(error, data = now){
        if(error){
          app.fire('error', error);
        } else {
          if(data > now){
            return;
          }
          app.fire('storage', {
            request: {
              name,
              execute: 'add',
              value: now + timer,
            },
            callback: function(error){
              if(error){
                app.fire('error', error);
              } else {
                callback && callback();
              }
            },
          });
        }
      },
    });
  });
});
