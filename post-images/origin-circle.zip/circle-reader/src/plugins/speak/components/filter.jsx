import React from 'react';
import useApp from 'app/context/useApp';
import Slider from 'app/components/slider';

export default function(props){
  const { data, onChange } = props;
  const app = useApp();

  return (
    <div className="filter">
      <Slider
        min={0}
        max={1}
        step={0.1}
        value={data.volume}
        tooltipVisible={false}
        label={app.fire('i18n', 'volume')}
        onChange={volume => {
          onChange && onChange(Object.assign({}, data, {volume}));
          app.fire('send', 'analytics', {event:'speak-volume'});
        }}
      />
      <Slider
        min={0.1}
        max={2}
        step={0.1}
        value={data.rate}
        tooltipVisible={false}
        label={app.fire('i18n', 'rate')}
        onChange={rate => {
          onChange && onChange(Object.assign({}, data, {rate}));
          app.fire('send', 'analytics', {event:'speak-rate'});
        }}
      />
      <Slider
        min={0}
        max={2}
        step={0.1}
        value={data.pitch}
        tooltipVisible={false}
        label={app.fire('i18n', 'pitch')}
        onChange={pitch => {
          onChange && onChange(Object.assign({}, data, {pitch}));
          app.fire('send', 'analytics', {event:'speak-pitch'});
        }}
      />
    </div>
  );
}
