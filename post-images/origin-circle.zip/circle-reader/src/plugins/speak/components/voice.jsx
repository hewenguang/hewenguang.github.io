import useApp from 'app/context/useApp';
import React, { useState, useEffect } from 'react';

export default function(props){
  const { value, onChange } = props;
  const app = useApp();
  const [ data, setData ] = useState([]);

  useEffect(() => {
    function voices(){
      const voices = speechSynthesis.getVoices();
      app.cache('speak-voices', voices);
      setData(voices);
    }
    voices();
    speechSynthesis.onvoiceschanged !== undefined && (speechSynthesis.onvoiceschanged = voices);
  }, []);

  if(data.length <= 0){
    return null;
  }

  let defaultVoice;
  const items = {};
  utils.each(data, function(item){
    const lang = item.lang.split('-').shift();
    !utils.isArray(items[lang]) && (items[lang] = []);
    items[lang].push(item);
    item.default && (defaultVoice = `${item.name}-${item.lang}`);
  });

  return (
    <select
      className="select"
      value={value || defaultVoice}
      onChange={event => {
        onChange && onChange(event.target.value);
        app.fire('send', 'analytics', {event:'speak-voice'});
      }}
    >
      {Object.entries(items).sort().map(item => {
        const [ label, langs ] = item;
        return (
          <optgroup key={label} label={label}>
            {langs.map(lang => {
              const voice = `${lang.name}-${lang.lang}`;
              return <option key={voice} value={voice}>{lang.name}</option>;
            })}
          </optgroup>
        );
      })}
    </select>
  );
}
