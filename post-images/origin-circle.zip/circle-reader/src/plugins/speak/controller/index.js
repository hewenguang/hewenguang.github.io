import { sections } from './utils';
import Mark from 'mark.js/dist/mark.es6';
import { LENGTH, PUNCTUATIONS, IGNORE_ELEMENTS } from './config';

export default function(app, root){
  let offset = 0;
  let destory = false;
  const elements = [];
  const container = app.fire('dom-container');
  const containerMark = new Mark(container);

  function push(context){
    sections(context, function(nodes){
      utils.each(nodes, function(node){
        if(IGNORE_ELEMENTS.includes(node.nodeName.toLowerCase())){
          return;
        }
        const text = dom.nodeText(node);
        const size = utils.length(text);
        const length = /[\u4e00-\u9fa5]/.test(text) ? LENGTH : LENGTH * 2;
        if(size < length){
          elements.push({node, text});
        } else {
          let start = 0;
          let index = 0;
          let cache = [];
          const combined = [];
          utils.each(text.split(PUNCTUATIONS).filter(item => item.length > 0), function(part){
            if (index > length){
              combined.push(cache.join(''));
              cache = [];
              index = 0;
            }
            const end = utils.length(part) + 1;
            cache.push(text.substr(start, end));
            start += end;
            index += end;
          });
          cache.length > 0 && combined.push(cache.join(''));
          index = 0;
          utils.each(combined, function(item){
            elements.push({
              node,
              text:item,
              start:index,
            });
            index += item.length;
          });
        }
      });
    });
  }
  push(container);
  app.on('render-ready', function(blocks){
    utils.each(blocks, push);
  });
  window.addEventListener('beforeunload', function(){
    app.fire('speak-pause');
  });
  app.on('render-start-done', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('render-destory-done', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-before', function(){
    dom.setStyle(root, 'display', 'none');
  });
  app.on('pure-after', function(){
    dom.setStyle(root, 'display', 'block');
  });
  app.on('speak-navigate', function(prev){
    let next;
    let nextElement;
    let element = elements[offset];
    if(prev){
      next = offset - 1;
      nextElement = elements[next];
      // 找到上一个
      while(nextElement && element.node === nextElement.node){
        next = next - 1;
        nextElement = elements[next];
      }
      // 继续找同级中的第一个
      element = nextElement;
      while(nextElement && element.node === nextElement.node){
        next = next - 1;
        nextElement = elements[next];
      }
      next++;
    } else {
      next = offset + 1;
      nextElement = elements[next];
      while(nextElement && element.node === nextElement.node){
        next = next + 1;
        nextElement = elements[next];
      }
    }
    const size = elements.length - 1;
    if(next < 0){
      offset = size;
    } else if(next > size) {
      offset = 0;
    } else {
      offset = next;
    }
    app.fire('speak-block');
  });
  app.on('speak-block', function(){
    speechSynthesis.speaking && app.fire('speak-pause');
    const element = elements[offset];
    if(!element){
      return;
    }
    const node = element.node;
    const text = element.text;
    if(!node || text.length <= 0){
      return;
    }
    const utterance = new SpeechSynthesisUtterance;
    utterance.addEventListener('start', function(){
      destory = false;
      node.timer && clearTimeout(node.timer);
      node.classList.add('hightlight-block');
      const rect = node.getBoundingClientRect();
      if(rect.top >= 0 && rect.bottom <= window.innerHeight){
        return;
      }
      dom.scrollIntoView(node);
    });
    utterance.addEventListener('end', function(){
      !destory && app.fire('speak-end');
      node.timer = setTimeout(function(){
        node.classList.remove('hightlight-block');
      }, 500);
    });
    const nodeMark = new Mark(node);
    const start = element.start || 0;
    utterance.addEventListener('boundary', function(event){
      containerMark.unmark({
        acrossElements: true,
        done: function(){
          nodeMark.markRanges([{
            length:event.charLength,
            start: start + event.charIndex,
          }], {
            acrossElements: true,
            className: 'hightlight',
          });
        },
      });
    });
    utterance.addEventListener('error', function(){
      offset = 0;
      app.fire('speak-pause');
    });
    const option = app.cache('speak-option');
    const voices = app.cache('speak-voices');
    utils.each(option, function(value, key){
      if(key === 'voice'){
        if(!value){
          // 选取默认值
          utils.each(voices, function(voice){
            if(voice.default){
              utterance[key] = voice;
              return true;
            }
          });
          return;
        }
        let item;
        utils.each(voices, function(voice){
          if(`${voice.name}-${voice.lang}` === value){
            item = voice;
            return true;
          }
        });
        if(item){
          utterance[key] = item
        } else {
          // 选取默认值
          utils.each(voices, function(voice){
            if(voice.default){
              utterance[key] = voice;
              return true;
            }
          });
        }
      } else {
        utterance[key] = value;
      }
    });
    utterance.text = text;
    speechSynthesis.speak(utterance);
  });
  app.on('speak-end', function(){
    if(offset < elements.length - 1){
      offset++;
      app.fire('speak-block');
    } else {
      offset = 0;
      app.fire('speak-speaking', false);
    }
  });
  app.on('speak-play', function(){
    utils.each(elements, function(element, index){
      const rect = element.node.getBoundingClientRect();
      if(rect.top >= 0){
        offset = index;
        return true;
      }
    });
    app.fire('speak-block');
  });
  app.on('speak-pause', function(){
    destory = true;
    speechSynthesis.pause();
    speechSynthesis.cancel();
    containerMark.unmark();
    app.fire('hightlight', null, 'hightlight-block');
  });
  app.on('render-destory-done', function(){
    app.fire('speak-pause');
  });
  app.on('speak-focus', function(){
    const target = root.querySelector('.togglespeak');
    target && target.focus && target.focus();
  });
  app.on('speak-change', function(visible){
    app.fire('speak-speaking', visible);
    app.fire(`speak-${visible ? 'play': 'pause'}`);
    if(!visible){
      return;
    }
    app.fire('speak-focus');
  });
}
