export const LENGTH = 80;
export const IGNORE_ELEMENTS = ['pre'];
export const PUNCTUATIONS = /；|，|,|\?|！/g; // 。 一般为结尾不做分割
export const IGNORE = ['audio','button','canvas','code','del','dialog','dl','embed','form','head','iframe','meter','nav','noscript','object','s','script','select','style','textarea','video'];
