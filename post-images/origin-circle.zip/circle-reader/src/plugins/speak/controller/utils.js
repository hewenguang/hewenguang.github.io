import { IGNORE } from './config';

export function eachText(context, callback){
  const walker = document.createNodeIterator(context, NodeFilter.SHOW_TEXT, {
    acceptNode(textNode){
      const text = dom.nodeText(textNode);
      if(text.length <= 0){
        return NodeFilter.FILTER_REJECT;
      }
      return /[\u4e00-\u9fa5a-zA-Z\d]/.test(text) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT;
    }
  });
  let nextNode;
  // eslint-disable-next-line
  while(nextNode = walker.nextNode()){
    const parent = nextNode.parentElement;
    dom.visible(parent) && !IGNORE.includes(parent.nodeName.toLowerCase()) && callback(parent);
  }
}

export function sections(context, callback){
  const nodes = [];
  eachText(context, function(node){
    !nodes.includes(node) && nodes.push(node);
  });
  let offset = nodes.length - 1;
  while(offset >= 0){
    const node = nodes[offset];
    nodes.forEach(function(item){
      item !== node && item.contains(node) && nodes.splice(offset, 1);
    });
    offset--;
  }
  callback && callback(nodes);
}
