import React from 'react';
import ReactDOM from 'react-dom';
import Drawer from 'app/components/drawer';
import controller from './controller';
import Entry from './entry';
import './index.less';

App.register('speak', ['shadow', 'dom', 'utils'], function(shadow, dom){
  const app = this;
  const root = dom.create('div');
  shadow({
    style: [
      'plugins/antd/index.css',
      'plugins/speak/index.css',
    ],
    onReady: function(shadowRoot){
      shadowRoot.appendChild(root);
    },
  });

  controller(app, root);
  
  ReactDOM.render((
    <Drawer
      app={app}
      type="toolbar"
      plugin="speak"
    >
      <Entry />
    </Drawer>
  ), root);
});
