import { Space } from 'antd';
import Icon from 'app/components/icon';
import useApp from 'app/context/useApp';
import useOption from 'app/context/useOption';
import useStorage from 'app/context/useStorage';
import React, { useState, useEffect } from 'react';
import Voice from './components/voice';
import Filter from './components/filter';

export default function(){
  const app = useApp();
  const [ speaking, setSpeaking ] = useState(true);
  const [ filter, setFilter ] = useStorage({
    field:'speak-filter',
    defaultValue: 'true',
  });
  const [ option, onChange ] = useOption({
    field:'speak',
    defaultValue:{
      pitch: 1,
      rate: 1,
      volume: 1,
      voice: '',
    },
  });

  useEffect(() => {
    const hook = app.on('speak-speaking', function(doing){
      setSpeaking(doing);
    });
    return () => {
      app.remove(hook);
    };
  }, []);

  useEffect(() => {
    const hook = app.on('srt-togglespeak', function(){
      app.fire(`speak-${speaking ? 'pause' : 'play'}`);
      setSpeaking(!speaking);
      app.fire('speak-focus');
    });
    return () => {
      app.remove(hook);
    };
  }, [ speaking ]);

  useEffect(() => {
    app.cache('speak-option', option);
    if(!speechSynthesis.speaking || !option.voice){
      return;
    }
    app.fire('speak-play');
    setSpeaking(true);
  }, [ option ]);

  return (
    <>
      <Space style={{display:'flex'}}>
        <Voice
          value={option.voice}
          onChange={voice => onChange(Object.assign({}, option, {voice}))}
        />
        <Icon
          size="large"
          tabIndex={0}
          name="step_backward"
          onClick={event => {
            event.stopPropagation();
            event.preventDefault();
            app.fire('speak-navigate', true);
            app.fire('send', 'analytics', {event:'speak-backward'});
          }}
        />
        <Icon
          size="large"
          tabIndex={0}
          className="togglespeak"
          name={speaking ? 'pause' : 'play'}
          onClick={event => {
            event.stopPropagation();
            event.preventDefault();
            app.fire('srt-togglespeak');
            app.fire('send', 'analytics', {event:'speak-toggle'});
          }}
        />
        <Icon
          size="large"
          tabIndex={0}
          name="step_forward"
          onClick={event => {
            event.stopPropagation();
            event.preventDefault();
            app.fire('speak-navigate');
            app.fire('send', 'analytics', {event:'speak-forward'});
          }}
        />
        <Icon
          tabIndex={0}
          name={filter === 'true' ? 'filter_close' : 'filter_open'}
          onClick={event => {
            event.stopPropagation();
            event.preventDefault();
            setFilter(filter === 'true' ? 'false' : 'true');
            app.fire('send', 'analytics', {event:`speak-filter-${filter}`});
          }}
        />
      </Space>
      {filter === 'true' && (
        <Filter
          data={option}
          onChange={onChange}
        />
      )}
    </>
  );
}
