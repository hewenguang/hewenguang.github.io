function datePadding(date){
  let padded = date.toString();
  if (padded.length === 1) {
    padded = `0${date.toString()}`;
  }
  return padded;
}

export default function(timestamp, format = 'yyyy-MM-dd HH:mm:ss'){
  const now = new Date(parseInt(timestamp, 10));
  const date = {
    yyyy: now.getFullYear(),
    MM: datePadding(now.getMonth() + 1),
    dd: datePadding(now.getDate()),
    HH: datePadding(now.getHours()),
    mm: datePadding(now.getMinutes()),
    ss: datePadding(now.getSeconds()),
  };
  Object.keys(date).forEach(item => {
    format = format.replace(item, date[item]);
  });
  return format;
}
