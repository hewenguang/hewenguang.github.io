import { AppContext } from './index';
import { useState, useEffect, useContext } from 'react';

export default function useTable(props){
  const { table = 'wrench' } = props;
  const app = useContext(AppContext);
  const [ data, setData ] = useState([]);
  const [ start, setStart ] = useState(1);
  const [ limit, setLimit ] = useState(5);
  const [ total, setTotal ] = useState(0);
  const [ filter, setFilter ] = useState('');
  const [ loading, setLoading ] = useState(false);
  const refetch = function(){
    app.fire('send', 'db', {
      table,
      execute:'list',
      query: {
        start,
        limit,
        filter,
      },
    }, function({error, data}){
      if(error){
        app.fire('error', error);
      } else {
        setData(data.data);
        setTotal(data.total);
      }
    });
  };

  useEffect(refetch, []);
  useEffect(refetch, [ start, filter ]);

  return [ data, {
    start,
    limit,
    total,
    filter,
    loading,
  },
  {
    refetch,
    setStart,
    setLimit,
    setTotal,
    setFilter,
    setLoading,
  }];
}
