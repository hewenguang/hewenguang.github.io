import { AppContext } from './index';
import { useState, useEffect, useContext } from 'react';

export default function useOption(props){
  const { field, table = 'wrench', defaultValue } = props;
  const app = useContext(AppContext);
  const [ option, setOption ] = useState(defaultValue);
  const fetch = () => {
    app.fire('send', 'db', {
      table,
      name:field,
      execute:'get',
    }, function({error, data}){
      if(error){
        app.fire('error', error);
      } else {
        !utils.isUndefined(data) && setOption(data);
      }
    });
  };
  const change = value => {
    if(utils.isUndefined(value)){
      return;
    }
    app.fire('send', 'db', {
      table,
      name: field,
      value: value,
      execute: 'add',
    }, function({error}){
      if(error){
        app.fire('error', error);
      } else {
        setOption(value);
      }
    });
  };

  useEffect(() => {
    fetch();
    const hook = app.on(`option-${field}`, function({callback} = {}){
      fetch();
      callback && callback();
    });
    return () => {
      app.remove(hook);
    };
  }, []);

  return [ option, change, setOption ];
}
