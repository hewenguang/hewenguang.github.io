import { useContext } from 'react';
import { AppContext } from './index';

export default function(){
  const app = useContext(AppContext);

  return [{
    field: 'srt-enter-or-exit',
    label: app.fire('i18n', 'enter_or_exit'),
  },{
    field: 'srt-exit',
    label: app.fire('i18n', 'exit'),
  },{
    field: 'srt-exitclose',
    label: app.fire('i18n', 'exitclose'),
  },{
    field: 'srt-fullscreen',
    label: app.fire('i18n', 'fullscreen'),
  },{
    field: 'srt-print',
    label: app.fire('i18n', 'print'),
  },{
    field: 'srt-scrollpage',
    label: app.fire('i18n', 'scrollpage'),
  },{
    field: 'srt-togglescrollpage',
    label: app.fire('i18n', 'togglescrollpage'),
  },{
    field: 'srt-speak',
    label: app.fire('i18n', 'speak'),
  },{
    field: 'srt-togglespeak',
    label: app.fire('i18n', 'togglespeak'),
  },{
    field: 'srt-setting',
    label: app.fire('i18n', 'adjust'),
  },{
    field: 'srt-style',
    label: app.fire('i18n', 'style'),
  },{
    field: 'srt-skin',
    label: app.fire('i18n', 'skin'),
  },{
    field: 'srt-layout',
    label: app.fire('i18n', 'layout'),
  },{
    field: 'srt-toolbar',
    label: app.fire('i18n', 'toolbar'),
  },{
    field: 'srt-option',
    label: app.fire('i18n', 'setting'),
  },{
    field: 'srt-basic',
    label: app.fire('i18n', 'basic'),
  },{
    field: 'srt-manage-whitelist',
    label: app.fire('i18n', 'whitelist'),
  },{
    field: 'srt-manage-blacklist',
    label: app.fire('i18n', 'blacklist'),
  },{
    field: 'srt-shortcut',
    label: app.fire('i18n', 'shortcut'),
  },{
    field: 'srt-contextmenu',
    label: app.fire('i18n', 'contextmenu'),
  },{
    field: 'srt-config',
    label: app.fire('i18n', 'config'),
  },{
    field: 'srt-stylesheet',
    label: app.fire('i18n', 'stylesheet'),
  },{
    field: 'srt-links',
    label: app.fire('i18n', 'links'),
  },{
    field:'srt-imagehide',
    label:app.fire('i18n', 'imagehide'),
  },{
    field:'srt-paper',
    label:app.fire('i18n', 'paper'),
  },{
    field: 'srt-whitelist',
    label: app.fire('i18n', 'togglewhitelist'),
  },{
    field: 'srt-whitelist-site',
    label: app.fire('i18n', 'sitewhitelist'),
  },{
    field: 'srt-blacklist',
    label: app.fire('i18n', 'toggleblacklist'),
  },{
    field: 'srt-blacklist-site',
    label: app.fire('i18n', 'siteblacklist'),
  },{
    field: 'srt-search',
    label: app.fire('i18n', 'find'),
  },{
    field:'srt-edit',
    label: app.fire('i18n', 'edit'),
  },{
    field:'srt-remove',
    label: app.fire('i18n', 'remove_element'),
  },{
    field:'srt-copy',
    label: app.fire('i18n', 'copy'),
  },{
    field:'srt-word',
    label: app.fire('i18n', 'export_word'),
  },{
    field:'srt-image',
    label: app.fire('i18n', 'export_image'),
  },{
    field:'srt-text',
    label: app.fire('i18n', 'export_text'),
  },{
    field:'srt-marked',
    label: app.fire('i18n', 'export_marked'),
  },{
    field:'srt-mail',
    label: app.fire('i18n', 'mail'),
  },{
    field:'srt-feedback',
    label: app.fire('i18n', 'feedback'),
  },{
    field:'srt-lnk',
    label: app.fire('i18n', 'export_lnk'),
  },{
    field:'srt-top',
    label: app.fire('i18n', 'backtop'),
  },{
    field:'srt-bottom',
    label: app.fire('i18n', 'backbottom'),
  },{
    field: 'srt-focus',
    label: app.fire('i18n', 'focus'),
    tooltip: app.fire('i18n', 'focus_tooltip'),
    learn_more: app.to('node/37'),
  },{
    field:'srt-exitimg',
    label: app.fire('i18n', 'exit_image'),
  },{
    field:'srt-exitcode',
    label: app.fire('i18n', 'exit_code'),
  },{
    field: 'srt-help',
    label: app.fire('i18n', 'helpcenter'),
  }];
}
