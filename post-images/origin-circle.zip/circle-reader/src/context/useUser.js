import { AppContext } from './index';
import { useState, useEffect, useContext } from 'react';

export default function useUser(){
  const app = useContext(AppContext);
  const initUser = {member:false};
  const [ user, setUser ] = useState(initUser);
  const check = function(){
    app.fire('send', 'user', function({error, data}){
      if(error){
        app.fire('error', error);
      } else {
        setUser(data || initUser);
      }
    });
  }

  useEffect(() => {
    check();
    const login = app.on('login', function({callback} = {}){
      check();
      callback && callback();
    });
    const hook = app.on('visiblechange', function(visible){
      visible && check();
    });
    return () => {
      app.remove(login);
      app.remove(hook);
    };
  }, []);

  return user;
}
