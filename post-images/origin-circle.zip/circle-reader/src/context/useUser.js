import { AppContext } from './index';
import { useState, useEffect, useContext } from 'react';

export default function useUser(){
  const app = useContext(AppContext);
  const [ user, setUser ] = useState({member:false, called: false});
  const check = function(){
    app.fire('send', 'user', function({error, data}){
      if(error){
        app.fire('error', error);
      } else {
        setUser(Object.assign({member:false, called:true}, data));
      }
    });
  }

  useEffect(() => {
    const hook = app.on('login', function({callback} = {}){
      callback && callback();
      check();
    });
    check();
    return () => {
      app.remove(hook);
    };
  }, []);

  return user;
}
