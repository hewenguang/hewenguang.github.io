import { useContext } from 'react';
import { AppContext } from './index';

export default function useApp(){
  return useContext(AppContext);
}
