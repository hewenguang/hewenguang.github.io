import { AppContext } from './index';
import { useState, useEffect, useContext } from 'react';

export default function useStorage(props){
  const { field, defaultValue } = props;
  const app = useContext(AppContext);
  const [ option, setOption ] = useState(defaultValue);
  const change = function(value){
    if(utils.isUndefined(value)){
      return;
    }
    if(value === 'remove'){
      app.fire('send', 'storage', {
        execute: 'remove',
        name: field,
      }, function({error}){
        if(error){
          app.fire('error', error);
        } else {
          setOption(defaultValue);
        }
      });
    } else {
      app.fire('send', 'storage', {
        execute: 'add',
        name: field,
        value: value,
      }, function({error}){
        if(error){
          app.fire('error', error);
        } else {
          setOption(value);
        }
      });
    }
  };

  useEffect(() => {
    app.fire('send', 'storage', {
      name:field,
      execute:'get',
    }, function({error, data}){
      if(error){
        app.fire('error', error);
      } else {
        !utils.isUndefined(data) && data !== null && setOption(data);
      }
    });
  }, []);

  return [ option, change, setOption ];
}
