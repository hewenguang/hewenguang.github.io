const app = new App(false);

app.on('send', function(type, option = {}, callback){
  const valid = app.type(option, 'Function');
  const opts = valid ? {} : option;
  const cb = valid ? option : callback;
  app.runtime.sendMessage(app.runtime.id, Object.assign(opts, { type }), function(...args){
    app.type(cb, 'Function') && cb.apply(null, args);
  });
});
app.on('i18n', function(name, substitutions){
  try{
    return app.i18n.getMessage(name, typeof substitutions === 'number' ? `${substitutions}` : substitutions);
  } catch(e){
    console.log(app.runtime.lastError);
    return name;
  }
});
// 升级高级帐户
app.on('upgrade', function(){
  app.fire('user');
});
document.addEventListener('visibilitychange', function(){
  app.fire('visiblechange', document.visibilityState === 'visible');
});
app.cache('env', 'option');
app.exec('utils');
app.exec('dom');
app.exec('shadow');
app.exec('message');
app.exec('user');
app.exec('wrench');
