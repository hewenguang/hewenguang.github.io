import Hook from './hook';

class App extends Hook{
  constructor() {
    super();
    this._cache = {
      _debug:false,
    };
    ['browserAction','contextMenus','i18n','pageAction','runtime','tabs', 'management'].forEach(item => {
      chrome[item] && (this[item] = chrome[item]);
    });
    this.runtime.onMessage.addListener((request, sender, sendResponse) => {
      const { type } = request;
      if(!type || !this.has(type)){
        sendResponse({error: null});
      } else {
        this.fire(type, {
          sender,
          request,
          callback: function(error, data){
            sendResponse({error, data});
          },
        });
      }
      return true;
    });
  }

  cache(key, value){
    const returnValue = this._cache[`_${key}`];
    if(this.type(value, 'Undefined')){
      return returnValue;
    }
    if(this.type(returnValue, 'Object') && this.type(value, 'Object')){
      this._cache[`_${key}`] = Object.assign({}, returnValue, value);
    } else {
      this._cache[`_${key}`] = value;
    }
  }

  load(name, callback, async){
    const plugin = this.cache(`module_${name}`);
    // console.log('-- load -->', name);
    if(plugin){
      callback && callback.call(this, plugin);
    } else {
      this.fire('load', {
        request: { name, async },
        callback
      });
    }
  }

  loads(dependencies, callback){
    // console.log('-- loads -->', dependencies);
    const dependencie = dependencies.shift();
    if(!dependencie){
      callback && callback();
    } else {
      this.load(dependencie, () => {
        this.loads(dependencies, callback);
      });
    }
  }

  _exec(name, callback){
    const plugin = App._plugin[name];
    const descriptor = plugin.descriptor;
    const dependenciesValue = plugin.dependencies.map(item => this.cache(`module_${item}`));
    const returnValue = this.type(descriptor, 'Function') ? descriptor.apply(this, dependenciesValue) : descriptor;
    this.cache(`module_${name}`, returnValue || descriptor);
    callback && callback.call(this, returnValue);
  }

  exec(name, callback, async){
    const plugin = App._plugin[name];
    // console.log('-- exec -->', name);
    const dependencies = plugin.dependencies;
    const depsLength = dependencies.length;
    if(depsLength <= 0){
      this._exec(name, function(){
        if(async){
          callback && utils.lazy(callback);
        } else {
          callback && callback();
        }
      });
    } else {
      this.loads([].concat(dependencies), () => {
        this._exec(name, function(){
          if(async){
            callback && utils.lazy(callback);
          } else {
            callback && callback();
          }
        });
      });
    }
  }

  static register(name, dependencies, descriptor){
    // console.log('-- register -->', name);
    !App._plugin && (App._plugin = {});
    if(App._plugin[name]){
      console.error(`${name} exist!!`);
      return;
    }
    const pluginDeps = typeof descriptor === 'function' ? dependencies : [];
    const pluginFactory = typeof dependencies === 'function' ? dependencies : descriptor;
    App._plugin[name] = {
      dependencies: Array.isArray(pluginDeps) ? pluginDeps : [ pluginDeps ],
      descriptor: typeof pluginFactory === 'function' ? pluginFactory : function(){},
    };
  }
}

window.App = App;
