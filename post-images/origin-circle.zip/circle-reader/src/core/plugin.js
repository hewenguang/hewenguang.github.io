export default {
  common: {
    script: 'plugins/common/index.js',
    server: 'plugins/common/index.js',
  },
  react: {
    script: 'plugins/react/index.js',
  },
  antd: {
    script: 'plugins/antd/index.js',
  },
  debug: {
    script: 'plugins/debug/index.js',
    server: 'plugins/debug/server.js',
  },
  user: {
    script: 'plugins/user/index.js',
    server: 'plugins/user/server.js',
  },
  utils: {
    script: 'plugins/utils/index.js',
    server: 'plugins/utils/index.js',
  },
  fetch: {
    script: 'plugins/fetch/index.js',
    server: 'plugins/fetch/index.js',
  },
  dom: {
    script: 'plugins/dom/index.js',
  },
  lnk: {
    script: 'plugins/lnk/index.js',
  },
  help: {
    script: 'plugins/help/index.js',
  },
  database: {
    server: 'plugins/database/server.js',
  },
  message: {
    script: 'plugins/message/index.js',
  },
  shadow: {
    script: 'plugins/shadow/index.js',
  },
  app: {
    script: 'plugins/app/index.js',
    server: 'plugins/app/server.js',
  },
  copy: {
    script: 'plugins/copy/index.js',
  },
  html2canvas: {
    script: 'plugins/html2canvas/index.js',
  },
  image: {
    script: 'plugins/image/index.js',
  },
  word: {
    script: 'plugins/word/index.js',
  },
  mail: {
    script: 'plugins/mail/index.js',
  },
  text: {
    script: 'plugins/text/index.js',
  },
  marked: {
    script: 'plugins/marked/index.js',
  },
  choose: {
    script: 'plugins/choose/index.js',
  },
  remove: {
    script: 'plugins/remove/index.js',
  },
  scrollpage: {
    script: 'plugins/scrollpage/index.js',
  },
  speak: {
    script: 'plugins/speak/index.js',
  },
  search: {
    script: 'plugins/search/index.js',
  },
  plain: {
    script: 'plugins/plain/index.js',
  },
  parser: {
    script: 'plugins/parser/index.js',
  },
  toolbar: {
    script: 'plugins/toolbar/index.js',
  },
  render: {
    script: 'plugins/render/index.js',
  },
  setting: {
    script: 'plugins/setting/index.js',
  },
  edit: {
    script: 'plugins/edit/index.js',
  },
  feedback: {
    script: 'plugins/feedback/index.js',
  },
  wrench: {
    script: 'plugins/wrench/index.js',
    server: 'plugins/wrench/server.js',
  },
  anchor: {
    script: 'plugins/anchor/index.js',
  },
  zoom: {
    script: 'plugins/zoom/index.js',
  },
  focus: {
    script: 'plugins/focus/index.js',
  },
  backtop: {
    script: 'plugins/backtop/index.js',
  },
  format: {
    script: 'plugins/format/index.js',
  },
  highlight: {
    script: 'plugins/highlight/index.js',
  },
  nextpage: {
    script: 'plugins/nextpage/index.js',
  },
};
