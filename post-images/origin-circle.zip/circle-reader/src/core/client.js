import loading from './loading';

const app = new App;
app.on('send', function(type, option = {}, callback){
  const valid = app.type(option, 'Function');
  const opts = valid ? {} : option;
  const cb = valid ? option : callback;
  try{
    app.runtime.sendMessage(app.runtime.id, Object.assign(opts, { type }), function(...args){
      app.type(cb, 'Function') && cb.apply(null, args);
    });
  } catch(e){
    console.log(app.runtime.lastError);
  }
});
app.on('load', function({request, callback}){
  app.fire('send', 'load', Object.assign({env: 'client'}, request), function(){
    const plugin = request.name;
    // console.log('----->>>>>', plugin, request);
    if(['common', 'react', 'antd'].includes(plugin)){
      callback && callback();
    } else {
      app.exec(plugin, callback);    
    }
  });
});
app.on('i18n', function(name, substitutions){
  try{
    return app.i18n.getMessage(name, typeof substitutions === 'number' ? `${substitutions}` : substitutions);
  } catch(e){
    console.log(app.runtime.lastError);
    return name;
  }
});

// 加载效果
loading(app);

app.loads(['common', 'react', 'antd', 'message', 'app']);
