import plugins from './plugin';

const app = new App;
const runClient = (code, callback, file, sender) => {
  const params = {
    allFrames: false,
    matchAboutBlank: false,
    runAt: 'document_start',
  };
  params[file ? 'file': 'code'] = code;
  app.tabs.executeScript(sender.tab.id, params, callback);
};
const runServer = (code, callback, file) => {
  const script = document.createElement('script');
  script.setAttribute('type', 'text/javascript');
  script.addEventListener('load', function(){
    document.documentElement.removeChild(script);
    callback && callback();
  });
  if(file){
    script.setAttribute('src', app.runtime.getURL(code));
  } else {
    script.textContent = code;
  }
  document.documentElement.appendChild(script);
};
const load = (client, name, callback, file, sender, data = {}) => {
  const plugin = plugins[name];
  const script = data.script || plugin.script;
  const server = data.server || plugin.server;
  if(client && script){
    runClient(script, callback, file, sender);
  } else if(server){
    runServer(server, function(){
      if(['common'].includes(name)){
        callback && callback();
      } else {
        app.exec(name, callback);
      }
    }, file);
  }
};
app.on('send', function(type, option = {}, callback){
  if(option.tab && option.tab.id){
    app.tabs.sendMessage(option.tab.id, Object.assign(option, { type }), (...args) => {
      app.type(callback, 'Function') && callback.apply(null, args);
    });
  } else {
    app.tabs.query({ active: true, currentWindow: true }, function(tabs){
      if(app.runtime.lastError){
        console.log(app.runtime.lastError);
        return;
      }
      Array.isArray(tabs) && tabs.length > 0 && tabs[0].id && app.tabs.sendMessage(tabs[0].id, Object.assign(option, { type }), (...args) => {
        app.type(callback, 'Function') && callback.apply(null, args);
      });
    });
  }
});
app.on('load', function({request, sender, callback}){
  const name = request.name;
  const client = request.env === 'client';
  load(client, name, callback, true, sender);
});
app.on('i18n', function(name, substitutions){
  try{
    return app.i18n.getMessage(name, typeof substitutions === 'number' ? `${substitutions}` : substitutions);
  } catch(e){
    // console.warn(e);
  }
});
// 记录安装更新事件
app.runtime.onInstalled.addListener(function(details){
  const reason = details.reason;
  if(!['install', 'update'].includes(reason)){
    return;
  }
  // wait hook loaded
  app.cache('system_timer', setInterval(function(){
    if(app.has(reason)){
      clearInterval(app.cache('system_timer'));
      app.fire(reason);
    }
  }, 500));
});
app.cache('db_tables', ['wrench', 'setting', 'shortcut', 'contextmenu', 'blacklist', 'whitelist', 'plugin']);
app.loads(['common', 'app']);
