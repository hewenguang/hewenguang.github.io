const app = new App;
const plugins = {
  common: {
    script: 'plugins/common/index.js',
    server: 'plugins/common/index.js',
  },
  react: {
    script: 'plugins/react/index.js',
  },
  antd: {
    script: 'plugins/antd/index.js',
  },
  debug: {
    script: 'plugins/debug/index.js',
    server: 'plugins/debug/server.js',
  },
  user: {
    script: 'plugins/user/index.js',
    server: 'plugins/user/server.js',
  },
  utils: {
    script: 'plugins/utils/index.js',
    server: 'plugins/utils/index.js',
  },
  fetch: {
    script: 'plugins/fetch/index.js',
    server: 'plugins/fetch/index.js',
  },
  dom: {
    script: 'plugins/dom/index.js',
  },
  cron: {
    server: 'plugins/cron/server.js',
  },
  analytics: {
    server: 'plugins/analytics/server.js',
  },
  database: {
    server: 'plugins/database/server.js',
  },
  message: {
    script: 'plugins/message/index.js',
  },
  shadow: {
    script: 'plugins/shadow/index.js',
  },
  pjax: {
    script: 'plugins/pjax/index.js',
    server: 'plugins/pjax/server.js',
  },
  app: {
    script: 'plugins/app/index.js',
    server: 'plugins/app/server.js',
  },
  plain: {
    script: 'plugins/plain/index.js',
  },
  parser: {
    script: 'plugins/parser/index.js',
  },
  toolbar: {
    script: 'plugins/toolbar/index.js',
  },
  render: {
    script: 'plugins/render/index.js',
  },
  setting: {
    script: 'plugins/setting/index.js',
  },
  wrench: {
    script: 'plugins/wrench/index.js',
    server: 'plugins/wrench/server.js',
  },
  print: {
    script: 'plugins/print/index.js',
  },
  anchor: {
    script: 'plugins/anchor/index.js',
  },
  zoom: {
    script: 'plugins/zoom/index.js',
  },
  focus: {
    script: 'plugins/focus/index.js',
  },
  backtop: {
    script: 'plugins/backtop/index.js',
  },
  format: {
    script: 'plugins/format/index.js',
  },
  highlight: {
    script: 'plugins/highlight/index.js',
  },
  fullscreen: {
    script: 'plugins/fullscreen/index.js',
  },
  nextpage: {
    script: 'plugins/nextpage/index.js',
  },
};
const runClient = (code, callback, file, sender) => {
  const params = {
    allFrames: false,
    matchAboutBlank: false,
    runAt: 'document_start',
  };
  params[file ? 'file': 'code'] = code;
  app.tabs.executeScript(sender.tab.id, params, callback);
};
const runServer = (code, callback, file) => {
  const script = document.createElement('script');
  script.setAttribute('type', 'text/javascript');
  script.addEventListener('load', function(){
    document.documentElement.removeChild(script);
    callback && callback();
  });
  if(file){
    script.setAttribute('src', app.runtime.getURL(code));
  } else {
    script.textContent = code;
  }
  document.documentElement.appendChild(script);
};
const load = (client, name, callback, file, sender, data = {}) => {
  const plugin = plugins[name];
  const script = data.script || plugin.script;
  const server = data.server || plugin.server;
  if(client && script){
    runClient(script, callback, file, sender);
  } else if(server){
    runServer(server, function(){
      if(['common', 'react', 'antd'].includes(name)){
        callback && callback();
      } else {
        app.exec(name, callback);
      }
    }, file);
  }
};
// 安装相关事件
app.runtime.onInstalled.addListener(details => {
  app.on(`system-${details.reason}`, function(){
    app.fire('analytics', {request:{event:details.reason}});
    app.fire(details.reason);
  }, true);
});
app.on('send', function(type, option = {}, callback){
  if(option.tab && option.tab.id){
    app.tabs.sendMessage(option.tab.id, Object.assign(option, { type }), (...args) => {
      app.type(callback, 'Function') && callback.apply(null, args);
    });
  } else {
    app.tabs.query({ active: true, currentWindow: true }, function(tabs){
      app.tabs.sendMessage(tabs[0].id, Object.assign(option, { type }), (...args) => {
        app.type(callback, 'Function') && callback.apply(null, args);
      });
    });
  }
});
app.on('load', function({request, sender, callback}){
  const name = request.name;
  const client = request.env === 'client';
  if(app.has('db')){
    app.fire('db', {
      request:{
        name,
        execute: 'get',
        table: 'plugin',
      },
      callback: function(error, data){
        // console.log(error, data);
        if(!error && data){
          load(client, name, callback, false, sender, data);
        } else {
          load(client, name, callback, true, sender);
        }
      },
    });
  } else {
    load(client, name, callback, true, sender);
  }
});
app.on('i18n', function(name, substitutions){
  try{
    return app.i18n.getMessage(name, typeof substitutions === 'number' ? `${substitutions}` : substitutions);
  } catch(e){
    // console.warn(e);
  }
});
app.cache('db_tables', ['wrench', 'setting', 'shortcut', 'contextmenu', 'blacklist', 'whitelist', 'plugin']);
app.loads(['common', 'app']);
