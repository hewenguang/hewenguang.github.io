export default class Hook {
  constructor() {
    this._index = 0;
    this._hooks = {};
  }

  getIndex(name){
    this._index++;
    return `__${this._index}_${name}`;
  }

  type(value, type){
    return Object.prototype.toString.call(value) === `[object ${type}]`;
  }

  on(name, callback, once, priority = 10){
    !this.type(this._hooks[name], 'Array') && (this._hooks[name] = []);
    let insertIndex = 0;
    this._hooks[name].forEach(function(item, index){
      if(item.priority <= priority){
        insertIndex = index;
        return false;
      }
    });
    const hookIndex = this.getIndex(name);
    this._hooks[hookIndex] = callback;
    this._hooks[name].splice(insertIndex, 0, {
      once:!!once,
      factory: hookIndex,
    });
    return hookIndex;
  }

  remove(name, callback){
    let hookName = name;
    let hookFactory = callback;
    if(name.startsWith('__')){
      hookName = name.split('_').pop();
      hookFactory = this._hooks[name];
    }
    if(!this.has(hookName)){
      return;
    }
    const removeCallback = this.type(hookFactory, 'Function');
    if (removeCallback) {
      this._hooks[hookName].forEach((item, index) => {
        this._hooks[item.factory] === hookFactory && this._hooks[hookName].splice(index, 1);
      });
    } else {
      this._hooks[hookName] = [];
    }
  }

  has(name){
    return !!this._hooks[name];
  }

  fire(name, ...args){
    // console.log('----fire---> ', name, args);
    if(!this.has(name)){
      return args[0];
    }
    const hooksToRemove = [];
    this._hooks[name].forEach(item => {
      const factory = this._hooks[item.factory];
      const returnValue = this.type(factory, 'Function') ? factory.apply(this, args) : factory;
      !this.type(returnValue, 'Undefined') && (args[0] = returnValue);
      item.once && hooksToRemove.push(item.factory);
    });
    hooksToRemove.forEach(hookToRemove => {
      this.remove(hookToRemove);
    });
    return args[0];
  }
}
