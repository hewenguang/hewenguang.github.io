const path = require('path');
const config = require('./config.json');
const TerserPlugin = require('terser-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CssMinimizerPlugin = require('css-minimizer-webpack-plugin');
const { getHTMLPlugins, getOutput, getCopyPlugins, getZipPlugin, getEntry, getFirefoxCopyPlugins } = require('./utils');

const generalConfig = {
  mode: 'production',
  module: {
    rules: [{
      test: /\.jsx$/,
      exclude: /node_modules/,
      resolve: {
        extensions: ['.js', '.jsx']
      },
      use: {
        loader: 'babel-loader',
        options: {
          presets: ['@babel/preset-env', '@babel/preset-react'],
        }
      },
    },{
      test: /\.js$/,
      exclude: /node_modules/,
      use: [{
        loader: 'babel-loader',
        options: {
          presets: ['@babel/preset-env'],
        }
      }, 'eslint-loader'],
    },
    {
      test: /\.(css|less)$/,
      use: [
        MiniCssExtractPlugin.loader,
        'css-loader',
        {
          loader: 'less-loader',
          options: {
            lessOptions: {
              javascriptEnabled:true,
              // modifyVars: {
              //   'primary-color': '#1DA57A',
              //   'link-color': '#1DA57A',
              //   'border-radius-base': '2px',
              // },
            }
          }
        }
      ],
    },{
      test: /\.(png|jpe?g|gif|svg)$/i,
      use: [
        {
          loader: 'file-loader',
          options: {
            outputPath: 'images',
            name: '[name].[ext]',
            publicPath: '../../images',
          },
        },
      ],
  }]},
  resolve: {
    alias: {
      app: path.resolve(__dirname, `${config.chromePath}/`),
      plugin: path.resolve(__dirname, `${config.chromePath}/plugins/`),
    },
    extensions: ['.js', '.jsx'],
  },
  optimization: {
    minimize: true,
    minimizer: [
      new CssMinimizerPlugin(),
      new TerserPlugin({
        terserOptions: {
          ecma: 6,
          compress: true,
          output: {
            comments: false,
            beautify: false
          }
        },
        parallel: true,
        extractComments: false,
      })
    ],
    splitChunks: {
      cacheGroups: {
        default: {
          name: 'plugins/common/index',
          chunks: 'initial',
          minChunks: 2,
          priority: -20,
        },
        react: {
          test: /react|react-dom/,
          name: 'plugins/react/index',
          chunks: 'initial',
          priority: -5
        },
        antd: {
          test: /antd|@ant-design/,
          name: 'plugins/antd/index',
          chunks: 'initial',
          priority: -1
        }
      }
    }
  }
};

module.exports = [
  {
    ...generalConfig,
    output: getOutput('chrome', config.tempDirectory),
    entry: getEntry(true),
    plugins: [
      new CleanWebpackPlugin(),
      new MiniCssExtractPlugin(),
      ...getHTMLPlugins('chrome', config.tempDirectory, config.chromePath),
      ...getCopyPlugins('chrome', config.tempDirectory, config.chromePath),
      getZipPlugin('chrome', config.distDirectory),
    ],
  },
  {
    ...generalConfig,
    output: getOutput('firefox', config.tempDirectory),
    entry: getEntry(true),
    plugins: [
      new CleanWebpackPlugin(),
      new MiniCssExtractPlugin(),
      ...getHTMLPlugins('firefox', config.tempDirectory, config.firefoxPath),
      ...getFirefoxCopyPlugins('firefox', config.tempDirectory, config.firefoxPath),
      getZipPlugin('firefox', config.distDirectory),
    ],
  },
];
