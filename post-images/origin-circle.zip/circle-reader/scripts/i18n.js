const a = {};

// const items = [];
// Object.keys(a).forEach(function(key){
//   items.push(a[key].message);
// });

// console.log(items.join('\n'));

const b = ``;
const keys = b.split('\n');
Object.keys(a).forEach(function(key, index){
  a[key].message = keys[index];
});
console.log(JSON.stringify(a));
