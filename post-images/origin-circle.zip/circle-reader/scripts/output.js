const fs = require('fs');
const glob = require('glob');
const path = require('path');

glob('dev/chrome/plugin/*/*', (error, files) => {
  if(error){
    throw new Error(error);
  }
  const maps = {};
  let fileIndex = 0;
  const filesLength = files.length;
  files.forEach(filePath => {
    const pluginPath = path.resolve(__dirname, '../', filePath);
    const pathArr = filePath.split('/');
    const pluginName = pathArr[pathArr.length - 2];
    !maps[pluginName] && (maps[pluginName] = {});
    let pluginKey;
    switch(pathArr.pop()){
      case 'index.js':
        pluginKey = 'script';
        break;
      case 'index.css':
        pluginKey = 'style';
        break;
      case 'server.js':
        pluginKey = 'server';
        break;
    }
    fs.readFile(pluginPath, (err, buffer) => {
      if (err) {
        throw new Error(err);
      }
      maps[pluginName][pluginKey] = buffer.toString();
      fileIndex ++;
      fileIndex >= filesLength && fs.writeFileSync('dev/chrome/output.json', JSON.stringify(maps));
    });
  });
});
