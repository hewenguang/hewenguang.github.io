const path = require('path');
const glob = require('glob');
const ZipPlugin = require('zip-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

const getHTMLPlugins = (browserDir, outputDir = 'dev', sourceDir = 'src') => [
  new HtmlWebpackPlugin({
    filename: path.resolve(__dirname, `${outputDir}/${browserDir}/option/index.html`),
    template: path.resolve(__dirname, `${sourceDir}/option/index.html`),
    chunks: [],
  }),
];

const getOutput = (browserDir, outputDir = 'dev') => {
  return {
    filename: '[name].js',
    path: path.resolve(__dirname, `${outputDir}/${browserDir}`),
  };
};

const getEntry = (pro) => {
  const entries = {};
  glob.sync('src/core/*.js').forEach(item => {
    const pathArr = item.split('/');
    const name = pathArr.pop();
    const plugin = name.split('.').shift();
    plugin !== 'hook' && (entries[`core/${plugin}`] = path.resolve(__dirname, `../${item}`));
  });
  glob.sync('src/plugins/*/?(index|server).js*').forEach(item => {
    const pathArr = item.split('/');
    const name = pathArr.pop();
    const plugin = name.split('.').shift();
    const folder = pathArr[2];
    if(pro){
      folder !== 'debug' && (entries[`plugins/${folder}/${plugin}`] = path.resolve(__dirname, `../${item}`));
    } else {
      entries[`plugins/${folder}/${plugin}`] = path.resolve(__dirname, `../${item}`);
    }
  });
  return entries;
};

const getCopyPlugins = (browserDir, outputDir = 'dev', sourceDir = 'src') => [
  new CopyWebpackPlugin({
    patterns: [
      { from: path.resolve(__dirname, `${sourceDir}/icons`), to: path.resolve(__dirname, `${outputDir}/${browserDir}/icons`) },
      { from: path.resolve(__dirname, `${sourceDir}/_locales`), to: path.resolve(__dirname, `${outputDir}/${browserDir}/_locales`) },
      { from: path.resolve(__dirname, `${sourceDir}/manifest.json`), to: path.resolve(__dirname, `${outputDir}/${browserDir}/manifest.json`) },
    ]
  }),
];

const getFirefoxCopyPlugins = (browserDir, outputDir = 'dev', sourceDir = 'src') => [
  new CopyWebpackPlugin({
    patterns: [
      { from: path.resolve(__dirname, `${sourceDir}/icons`), to: path.resolve(__dirname, `${outputDir}/${browserDir}/icons`) },
      { from: path.resolve(__dirname, `${sourceDir}/_locales`), to: path.resolve(__dirname, `${outputDir}/${browserDir}/_locales`) },
      { from: path.resolve(__dirname, `${sourceDir}/manifest-ff.json`), to: path.resolve(__dirname, `${outputDir}/${browserDir}/manifest.json`) },
    ]
  }),
];

const getZipPlugin = (browserDir, outputDir = 'dist') =>
  new ZipPlugin({
    path: path.resolve(__dirname, `${outputDir}/${browserDir}`),
    filename: browserDir,
    extension: 'zip',
    fileOptions: {
      mtime: new Date(),
      mode: 0o100664,
      compress: true,
      forceZip64Format: false,
    },
    zipOptions: {
      forceZip64Format: false,
    },
});

module.exports = {
  getHTMLPlugins,
  getOutput,
  getCopyPlugins,
  getFirefoxCopyPlugins,
  getZipPlugin,
  getEntry,
};
